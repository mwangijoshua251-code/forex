"use client";

import { formatPrice, getSymbol } from "@/lib/markets";
import { useQuotes } from "./useQuotes";

const LIST = ["1HZ100V", "R_75", "BOOM1000", "CRASH500", "frxEURUSD", "frxGBPUSD", "frxXAUUSD", "cryBTCUSD", "cryETHUSD", "OTC_NDX", "stkTSLA", "stkNVDA", "WTI_OIL", "frxUSDKES"];

export function LiveTicker() {
  const quotes = useQuotes(3000);
  const items = LIST.map((s) => ({ s: getSymbol(s)!, q: quotes[s] }));
  return (
    <div className="overflow-hidden border-t border-white/5 bg-ink-900/60">
      <div className="flex w-max animate-[marquee_60s_linear_infinite] gap-8 px-4 py-1.5 text-xs">
        {[...items, ...items].map(({ s, q }, i) => (
          <span key={i} className="flex items-center gap-2 whitespace-nowrap">
            <span className="text-slate-400">{s.name}</span>
            <span className="tabular-nums text-white">{q ? formatPrice(q.price, s.decimals) : "—"}</span>
            {q && <span className={q.change >= 0 ? "text-up" : "text-down"}>{q.change >= 0 ? "▲" : "▼"} {Math.abs(q.change).toFixed(2)}%</span>}
          </span>
        ))}
      </div>
      <style>{`@keyframes marquee { from { transform: translateX(0); } to { transform: translateX(-50%); } }`}</style>
    </div>
  );
}
