"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { MARKETS, SYMBOLS, formatPrice, getSymbol, type MarketKey } from "@/lib/markets";
import { TRADE_GROUPS } from "@/lib/pricing";
import { api, money, signed } from "@/lib/format";
import { useMe } from "./AppShell";
import { useQuotes } from "./useQuotes";
import { SymbolIcon } from "./trade/MarketSelector";

export function Hub({ welcome }: { welcome: boolean }) {
  const { me, switchAccount, refresh } = useMe();
  const quotes = useQuotes(3000);
  const [market, setMarket] = useState<MarketKey>("synthetic");
  const [summary, setSummary] = useState<{ total: number; won: number; lost: number; staked: number } | null>(null);
  const [alerts, setAlerts] = useState<{ id: number; symbol: string; price: number; direction: string; triggered: boolean }[]>([]);
  const [msg, setMsg] = useState("");

  const loadAlerts = useCallback(() => api<{ rows: typeof alerts }>("/api/alerts").then((r) => setAlerts(r.rows)).catch(() => {}), []);
  useEffect(() => {
    api<{ summary: typeof summary }>("/api/reports?type=profit").then((r) => setSummary(r.summary)).catch(() => {});
    loadAlerts();
  }, [me.active.id, loadAlerts]);

  const demo = me.accounts.find((a) => a.type === "demo");
  const real = me.accounts.find((a) => a.type === "real");

  const resetDemo = async () => {
    try {
      await api("/api/accounts", { json: { action: "reset-demo" } });
      setMsg("Demo balance reset to 10,000.00 USD");
      refresh();
    } catch (e) {
      setMsg((e as Error).message);
    }
  };

  const go = async (id: number) => {
    if (id !== me.active.id) await switchAccount(id);
    window.location.href = "/trade";
  };

  const total = (summary?.won ?? 0) + (summary?.lost ?? 0);

  return (
    <div className="mx-auto max-w-7xl p-4 sm:p-6">
      {welcome && (
        <div className="mb-6 rounded-xl border border-brand/30 bg-gradient-to-r from-brand/20 to-transparent p-5">
          <h2 className="text-lg font-bold text-white">Welcome to Tradova, {me.user.fullName.split(" ")[0]}! 🎉</h2>
          <p className="text-sm text-slate-300">Your demo account is loaded with 10,000 USD of virtual funds. Practise risk-free, then fund your real account with USDT, BTC, ETH or M-Pesa.</p>
        </div>
      )}
      <h1 className="mb-1 text-2xl font-bold text-white">Trader&apos;s Hub</h1>
      <p className="mb-6 text-sm text-slate-400">Manage your accounts and jump into the markets.</p>
      {msg && <p className="mb-4 rounded-lg bg-white/5 px-4 py-2 text-sm text-slate-300">{msg}</p>}

      <div className="grid gap-4 md:grid-cols-2">
        {real && (
          <div className="card relative overflow-hidden p-5">
            <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-emerald-500/10 blur-2xl" />
            <div className="flex items-center justify-between">
              <span className="rounded bg-emerald-500/15 px-2 py-0.5 text-xs font-bold uppercase text-emerald-300">Real · USD</span>
              <span className="text-xs text-slate-500">{real.loginId}</span>
            </div>
            <div className="mt-4 text-3xl font-bold tabular-nums text-white">{money(real.balance)}</div>
            <div className="mt-5 flex flex-wrap gap-2">
              <button onClick={() => go(real.id)} className="btn-brand">Trade</button>
              <Link href="/cashier?tab=deposit" className="btn-ghost">Deposit</Link>
              <Link href="/cashier?tab=withdraw" className="btn-ghost">Withdraw</Link>
            </div>
            {me.user.kycStatus !== "verified" && (
              <p className="mt-4 text-xs text-amber-300">
                Identity {me.user.kycStatus === "pending" ? "verification pending review" : "not verified"} · <Link href="/profile?tab=verification" className="underline">Verification</Link>
              </p>
            )}
          </div>
        )}
        {demo && (
          <div className="card relative overflow-hidden p-5">
            <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-sky-500/10 blur-2xl" />
            <div className="flex items-center justify-between">
              <span className="rounded bg-sky-500/15 px-2 py-0.5 text-xs font-bold uppercase text-sky-300">Demo · USD</span>
              <span className="text-xs text-slate-500">{demo.loginId}</span>
            </div>
            <div className="mt-4 text-3xl font-bold tabular-nums text-white">{money(demo.balance)}</div>
            <div className="mt-5 flex flex-wrap gap-2">
              <button onClick={() => go(demo.id)} className="btn-brand">Trade</button>
              <button onClick={resetDemo} className="btn-ghost">Reset balance</button>
            </div>
          </div>
        )}
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          ["Net P/L (30d)", summary ? signed(summary.total) + " USD" : "—", (summary?.total ?? 0) >= 0 ? "text-up" : "text-down"],
          ["Contracts (30d)", String(total), "text-white"],
          ["Win rate", total ? `${(((summary?.won ?? 0) / total) * 100).toFixed(1)}%` : "—", "text-white"],
          ["Turnover (30d)", summary ? money(summary.staked) : "—", "text-white"],
        ].map(([k, v, c]) => (
          <div key={k} className="card p-4">
            <div className="text-xs text-slate-500">{k} · {me.active.type}</div>
            <div className={`mt-1 text-lg font-bold tabular-nums ${c}`}>{v}</div>
          </div>
        ))}
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_340px]">
        <div className="card overflow-hidden">
          <div className="flex flex-wrap items-center gap-1 border-b border-white/5 p-3">
            <span className="mr-3 font-semibold text-white">Markets</span>
            {MARKETS.map((m) => (
              <button key={m.key} onClick={() => setMarket(m.key)} className={`tab text-xs ${market === m.key ? "tab-active" : ""}`}>{m.label}</button>
            ))}
          </div>
          <p className="px-4 pt-3 text-xs text-slate-500">{MARKETS.find((m) => m.key === market)?.desc}</p>
          <div className="overflow-x-auto">
            <table className="data w-full">
              <thead><tr><th>Instrument</th><th className="!text-right">Price</th><th className="!text-right">Change</th><th /></tr></thead>
              <tbody>
                {SYMBOLS.filter((s) => s.market === market).map((s) => {
                  const q = quotes[s.symbol];
                  return (
                    <tr key={s.symbol} className="hover:bg-white/[0.02]">
                      <td>
                        <div className="flex items-center gap-3">
                          <SymbolIcon market={s.market} />
                          <div><div className="font-medium text-white">{s.name}</div><div className="text-xs text-slate-500">{s.submarket}</div></div>
                        </div>
                      </td>
                      <td className="text-right tabular-nums text-white">{q ? formatPrice(q.price, s.decimals) : "—"}</td>
                      <td className={`text-right tabular-nums ${q && q.change >= 0 ? "text-up" : "text-down"}`}>{q ? `${q.change >= 0 ? "+" : ""}${q.change.toFixed(2)}%` : ""}</td>
                      <td className="text-right"><Link href={`/trade?symbol=${s.symbol}`} className="rounded-md bg-brand/15 px-3 py-1 text-xs font-semibold text-brand hover:bg-brand/25">Trade</Link></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
        <div className="space-y-6">
          <div className="card p-4">
            <h3 className="mb-3 font-semibold text-white">Trade types</h3>
            <div className="space-y-2">
              {TRADE_GROUPS.map((t) => (
                <div key={t.key} className="rounded-lg bg-ink-850 p-3">
                  <div className="flex items-center justify-between text-sm font-medium text-white">{t.label}<span className="text-[10px] uppercase text-slate-500">{t.category}</span></div>
                  <p className="mt-1 text-xs text-slate-500">{t.desc}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="card p-4">
            <h3 className="mb-3 font-semibold text-white">Price alerts</h3>
            {alerts.length === 0 && <p className="text-xs text-slate-500">Set alerts from the 🔔 button on the trading chart.</p>}
            {alerts.map((a) => {
              const s = getSymbol(a.symbol);
              return (
                <div key={a.id} className="flex items-center justify-between border-t border-white/5 py-2 text-sm first:border-0">
                  <div>
                    <div className="text-white">{s?.name}</div>
                    <div className="text-xs text-slate-500">{a.direction} {formatPrice(a.price, s?.decimals ?? 2)} {a.triggered && <span className="text-up">· triggered</span>}</div>
                  </div>
                  <button onClick={async () => { await api("/api/alerts", { json: { action: "delete", id: a.id } }); loadAlerts(); }} className="text-xs text-slate-500 hover:text-brand">Remove</button>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
