"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/format";

export type Quotes = Record<string, { price: number; change: number; prev: number }>;

export function useQuotes(intervalMs = 2000) {
  const [quotes, setQuotes] = useState<Quotes>({});
  useEffect(() => {
    let alive = true;
    const load = async () => {
      try {
        const r = await api<{ quotes: Quotes }>("/api/market/quotes");
        if (alive) setQuotes(r.quotes);
      } catch {
        /* ignore */
      }
    };
    load();
    const id = setInterval(load, intervalMs);
    return () => {
      alive = false;
      clearInterval(id);
    };
  }, [intervalMs]);
  return quotes;
}
