"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { api, dateTime, money } from "@/lib/format";

export interface ClientAccount {
  id: number;
  type: string;
  loginId: string;
  currency: string;
  balance: number;
}
export interface ClientUser {
  id: number;
  email: string | null;
  phone: string | null;
  fullName: string;
  country: string;
  role: string;
  kycStatus: string;
}
interface Me {
  user: ClientUser;
  accounts: ClientAccount[];
  active: ClientAccount;
  unread: number;
}

const Ctx = createContext<{
  me: Me;
  refresh: () => Promise<void>;
  switchAccount: (id: number) => Promise<void>;
  setBalance: (b: number) => void;
} | null>(null);

export function useMe() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useMe outside AppShell");
  return c;
}

export function Logo({ className = "" }: { className?: string }) {
  return (
    <span className={`flex items-center gap-2 font-extrabold tracking-tight ${className}`}>
      <span className="grid h-7 w-7 place-items-center rounded-md bg-brand text-sm text-white">T</span>
      <span className="text-lg text-white">
        trad<span className="text-brand">ova</span>
      </span>
    </span>
  );
}

const NAV = [
  { href: "/trade", label: "Trade" },
  { href: "/hub", label: "Trader's Hub" },
  { href: "/cashier", label: "Cashier" },
  { href: "/reports", label: "Reports" },
  { href: "/profile", label: "Account" },
];

export function AppShell({ initial, children }: { initial: Me; children: ReactNode }) {
  const [me, setMe] = useState<Me>(initial);
  const router = useRouter();
  const path = usePathname();

  const refresh = useCallback(async () => {
    try {
      const m = await api<Me>("/api/me");
      setMe(m);
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    const id = setInterval(refresh, 5000);
    return () => clearInterval(id);
  }, [refresh]);

  const switchAccount = useCallback(
    async (id: number) => {
      await api("/api/accounts", { json: { action: "switch", accountId: id } });
      await refresh();
      router.refresh();
    },
    [refresh, router]
  );

  const setBalance = useCallback((b: number) => {
    setMe((m) => (m.active.balance === b ? m : { ...m, active: { ...m.active, balance: b }, accounts: m.accounts.map((a) => (a.id === m.active.id ? { ...a, balance: b } : a)) }));
  }, []);

  const nav = me.user.role === "admin" ? [...NAV, { href: "/admin", label: "Admin" }] : NAV;

  return (
    <Ctx.Provider value={{ me, refresh, switchAccount, setBalance }}>
      <div className="flex min-h-screen flex-col">
        <header className="sticky top-0 z-40 border-b border-white/5 bg-ink-900/95 backdrop-blur">
          <div className="flex h-14 items-center gap-4 px-3 sm:px-5">
            <Link href="/trade">
              <Logo />
            </Link>
            <nav className="hidden items-center gap-1 md:flex">
              {nav.map((n) => (
                <Link key={n.href} href={n.href} className={`tab ${path.startsWith(n.href) ? "tab-active" : ""}`}>
                  {n.label}
                </Link>
              ))}
            </nav>
            <div className="ml-auto flex items-center gap-2">
              <Notifications unread={me.unread} onRead={refresh} />
              <AccountSwitcher />
              <Link href="/cashier" className="btn-brand hidden !py-2 sm:inline-flex">
                Deposit
              </Link>
              <UserMenu />
            </div>
          </div>
          <nav className="flex gap-1 overflow-x-auto border-t border-white/5 px-2 py-1.5 md:hidden">
            {nav.map((n) => (
              <Link key={n.href} href={n.href} className={`tab whitespace-nowrap ${path.startsWith(n.href) ? "tab-active" : ""}`}>
                {n.label}
              </Link>
            ))}
          </nav>
        </header>
        <main className="flex-1">{children}</main>
      </div>
    </Ctx.Provider>
  );
}

function useClickOutside(cb: () => void) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) cb();
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [cb]);
  return ref;
}

function AccountSwitcher() {
  const { me, switchAccount } = useMe();
  const [open, setOpen] = useState(false);
  const ref = useClickOutside(useCallback(() => setOpen(false), []));
  const a = me.active;
  return (
    <div className="relative" ref={ref}>
      <button onClick={() => setOpen(!open)} className="flex items-center gap-2 rounded-lg border border-white/10 bg-ink-850 px-3 py-1.5 text-left hover:bg-ink-800">
        <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold uppercase ${a.type === "demo" ? "bg-sky-500/15 text-sky-300" : "bg-emerald-500/15 text-emerald-300"}`}>
          {a.type}
        </span>
        <span className="text-sm font-semibold tabular-nums text-white">{money(a.balance)}</span>
        <svg width="12" height="12" viewBox="0 0 24 24" className="text-slate-400"><path fill="currentColor" d="M7 10l5 5 5-5z" /></svg>
      </button>
      {open && (
        <div className="absolute right-0 mt-2 w-72 rounded-xl border border-white/10 bg-ink-850 p-2 shadow-2xl">
          <p className="px-2 pb-2 pt-1 text-xs uppercase tracking-wide text-slate-500">Your accounts</p>
          {me.accounts.map((acc) => (
            <button
              key={acc.id}
              onClick={async () => {
                setOpen(false);
                if (acc.id !== a.id) await switchAccount(acc.id);
              }}
              className={`flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-left hover:bg-white/5 ${acc.id === a.id ? "bg-white/5" : ""}`}
            >
              <div>
                <div className="text-sm font-medium text-white">{acc.type === "demo" ? "Demo account" : "Real account"}</div>
                <div className="text-xs text-slate-500">{acc.loginId}</div>
              </div>
              <div className="text-sm font-semibold tabular-nums">{money(acc.balance)}</div>
            </button>
          ))}
          <Link href="/hub" onClick={() => setOpen(false)} className="mt-1 block rounded-lg px-3 py-2 text-center text-xs text-slate-400 hover:bg-white/5">
            Manage accounts →
          </Link>
        </div>
      )}
    </div>
  );
}

function Notifications({ unread, onRead }: { unread: number; onRead: () => void }) {
  const [open, setOpen] = useState(false);
  const [rows, setRows] = useState<{ id: number; title: string; body: string; read: boolean; createdAt: string }[]>([]);
  const ref = useClickOutside(useCallback(() => setOpen(false), []));
  const toggle = async () => {
    const next = !open;
    setOpen(next);
    if (next) {
      const r = await api<{ rows: typeof rows }>("/api/notifications");
      setRows(r.rows);
      if (unread) {
        await api("/api/notifications", { json: {} });
        onRead();
      }
    }
  };
  return (
    <div className="relative" ref={ref}>
      <button onClick={toggle} className="relative grid h-9 w-9 place-items-center rounded-lg hover:bg-white/5" aria-label="Notifications">
        <svg width="20" height="20" viewBox="0 0 24 24" className="text-slate-300"><path fill="currentColor" d="M12 22a2 2 0 0 0 2-2h-4a2 2 0 0 0 2 2m6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4a1.5 1.5 0 0 0-3 0v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1z" /></svg>
        {unread > 0 && <span className="absolute right-1 top-1 grid h-4 min-w-4 place-items-center rounded-full bg-brand px-1 text-[10px] font-bold text-white">{unread}</span>}
      </button>
      {open && (
        <div className="absolute right-0 mt-2 max-h-96 w-80 overflow-y-auto rounded-xl border border-white/10 bg-ink-850 p-2 shadow-2xl">
          <p className="px-2 pb-2 pt-1 text-xs uppercase tracking-wide text-slate-500">Notifications</p>
          {rows.length === 0 && <p className="px-2 py-6 text-center text-sm text-slate-500">No notifications yet</p>}
          {rows.map((n) => (
            <div key={n.id} className="rounded-lg px-3 py-2 hover:bg-white/5">
              <div className="flex items-center gap-2 text-sm font-medium text-white">
                {!n.read && <span className="h-1.5 w-1.5 rounded-full bg-brand" />}
                {n.title}
              </div>
              <div className="text-xs text-slate-400">{n.body}</div>
              <div className="mt-0.5 text-[10px] text-slate-600">{dateTime(n.createdAt)}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function UserMenu() {
  const { me } = useMe();
  const [open, setOpen] = useState(false);
  const ref = useClickOutside(useCallback(() => setOpen(false), []));
  const logout = async () => {
    await api("/api/auth/logout", { json: {} });
    window.location.href = "/login";
  };
  return (
    <div className="relative" ref={ref}>
      <button onClick={() => setOpen(!open)} className="grid h-9 w-9 place-items-center rounded-full bg-ink-700 text-sm font-bold text-white">
        {me.user.fullName.slice(0, 1).toUpperCase()}
      </button>
      {open && (
        <div className="absolute right-0 mt-2 w-60 rounded-xl border border-white/10 bg-ink-850 p-2 shadow-2xl">
          <div className="px-3 py-2">
            <div className="text-sm font-semibold text-white">{me.user.fullName}</div>
            <div className="text-xs text-slate-500">{me.user.email ?? me.user.phone}</div>
          </div>
          <Link href="/profile" onClick={() => setOpen(false)} className="block rounded-lg px-3 py-2 text-sm hover:bg-white/5">Profile & security</Link>
          <Link href="/cashier" onClick={() => setOpen(false)} className="block rounded-lg px-3 py-2 text-sm hover:bg-white/5">Cashier</Link>
          <Link href="/reports" onClick={() => setOpen(false)} className="block rounded-lg px-3 py-2 text-sm hover:bg-white/5">Reports</Link>
          <button onClick={logout} className="block w-full rounded-lg px-3 py-2 text-left text-sm text-brand hover:bg-white/5">Log out</button>
        </div>
      )}
    </div>
  );
}
