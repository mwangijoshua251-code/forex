"use client";

import { useCallback, useEffect, useState } from "react";
import { METHODS, type MethodKey } from "@/lib/methods";
import { api, dateTime, money } from "@/lib/format";
import { StatusBadge } from "./Cashier";

interface Pay {
  id: number; userId: number; kind: string; method: MethodKey; amountUsd: number; feeUsd: number; assetAmount: number | null; assetCurrency: string | null;
  address: string | null; phone: string | null; txHash: string | null; reference: string; status: string; confirmations: number; requiredConfirmations: number; createdAt: string;
}
interface U {
  id: number; fullName: string; email: string | null; phone: string | null; role: string; kycStatus: string; kycDocType: string | null; kycDocNumber: string | null;
  disabled: boolean; createdAt: string; balance: number | null; loginId: string | null;
}
interface Data {
  stats: Record<string, number>;
  pending: { p: Pay; name: string | null; email: string | null; phone: string | null }[];
  recent: { p: Pay; name: string | null }[];
  users: U[];
}

export function Admin() {
  const [d, setD] = useState<Data | null>(null);
  const [tab, setTab] = useState<"queue" | "users" | "payments">("queue");
  const [q, setQ] = useState("");
  const [msg, setMsg] = useState("");
  const load = useCallback(() => api<Data>(`/api/admin/overview?q=${encodeURIComponent(q)}`).then(setD).catch((e) => setMsg(e.message)), [q]);
  useEffect(() => {
    load();
    const id = setInterval(load, 5000);
    return () => clearInterval(id);
  }, [load]);

  const act = async (payload: Record<string, unknown>, ok: string) => {
    try {
      await api("/api/admin/action", { json: payload });
      setMsg(ok);
      load();
    } catch (e) {
      setMsg((e as Error).message);
    }
  };

  if (!d) return <div className="p-10 text-center text-slate-500">Loading back office…</div>;
  const s = d.stats;
  return (
    <div className="mx-auto max-w-7xl p-4 sm:p-6">
      <h1 className="text-2xl font-bold text-white">Back office</h1>
      <p className="mb-5 text-sm text-slate-400">Payments compliance, KYC review and client management.</p>
      <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4 lg:grid-cols-7">
        {[
          ["Clients", String(s.users)],
          ["Client balances", money(s.realBalances)],
          ["Deposits", money(s.deposits)],
          ["Withdrawals", money(s.withdrawals)],
          ["House P/L (real)", money(s.realPnl)],
          ["Open contracts", String(s.openContracts)],
          ["KYC pending", String(s.pendingKyc)],
        ].map(([k, v]) => (
          <div key={k} className="card p-3">
            <div className="text-[11px] text-slate-500">{k}</div>
            <div className="mt-1 text-sm font-bold tabular-nums text-white">{v}</div>
          </div>
        ))}
      </div>
      {msg && <p className="mb-4 rounded-lg bg-white/5 px-4 py-2 text-sm text-slate-300">{msg}</p>}
      <div className="mb-4 flex gap-1">
        <button onClick={() => setTab("queue")} className={`tab ${tab === "queue" ? "tab-active" : ""}`}>Payment queue ({d.pending.length})</button>
        <button onClick={() => setTab("users")} className={`tab ${tab === "users" ? "tab-active" : ""}`}>Clients</button>
        <button onClick={() => setTab("payments")} className={`tab ${tab === "payments" ? "tab-active" : ""}`}>Recent payments</button>
      </div>

      {tab === "queue" && (
        <div className="card overflow-x-auto">
          <table className="data w-full min-w-[1000px]">
            <thead><tr><th>Date</th><th>Client</th><th>Type</th><th>Method</th><th className="!text-right">USD</th><th>Asset</th><th>Destination / TX</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              {d.pending.length === 0 && <tr><td colSpan={9} className="py-10 text-center text-slate-500">Queue is empty 🎉</td></tr>}
              {d.pending.map(({ p, name, email, phone }) => (
                <tr key={p.id}>
                  <td className="whitespace-nowrap text-xs text-slate-400">{dateTime(p.createdAt)}</td>
                  <td><div className="text-white">{name}</div><div className="text-xs text-slate-500">{email ?? phone}</div></td>
                  <td className="capitalize">{p.kind}</td>
                  <td>{METHODS[p.method]?.label}</td>
                  <td className="text-right font-semibold tabular-nums">{money(p.amountUsd, false)}</td>
                  <td className="text-xs tabular-nums">{p.assetAmount} {p.assetCurrency}</td>
                  <td className="max-w-[220px] truncate font-mono text-[11px] text-slate-400" title={p.address || p.phone || p.txHash || ""}>{p.address || p.phone}<div>{p.txHash}</div></td>
                  <td><StatusBadge s={p.status} />{p.requiredConfirmations > 0 && <div className="text-[10px] text-slate-500">{p.confirmations}/{p.requiredConfirmations} conf</div>}</td>
                  <td className="whitespace-nowrap">
                    <button onClick={() => act({ target: "payment", id: p.id, action: "approve" }, `${p.reference} approved`)} className="mr-2 rounded bg-up/20 px-2 py-1 text-xs font-semibold text-up hover:bg-up/30">{p.kind === "deposit" ? "Confirm" : "Approve & send"}</button>
                    <button onClick={() => { const r = prompt("Reason for rejection", "Failed compliance checks"); if (r !== null) act({ target: "payment", id: p.id, action: "reject", reason: r }, `${p.reference} rejected`); }} className="rounded bg-down/20 px-2 py-1 text-xs font-semibold text-down hover:bg-down/30">Reject</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === "users" && (
        <div className="card overflow-x-auto">
          <div className="p-3"><input className="input max-w-sm" placeholder="Search name, email, phone…" value={q} onChange={(e) => setQ(e.target.value)} /></div>
          <table className="data w-full min-w-[1000px]">
            <thead><tr><th>Client</th><th>Login</th><th className="!text-right">Real balance</th><th>KYC</th><th>Joined</th><th>Actions</th></tr></thead>
            <tbody>
              {d.users.map((u) => (
                <tr key={u.id} className={u.disabled ? "opacity-50" : ""}>
                  <td><div className="text-white">{u.fullName} {u.role === "admin" && <span className="ml-1 rounded bg-brand/20 px-1.5 text-[10px] text-brand">ADMIN</span>}</div><div className="text-xs text-slate-500">{u.email} {u.phone}</div></td>
                  <td className="text-xs text-slate-400">{u.loginId}</td>
                  <td className="text-right tabular-nums">{money(u.balance, false)}</td>
                  <td>
                    <span className={`text-xs font-semibold uppercase ${u.kycStatus === "verified" ? "text-up" : u.kycStatus === "pending" ? "text-amber-300" : "text-slate-500"}`}>{u.kycStatus}</span>
                    {u.kycDocNumber && <div className="text-[10px] text-slate-500">{u.kycDocType?.replace("_", " ")} · {u.kycDocNumber}</div>}
                  </td>
                  <td className="text-xs text-slate-400">{dateTime(u.createdAt)}</td>
                  <td className="space-x-1 whitespace-nowrap">
                    {u.kycStatus !== "verified" && <button onClick={() => act({ target: "user", id: u.id, action: "verify" }, `${u.fullName} verified`)} className="rounded bg-up/20 px-2 py-1 text-xs text-up">Verify</button>}
                    {u.kycStatus === "pending" && <button onClick={() => act({ target: "user", id: u.id, action: "reject_kyc" }, "KYC rejected")} className="rounded bg-white/10 px-2 py-1 text-xs">Reject KYC</button>}
                    <button onClick={() => { const a = prompt("Adjust real balance by (USD, negative to debit):"); if (a) act({ target: "user", id: u.id, action: "credit", amount: Number(a), reason: "Manual adjustment by admin" }, "Balance adjusted"); }} className="rounded bg-white/10 px-2 py-1 text-xs">Adjust</button>
                    {u.role !== "admin" && <button onClick={() => act({ target: "user", id: u.id, action: u.disabled ? "enable" : "disable" }, "Updated")} className="rounded bg-down/20 px-2 py-1 text-xs text-down">{u.disabled ? "Enable" : "Disable"}</button>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === "payments" && (
        <div className="card overflow-x-auto">
          <table className="data w-full min-w-[800px]">
            <thead><tr><th>Date</th><th>Client</th><th>Ref</th><th>Type</th><th>Method</th><th className="!text-right">USD</th><th>Status</th></tr></thead>
            <tbody>
              {d.recent.map(({ p, name }) => (
                <tr key={p.id}>
                  <td className="whitespace-nowrap text-xs text-slate-400">{dateTime(p.createdAt)}</td>
                  <td className="text-white">{name}</td>
                  <td className="text-xs text-slate-400">{p.reference}</td>
                  <td className="capitalize">{p.kind}</td>
                  <td>{METHODS[p.method]?.label}</td>
                  <td className="text-right tabular-nums">{money(p.amountUsd, false)}</td>
                  <td><StatusBadge s={p.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
