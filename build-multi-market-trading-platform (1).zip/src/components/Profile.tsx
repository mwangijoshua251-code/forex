"use client";

import { useEffect, useState } from "react";
import { api, dateTime } from "@/lib/format";
import { useMe } from "./AppShell";

interface P {
  id: number; email: string | null; phone: string | null; fullName: string; country: string; role: string; kycStatus: string;
  dateOfBirth: string | null; address: string | null; kycDocType: string | null; kycDocNumber: string | null;
  maxStake: number | null; dailyLossLimit: number | null; selfExcludedUntil: string | null; createdAt: string;
}

export function Profile({ initialTab }: { initialTab?: string }) {
  const { refresh } = useMe();
  const [tab, setTab] = useState(initialTab || "details");
  const [p, setP] = useState<P | null>(null);
  const [msg, setMsg] = useState<{ t: string; ok: boolean } | null>(null);
  const load = () => api<{ user: P }>("/api/profile").then((r) => setP(r.user));
  useEffect(() => {
    load();
  }, []);

  const save = async (payload: Record<string, unknown>, okMsg: string) => {
    setMsg(null);
    try {
      await api("/api/profile", { json: payload });
      setMsg({ t: okMsg, ok: true });
      await load();
      refresh();
    } catch (e) {
      setMsg({ t: (e as Error).message, ok: false });
    }
  };

  if (!p) return <div className="p-10 text-center text-slate-500">Loading…</div>;

  return (
    <div className="mx-auto max-w-4xl p-4 sm:p-6">
      <h1 className="text-2xl font-bold text-white">Account settings</h1>
      <p className="mb-5 text-sm text-slate-400">Member since {dateTime(p.createdAt)}</p>
      <div className="mb-5 flex flex-wrap gap-1">
        {[["details", "Personal details"], ["verification", "Verification"], ["security", "Security"], ["limits", "Responsible trading"]].map(([k, l]) => (
          <button key={k} onClick={() => { setTab(k); setMsg(null); }} className={`tab ${tab === k ? "tab-active" : ""}`}>{l}</button>
        ))}
      </div>
      {msg && <p className={`mb-4 rounded-lg px-4 py-2 text-sm ${msg.ok ? "bg-up/10 text-emerald-200" : "bg-down/10 text-red-300"}`}>{msg.t}</p>}
      <div className="card p-5">
        {tab === "details" && <Details p={p} save={save} />}
        {tab === "verification" && <Verification p={p} save={save} />}
        {tab === "security" && <Security save={save} />}
        {tab === "limits" && <Limits p={p} save={save} />}
      </div>
    </div>
  );
}

type Save = (payload: Record<string, unknown>, okMsg: string) => Promise<void>;

function Details({ p, save }: { p: P; save: Save }) {
  const [f, setF] = useState({ fullName: p.fullName, email: p.email ?? "", phone: p.phone ?? "", country: p.country, address: p.address ?? "", dateOfBirth: p.dateOfBirth ?? "" });
  return (
    <form onSubmit={(e) => { e.preventDefault(); save({ action: "update", ...f }, "Profile updated"); }} className="grid gap-4 sm:grid-cols-2">
      <Field label="Full name"><input className="input" value={f.fullName} onChange={(e) => setF({ ...f, fullName: e.target.value })} /></Field>
      <Field label="Country"><input className="input" value={f.country} onChange={(e) => setF({ ...f, country: e.target.value })} /></Field>
      <Field label="Email address"><input className="input" disabled={!!p.email} value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} placeholder="Add an email to log in with it" /></Field>
      <Field label="Phone number"><input className="input" disabled={!!p.phone} value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} placeholder="Add a phone to log in with it" /></Field>
      <Field label="Date of birth"><input type="date" className="input" value={f.dateOfBirth} onChange={(e) => setF({ ...f, dateOfBirth: e.target.value })} /></Field>
      <Field label="Address"><input className="input" value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} /></Field>
      <div className="sm:col-span-2"><button className="btn-brand">Save changes</button></div>
    </form>
  );
}

function Verification({ p, save }: { p: P; save: Save }) {
  const [f, setF] = useState({ docType: p.kycDocType ?? "national_id", docNumber: p.kycDocNumber ?? "", dateOfBirth: p.dateOfBirth ?? "", address: p.address ?? "" });
  const badge: Record<string, string> = { verified: "bg-up/15 text-up", pending: "bg-amber-500/15 text-amber-300", unverified: "bg-down/15 text-down" };
  return (
    <div>
      <div className="mb-5 flex items-center justify-between">
        <div>
          <h2 className="font-semibold text-white">Proof of identity</h2>
          <p className="text-sm text-slate-400">Required for withdrawals under our KYC/AML policy.</p>
        </div>
        <span className={`rounded px-3 py-1 text-xs font-bold uppercase ${badge[p.kycStatus]}`}>{p.kycStatus}</span>
      </div>
      {p.kycStatus === "verified" ? (
        <p className="rounded-lg bg-up/10 p-4 text-sm text-emerald-200">✓ Your identity is verified. All features are unlocked.</p>
      ) : (
        <form onSubmit={(e) => { e.preventDefault(); save({ action: "kyc", ...f }, "Documents submitted. Our team will review them shortly — you can already request withdrawals."); }} className="grid gap-4 sm:grid-cols-2">
          <Field label="Document type">
            <select className="input" value={f.docType} onChange={(e) => setF({ ...f, docType: e.target.value })}>
              <option value="national_id">National ID</option>
              <option value="passport">Passport</option>
              <option value="driving_licence">Driving licence</option>
            </select>
          </Field>
          <Field label="Document number"><input className="input" value={f.docNumber} onChange={(e) => setF({ ...f, docNumber: e.target.value })} /></Field>
          <Field label="Date of birth"><input type="date" className="input" value={f.dateOfBirth} onChange={(e) => setF({ ...f, dateOfBirth: e.target.value })} /></Field>
          <Field label="Residential address"><input className="input" value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} /></Field>
          <div className="sm:col-span-2">
            <label className="label">Document photo (front)</label>
            <input type="file" accept="image/*,.pdf" className="input file:mr-3 file:rounded file:border-0 file:bg-white/10 file:px-3 file:py-1 file:text-white" />
            <p className="mt-1 text-xs text-slate-500">JPG, PNG or PDF, max 8MB. Make sure all corners are visible.</p>
          </div>
          <div className="sm:col-span-2"><button className="btn-brand">{p.kycStatus === "pending" ? "Resubmit documents" : "Submit for verification"}</button></div>
        </form>
      )}
    </div>
  );
}

function Security({ save }: { save: Save }) {
  const [f, setF] = useState({ current: "", next: "", confirm: "" });
  return (
    <form
      onSubmit={async (e) => {
        e.preventDefault();
        if (f.next !== f.confirm) return alert("Passwords do not match");
        await save({ action: "password", current: f.current, next: f.next }, "Password changed successfully");
        setF({ current: "", next: "", confirm: "" });
      }}
      className="grid max-w-md gap-4"
    >
      <h2 className="font-semibold text-white">Change password</h2>
      <Field label="Current password"><input type="password" className="input" value={f.current} onChange={(e) => setF({ ...f, current: e.target.value })} /></Field>
      <Field label="New password"><input type="password" className="input" value={f.next} onChange={(e) => setF({ ...f, next: e.target.value })} /></Field>
      <Field label="Confirm new password"><input type="password" className="input" value={f.confirm} onChange={(e) => setF({ ...f, confirm: e.target.value })} /></Field>
      <div><button className="btn-brand">Update password</button></div>
    </form>
  );
}

function Limits({ p, save }: { p: P; save: Save }) {
  const [f, setF] = useState({ maxStake: p.maxStake?.toString() ?? "", dailyLossLimit: p.dailyLossLimit?.toString() ?? "", selfExcludeDays: "" });
  const excluded = p.selfExcludedUntil && new Date(p.selfExcludedUntil) > new Date();
  return (
    <form onSubmit={(e) => { e.preventDefault(); save({ action: "limits", ...f }, "Trading limits updated"); }} className="grid gap-4 sm:grid-cols-2">
      <div className="sm:col-span-2">
        <h2 className="font-semibold text-white">Responsible trading</h2>
        <p className="text-sm text-slate-400">Trading derivatives is risky. Set personal limits to stay in control.</p>
      </div>
      {excluded && <p className="rounded-lg bg-amber-500/10 p-3 text-sm text-amber-200 sm:col-span-2">You are self-excluded until {dateTime(p.selfExcludedUntil!)}.</p>}
      <Field label="Max stake per contract (USD)"><input className="input" value={f.maxStake} onChange={(e) => setF({ ...f, maxStake: e.target.value })} placeholder="No limit" /></Field>
      <Field label="Daily loss limit — real account (USD)"><input className="input" value={f.dailyLossLimit} onChange={(e) => setF({ ...f, dailyLossLimit: e.target.value })} placeholder="No limit" /></Field>
      <Field label="Self-exclude from trading">
        <select className="input" value={f.selfExcludeDays} onChange={(e) => setF({ ...f, selfExcludeDays: e.target.value })}>
          <option value="">Don&apos;t self-exclude</option>
          <option value="1">24 hours</option>
          <option value="7">7 days</option>
          <option value="30">30 days</option>
          <option value="180">6 months</option>
        </select>
      </Field>
      <div className="sm:col-span-2"><button className="btn-brand">Save limits</button></div>
    </form>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="label">{label}</label>
      {children}
    </div>
  );
}
