"use client";

import { useCallback, useEffect, useState } from "react";
import { formatPrice, getSymbol } from "@/lib/markets";
import { CONTRACT_LABELS } from "@/lib/pricing";
import { api, dateTime, money, signed } from "@/lib/format";
import { useMe } from "./AppShell";
import { ContractDetail, type ClientContract } from "./trade/Positions";

interface TxRow { id: number; type: string; amount: number; balanceAfter: number; description: string | null; reference: string | null; createdAt: string }

function iso(d: Date) {
  return d.toISOString().slice(0, 10);
}

function downloadCsv(name: string, rows: (string | number)[][]) {
  const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
  a.download = name;
  a.click();
}

export function Reports() {
  const { me } = useMe();
  const [tab, setTab] = useState<"open" | "profit" | "statement">("open");
  const [from, setFrom] = useState(iso(new Date(Date.now() - 30 * 86400000)));
  const [to, setTo] = useState(iso(new Date()));
  const [open, setOpen] = useState<ClientContract[]>([]);
  const [profit, setProfit] = useState<{ rows: ClientContract[]; summary: { total: number; won: number; lost: number; staked: number } } | null>(null);
  const [statement, setStatement] = useState<TxRow[]>([]);
  const [detail, setDetail] = useState<ClientContract | null>(null);

  const load = useCallback(async () => {
    if (tab === "open") {
      const r = await api<{ open: ClientContract[] }>("/api/trade/portfolio");
      setOpen(r.open);
    } else if (tab === "profit") {
      setProfit(await api(`/api/reports?type=profit&from=${from}&to=${to}`));
    } else {
      const r = await api<{ rows: TxRow[] }>(`/api/reports?type=statement&from=${from}&to=${to}`);
      setStatement(r.rows);
    }
  }, [tab, from, to]);

  useEffect(() => {
    load().catch(() => {});
    if (tab !== "open") return;
    const id = setInterval(() => load().catch(() => {}), 1500);
    return () => clearInterval(id);
  }, [load, tab, me.active.id]);

  return (
    <div className="mx-auto max-w-7xl p-4 sm:p-6">
      <h1 className="text-2xl font-bold text-white">Reports</h1>
      <p className="mb-5 text-sm text-slate-400">{me.active.type === "demo" ? "Demo" : "Real"} account {me.active.loginId}</p>
      <div className="mb-4 flex flex-wrap items-center gap-2">
        {([["open", "Open positions"], ["profit", "Trade table"], ["statement", "Statement"]] as const).map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className={`tab ${tab === k ? "tab-active" : ""}`}>{l}</button>
        ))}
        {tab !== "open" && (
          <div className="ml-auto flex flex-wrap items-center gap-2">
            <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="input !w-auto !py-1.5" />
            <span className="text-slate-500">→</span>
            <input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="input !w-auto !py-1.5" />
            <button
              className="btn-ghost !py-1.5"
              onClick={() =>
                tab === "statement"
                  ? downloadCsv("statement.csv", [["Date", "Type", "Reference", "Description", "Amount", "Balance"], ...statement.map((r) => [dateTime(r.createdAt), r.type, r.reference ?? "", r.description ?? "", r.amount, r.balanceAfter])])
                  : downloadCsv("trades.csv", [["ID", "Market", "Type", "Stake", "Payout/Sell", "Profit", "Entry", "Exit", "Date"], ...(profit?.rows ?? []).map((c) => [c.id, getSymbol(c.symbol)?.name ?? c.symbol, CONTRACT_LABELS[c.contractType], c.stake, c.sellPrice ?? 0, c.profit ?? 0, c.entrySpot, c.exitSpot ?? "", dateTime(c.createdAt)])])
              }
            >
              Export CSV
            </button>
          </div>
        )}
      </div>

      {tab === "profit" && profit && (
        <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-4">
          <Stat k="Total profit/loss" v={`${signed(profit.summary.total)} USD`} c={profit.summary.total >= 0 ? "text-up" : "text-down"} />
          <Stat k="Won" v={String(profit.summary.won)} c="text-up" />
          <Stat k="Lost" v={String(profit.summary.lost)} c="text-down" />
          <Stat k="Total staked" v={money(profit.summary.staked)} c="text-white" />
        </div>
      )}

      <div className="card overflow-x-auto">
        {tab === "open" && (
          <table className="data w-full min-w-[800px]">
            <thead><tr><th>Ref</th><th>Market</th><th>Type</th><th className="!text-right">Stake</th><th className="!text-right">Entry</th><th className="!text-right">Current</th><th className="!text-right">Value</th><th className="!text-right">P/L</th></tr></thead>
            <tbody>
              {open.length === 0 && <tr><td colSpan={8} className="py-10 text-center text-slate-500">No open positions</td></tr>}
              {open.map((c) => {
                const s = getSymbol(c.symbol)!;
                return (
                  <tr key={c.id} onClick={() => setDetail(c)} className="cursor-pointer hover:bg-white/[0.02]">
                    <td className="text-slate-400">#{c.id}</td>
                    <td className="text-white">{s.name}</td>
                    <td>{CONTRACT_LABELS[c.contractType]}{c.multiplier ? ` x${c.multiplier}` : ""}</td>
                    <td className="text-right tabular-nums">{money(c.stake, false)}</td>
                    <td className="text-right tabular-nums">{formatPrice(c.entrySpot, s.decimals)}</td>
                    <td className="text-right tabular-nums">{formatPrice(c.live?.currentSpot ?? 0, s.decimals)}</td>
                    <td className="text-right tabular-nums">{money(c.live?.currentValue, false)}</td>
                    <td className={`text-right font-semibold tabular-nums ${(c.live?.pnl ?? 0) >= 0 ? "text-up" : "text-down"}`}>{signed(c.live?.pnl)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
        {tab === "profit" && (
          <table className="data w-full min-w-[900px]">
            <thead><tr><th>Ref</th><th>Date</th><th>Market</th><th>Type</th><th className="!text-right">Stake</th><th className="!text-right">Entry</th><th className="!text-right">Exit</th><th className="!text-right">Sell/Payout</th><th className="!text-right">P/L</th></tr></thead>
            <tbody>
              {profit?.rows.length === 0 && <tr><td colSpan={9} className="py-10 text-center text-slate-500">No trades in this period</td></tr>}
              {profit?.rows.map((c) => {
                const s = getSymbol(c.symbol)!;
                return (
                  <tr key={c.id} onClick={() => setDetail(c)} className="cursor-pointer hover:bg-white/[0.02]">
                    <td className="text-slate-400">#{c.id}</td>
                    <td className="whitespace-nowrap text-slate-400">{dateTime(c.createdAt)}</td>
                    <td className="text-white">{s.name}</td>
                    <td>{CONTRACT_LABELS[c.contractType]}</td>
                    <td className="text-right tabular-nums">{money(c.stake, false)}</td>
                    <td className="text-right tabular-nums">{formatPrice(c.entrySpot, s.decimals)}</td>
                    <td className="text-right tabular-nums">{c.exitSpot ? formatPrice(c.exitSpot, s.decimals) : "—"}</td>
                    <td className="text-right tabular-nums">{money(c.sellPrice, false)}</td>
                    <td className={`text-right font-semibold tabular-nums ${(c.profit ?? 0) > 0 ? "text-up" : "text-down"}`}>{signed(c.profit)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
        {tab === "statement" && (
          <table className="data w-full min-w-[800px]">
            <thead><tr><th>Date</th><th>Type</th><th>Reference</th><th>Description</th><th className="!text-right">Amount</th><th className="!text-right">Balance</th></tr></thead>
            <tbody>
              {statement.length === 0 && <tr><td colSpan={6} className="py-10 text-center text-slate-500">No transactions in this period</td></tr>}
              {statement.map((r) => (
                <tr key={r.id}>
                  <td className="whitespace-nowrap text-slate-400">{dateTime(r.createdAt)}</td>
                  <td><span className="rounded bg-white/5 px-2 py-0.5 text-xs capitalize">{r.type}</span></td>
                  <td className="text-slate-400">{r.reference}</td>
                  <td className="text-slate-300">{r.description}</td>
                  <td className={`text-right font-semibold tabular-nums ${r.amount >= 0 ? "text-up" : "text-down"}`}>{signed(r.amount)}</td>
                  <td className="text-right tabular-nums text-white">{money(r.balanceAfter, false)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
      {detail && <ContractDetail c={detail} onClose={() => setDetail(null)} />}
    </div>
  );
}

function Stat({ k, v, c }: { k: string; v: string; c: string }) {
  return (
    <div className="card p-4">
      <div className="text-xs text-slate-500">{k}</div>
      <div className={`mt-1 text-lg font-bold tabular-nums ${c}`}>{v}</div>
    </div>
  );
}
