"use client";

import { useEffect, useRef } from "react";
import {
  AreaSeries,
  CandlestickSeries,
  ColorType,
  CrosshairMode,
  LineStyle,
  createChart,
  type IChartApi,
  type IPriceLine,
  type ISeriesApi,
  type UTCTimestamp,
} from "lightweight-charts";
import { api } from "@/lib/format";

export interface Tick {
  time: number;
  price: number;
}
export interface ChartLine {
  price: number;
  color: string;
  title: string;
  dashed?: boolean;
}

export function PriceChart({
  symbol,
  decimals,
  ticks,
  mode,
  granularity,
  lines,
}: {
  symbol: string;
  decimals: number;
  ticks: Tick[];
  mode: "area" | "candles";
  granularity: number;
  lines: ChartLine[];
}) {
  const el = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const seriesRef = useRef<ISeriesApi<"Area"> | ISeriesApi<"Candlestick"> | null>(null);
  const lastTime = useRef(0);
  const ready = useRef(false);
  const candle = useRef<{ time: number; open: number; high: number; low: number; close: number } | null>(null);
  const priceLines = useRef<IPriceLine[]>([]);
  const ticksRef = useRef(ticks);
  ticksRef.current = ticks;

  useEffect(() => {
    if (!el.current) return;
    const chart = createChart(el.current, {
      autoSize: true,
      layout: { background: { type: ColorType.Solid, color: "transparent" }, textColor: "#8a94a6", attributionLogo: false, fontSize: 11 },
      grid: { vertLines: { color: "rgba(255,255,255,0.03)" }, horzLines: { color: "rgba(255,255,255,0.04)" } },
      rightPriceScale: { borderColor: "rgba(255,255,255,0.08)" },
      timeScale: {
        borderColor: "rgba(255,255,255,0.08)",
        timeVisible: true,
        secondsVisible: true,
        rightOffset: 8,
        tickMarkFormatter: (t: unknown) => new Date(Number(t) * 1000).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
      },
      localization: { timeFormatter: (t: unknown) => new Date(Number(t) * 1000).toLocaleString("en-GB") },
      crosshair: { mode: CrosshairMode.Normal },
    });
    chartRef.current = chart;
    return () => {
      chart.remove();
      chartRef.current = null;
      seriesRef.current = null;
    };
  }, []);

  // (re)create series when symbol / mode / granularity changes
  useEffect(() => {
    const chart = chartRef.current;
    if (!chart) return;
    let cancelled = false;
    ready.current = false;
    if (seriesRef.current) {
      chart.removeSeries(seriesRef.current);
      seriesRef.current = null;
      priceLines.current = [];
    }
    const priceFormat = { type: "price" as const, precision: decimals, minMove: Math.pow(10, -decimals) };
    if (mode === "area") {
      const s = chart.addSeries(AreaSeries, {
        lineColor: "#ff444f",
        topColor: "rgba(255,68,79,0.28)",
        bottomColor: "rgba(255,68,79,0.0)",
        lineWidth: 2,
        priceFormat,
        lastPriceAnimation: 1,
      });
      seriesRef.current = s;
      const cur = ticksRef.current;
      if (cur.length) {
        s.setData(cur.map((t) => ({ time: t.time as UTCTimestamp, value: t.price })));
        lastTime.current = cur[cur.length - 1].time;
        ready.current = true;
        chart.timeScale().setVisibleLogicalRange({ from: Math.max(0, cur.length - 180), to: cur.length + 8 });
      }
    } else {
      const s = chart.addSeries(CandlestickSeries, {
        upColor: "#4bb4b3",
        downColor: "#ec3f3f",
        borderVisible: false,
        wickUpColor: "#4bb4b3",
        wickDownColor: "#ec3f3f",
        priceFormat,
      });
      seriesRef.current = s;
      api<{ candles: { time: number; open: number; high: number; low: number; close: number }[]; time: number }>(
        `/api/market/ticks?symbol=${symbol}&granularity=${granularity}`
      ).then((r) => {
        if (cancelled) return;
        s.setData(r.candles.map((c) => ({ ...c, time: c.time as UTCTimestamp })));
        candle.current = r.candles[r.candles.length - 1] ?? null;
        lastTime.current = r.time;
        ready.current = true;
        chart.timeScale().setVisibleLogicalRange({ from: Math.max(0, r.candles.length - 90), to: r.candles.length + 5 });
      });
    }
    return () => {
      cancelled = true;
    };
  }, [symbol, mode, granularity, decimals]);

  // stream updates
  useEffect(() => {
    const s = seriesRef.current;
    const chart = chartRef.current;
    if (!s || !chart) return;
    if (!ready.current) {
      if (mode === "area" && ticks.length) {
        (s as ISeriesApi<"Area">).setData(ticks.map((t) => ({ time: t.time as UTCTimestamp, value: t.price })));
        lastTime.current = ticks[ticks.length - 1].time;
        ready.current = true;
        chart.timeScale().setVisibleLogicalRange({ from: Math.max(0, ticks.length - 180), to: ticks.length + 8 });
      }
      return;
    }
    for (const t of ticks) {
      if (t.time <= lastTime.current) continue;
      if (mode === "area") {
        (s as ISeriesApi<"Area">).update({ time: t.time as UTCTimestamp, value: t.price });
      } else {
        const bucket = Math.floor(t.time / granularity) * granularity;
        const c = candle.current;
        if (!c || c.time !== bucket) candle.current = { time: bucket, open: c?.close ?? t.price, high: t.price, low: t.price, close: t.price };
        else candle.current = { ...c, high: Math.max(c.high, t.price), low: Math.min(c.low, t.price), close: t.price };
        const n = candle.current;
        (s as ISeriesApi<"Candlestick">).update({ ...n, time: n.time as UTCTimestamp });
      }
      lastTime.current = t.time;
    }
  }, [ticks, mode, granularity]);

  // contract lines
  const linesKey = lines.map((l) => `${l.title}:${l.price}`).join("|");
  useEffect(() => {
    const s = seriesRef.current;
    if (!s) return;
    for (const pl of priceLines.current) {
      try {
        s.removePriceLine(pl);
      } catch {
        /* ignore */
      }
    }
    priceLines.current = lines.map((l) =>
      s.createPriceLine({ price: l.price, color: l.color, lineWidth: 1, lineStyle: l.dashed ? LineStyle.Dashed : LineStyle.Solid, axisLabelVisible: true, title: l.title })
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [linesKey, symbol, mode, granularity]);

  return <div ref={el} className="h-full w-full" />;
}
