"use client";

import { useEffect, useMemo, useState } from "react";
import { MARKETS, SYMBOLS, formatPrice, getSymbol, type MarketKey } from "@/lib/markets";
import type { Quotes } from "../useQuotes";

export function MarketSelector({ symbol, onSelect, quotes }: { symbol: string; onSelect: (s: string) => void; quotes: Quotes }) {
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState<MarketKey | "fav">("synthetic");
  const [q, setQ] = useState("");
  const [favs, setFavs] = useState<string[]>([]);
  const cur = getSymbol(symbol)!;
  const quote = quotes[symbol];

  useEffect(() => {
    try {
      setFavs(JSON.parse(localStorage.getItem("tv_favs") || "[]"));
    } catch {
      /* ignore */
    }
  }, []);

  const toggleFav = (s: string) => {
    const next = favs.includes(s) ? favs.filter((x) => x !== s) : [...favs, s];
    setFavs(next);
    localStorage.setItem("tv_favs", JSON.stringify(next));
  };

  const list = useMemo(() => {
    const term = q.trim().toLowerCase();
    let l = SYMBOLS;
    if (term) l = l.filter((s) => s.name.toLowerCase().includes(term) || s.symbol.toLowerCase().includes(term));
    else if (tab === "fav") l = l.filter((s) => favs.includes(s.symbol));
    else l = l.filter((s) => s.market === tab);
    const groups: Record<string, typeof SYMBOLS> = {};
    for (const s of l) (groups[term ? MARKETS.find((m) => m.key === s.market)!.label : s.submarket] ||= []).push(s);
    return groups;
  }, [q, tab, favs]);

  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)} className="flex items-center gap-3 rounded-lg border border-white/10 bg-ink-850 px-3 py-2 text-left hover:bg-ink-800">
        <SymbolIcon market={cur.market} />
        <div>
          <div className="text-sm font-semibold text-white">{cur.name}</div>
          <div className="text-xs tabular-nums text-slate-400">
            {quote ? formatPrice(quote.price, cur.decimals) : "—"}{" "}
            {quote && <span className={quote.change >= 0 ? "text-up" : "text-down"}>{quote.change >= 0 ? "+" : ""}{quote.change.toFixed(2)}%</span>}
          </div>
        </div>
        <svg width="14" height="14" viewBox="0 0 24 24" className="ml-1 text-slate-400"><path fill="currentColor" d="M7 10l5 5 5-5z" /></svg>
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-40 bg-black/50" onClick={() => setOpen(false)} />
          <div className="absolute left-0 z-50 mt-2 flex max-h-[75vh] w-[min(92vw,720px)] flex-col overflow-hidden rounded-xl border border-white/10 bg-ink-850 shadow-2xl sm:flex-row">
            <div className="flex shrink-0 gap-1 overflow-x-auto border-b border-white/5 p-2 sm:w-48 sm:flex-col sm:border-b-0 sm:border-r">
              <button onClick={() => setTab("fav")} className={`tab whitespace-nowrap text-left ${tab === "fav" ? "tab-active" : ""}`}>★ Favourites</button>
              {MARKETS.map((m) => (
                <button key={m.key} onClick={() => { setTab(m.key); setQ(""); }} className={`tab whitespace-nowrap text-left ${tab === m.key && !q ? "tab-active" : ""}`}>
                  {m.label}
                </button>
              ))}
            </div>
            <div className="flex min-h-0 flex-1 flex-col">
              <div className="border-b border-white/5 p-2">
                <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search markets…" className="input !py-2" />
              </div>
              <div className="min-h-0 flex-1 overflow-y-auto p-2">
                {Object.keys(list).length === 0 && <p className="py-10 text-center text-sm text-slate-500">{tab === "fav" ? "Star markets to add them to favourites" : "No markets found"}</p>}
                {Object.entries(list).map(([g, items]) => (
                  <div key={g} className="mb-3">
                    <p className="px-2 py-1 text-[11px] font-semibold uppercase tracking-wider text-slate-500">{g}</p>
                    {items.map((s) => {
                      const qt = quotes[s.symbol];
                      return (
                        <div key={s.symbol} className={`flex items-center gap-2 rounded-lg px-2 py-2 hover:bg-white/5 ${s.symbol === symbol ? "bg-white/5" : ""}`}>
                          <button onClick={() => toggleFav(s.symbol)} className={`text-sm ${favs.includes(s.symbol) ? "text-amber-400" : "text-slate-600 hover:text-slate-400"}`}>★</button>
                          <button onClick={() => { onSelect(s.symbol); setOpen(false); }} className="flex flex-1 items-center justify-between text-left">
                            <span className="text-sm text-white">{s.name}</span>
                            <span className="text-right text-xs tabular-nums">
                              <span className="text-slate-300">{qt ? formatPrice(qt.price, s.decimals) : "—"}</span>
                              {qt && <span className={`ml-2 inline-block w-14 ${qt.change >= 0 ? "text-up" : "text-down"}`}>{qt.change >= 0 ? "+" : ""}{qt.change.toFixed(2)}%</span>}
                            </span>
                          </button>
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

export function SymbolIcon({ market }: { market: MarketKey }) {
  const map: Record<MarketKey, [string, string]> = {
    synthetic: ["∿", "bg-fuchsia-500/15 text-fuchsia-300"],
    forex: ["¤", "bg-sky-500/15 text-sky-300"],
    indices: ["▲", "bg-indigo-500/15 text-indigo-300"],
    commodities: ["◆", "bg-amber-500/15 text-amber-300"],
    crypto: ["₿", "bg-orange-500/15 text-orange-300"],
    stocks: ["$", "bg-emerald-500/15 text-emerald-300"],
  };
  const [ch, cls] = map[market];
  return <span className={`grid h-8 w-8 shrink-0 place-items-center rounded-lg text-base font-bold ${cls}`}>{ch}</span>;
}
