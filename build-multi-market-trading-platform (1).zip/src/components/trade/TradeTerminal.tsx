"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { formatPrice, getSymbol } from "@/lib/markets";
import type { TradeGroup } from "@/lib/pricing";
import { api, money } from "@/lib/format";
import { useMe } from "../AppShell";
import { useQuotes } from "../useQuotes";
import { MarketSelector } from "./MarketSelector";
import { PriceChart, type ChartLine, type Tick } from "./PriceChart";
import { TradePanel } from "./TradePanel";
import { DigitStats, Positions, type ClientContract } from "./Positions";

const CHART_MODES = [
  { key: "tick", label: "Tick", mode: "area" as const, gran: 0 },
  { key: "1m", label: "1m", mode: "candles" as const, gran: 60 },
  { key: "5m", label: "5m", mode: "candles" as const, gran: 300 },
  { key: "15m", label: "15m", mode: "candles" as const, gran: 900 },
];

interface Toast {
  id: number;
  msg: string;
  kind: "ok" | "err" | "win" | "loss";
}

export function TradeTerminal() {
  const params = useSearchParams();
  const { me, setBalance } = useMe();
  const quotes = useQuotes(2000);
  const [symbol, setSymbolState] = useState(() => (params.get("symbol") && getSymbol(params.get("symbol")!) ? params.get("symbol")! : "1HZ100V"));
  const sym = getSymbol(symbol)!;
  const [ticks, setTicks] = useState<{ symbol: string; list: Tick[] }>({ symbol, list: [] });
  const [chartKey, setChartKey] = useState("tick");
  const [group, setGroup] = useState<TradeGroup>("rise_fall");
  const [digit, setDigit] = useState(5);
  const [portfolio, setPortfolio] = useState<{ open: ClientContract[]; closed: ClientContract[]; time: number }>({ open: [], closed: [], time: 0 });
  const [toasts, setToasts] = useState<Toast[]>([]);
  const prevOpen = useRef<Set<number>>(new Set());
  const firstLoad = useRef(true);

  useEffect(() => {
    if (!params.get("symbol")) {
      const saved = localStorage.getItem("tv_symbol");
      if (saved && getSymbol(saved)) setSymbolState(saved);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const setSymbol = (s: string) => {
    setSymbolState(s);
    localStorage.setItem("tv_symbol", s);
  };

  const toast = useCallback((msg: string, kind: Toast["kind"] = "ok") => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t.slice(-3), { id, msg, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4500);
  }, []);

  // ticks stream
  useEffect(() => {
    let alive = true;
    let last = 0;
    let buf: Tick[] = [];
    let timer: ReturnType<typeof setInterval> | undefined;
    setTicks({ symbol, list: [] });
    api<{ ticks: Tick[]; time: number }>(`/api/market/ticks?symbol=${symbol}&count=1000`).then((r) => {
      if (!alive) return;
      buf = r.ticks;
      last = r.time;
      setTicks({ symbol, list: buf });
      timer = setInterval(async () => {
        try {
          const n = await api<{ ticks: Tick[] }>(`/api/market/ticks?symbol=${symbol}&since=${last}`);
          if (!alive || !n.ticks.length) return;
          buf = [...buf, ...n.ticks].slice(-1000);
          last = n.ticks[n.ticks.length - 1].time;
          setTicks({ symbol, list: buf });
        } catch {
          /* ignore */
        }
      }, 1000);
    });
    return () => {
      alive = false;
      if (timer) clearInterval(timer);
    };
  }, [symbol]);

  const loadPortfolio = useCallback(async () => {
    try {
      const r = await api<{ open: ClientContract[]; closed: ClientContract[]; time: number; balance: number }>("/api/trade/portfolio");
      setPortfolio(r);
      setBalance(r.balance);
      const nowOpen = new Set(r.open.map((c) => c.id));
      if (!firstLoad.current) {
        for (const id of prevOpen.current) {
          if (!nowOpen.has(id)) {
            const c = r.closed.find((x) => x.id === id);
            if (c && c.status !== "sold") {
              const p = c.profit ?? 0;
              toast(p > 0 ? `You won! +${money(p)} on ${getSymbol(c.symbol)?.name}` : `Contract lost: ${money(p)} on ${getSymbol(c.symbol)?.name}`, p > 0 ? "win" : "loss");
            }
          }
        }
      }
      firstLoad.current = false;
      prevOpen.current = nowOpen;
    } catch {
      /* ignore */
    }
  }, [setBalance, toast]);

  useEffect(() => {
    firstLoad.current = true;
    loadPortfolio();
    const id = setInterval(loadPortfolio, 1000);
    return () => clearInterval(id);
  }, [loadPortfolio, me.active.id]);

  const list = ticks.symbol === symbol ? ticks.list : [];
  const spot = list.length ? list[list.length - 1].price : undefined;
  const prevSpot = list.length > 1 ? list[list.length - 2].price : undefined;
  const dir = spot !== undefined && prevSpot !== undefined ? (spot > prevSpot ? "up" : spot < prevSpot ? "down" : "flat") : "flat";
  const cm = CHART_MODES.find((c) => c.key === chartKey)!;
  const isDigits = group === "matches_differs" || group === "even_odd" || group === "over_under";

  const lines: ChartLine[] = [];
  for (const c of portfolio.open.filter((o) => o.symbol === symbol)) {
    lines.push({ price: c.entrySpot, color: "#94a3b8", title: `Entry #${c.id}`, dashed: true });
    if (c.contractType === "ACCU" && c.live?.rangeHigh && c.live.rangeLow) {
      lines.push({ price: c.live.rangeHigh, color: "#f59e0b", title: "Range" }, { price: c.live.rangeLow, color: "#f59e0b", title: "Range" });
    } else if (c.barrier) lines.push({ price: c.barrier, color: "#f59e0b", title: "Barrier" });
    if (c.multiplier) {
      const so = c.contractType === "MULTUP" ? c.entrySpot * (1 - 1 / c.multiplier) : c.entrySpot * (1 + 1 / c.multiplier);
      lines.push({ price: so, color: "#ec3f3f", title: "Stop out", dashed: true });
    }
  }

  const addAlert = async () => {
    const v = window.prompt(`Alert me when ${sym.name} reaches (current ${spot ? formatPrice(spot, sym.decimals) : "—"}):`);
    if (!v) return;
    try {
      await api("/api/alerts", { json: { symbol, price: Number(v) } });
      toast(`Price alert set for ${sym.name} at ${v}`);
    } catch (e) {
      toast((e as Error).message, "err");
    }
  };

  return (
    <div className="flex flex-col lg:h-[calc(100vh-56px)] lg:flex-row">
      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex flex-wrap items-center gap-3 border-b border-white/5 bg-ink-900 px-3 py-2">
          <MarketSelector symbol={symbol} onSelect={setSymbol} quotes={quotes} />
          <div className="flex items-baseline gap-2">
            <span key={spot} className={`rounded px-1 text-xl font-bold tabular-nums ${dir === "up" ? "tick-up text-up" : dir === "down" ? "tick-down text-down" : "text-white"}`}>
              {spot !== undefined ? formatPrice(spot, sym.decimals) : "—"}
            </span>
            {quotes[symbol] && (
              <span className={`text-xs ${quotes[symbol].change >= 0 ? "text-up" : "text-down"}`}>
                {quotes[symbol].change >= 0 ? "+" : ""}
                {quotes[symbol].change.toFixed(2)}%
              </span>
            )}
          </div>
          <div className="ml-auto flex items-center gap-1">
            {CHART_MODES.map((c) => (
              <button key={c.key} onClick={() => setChartKey(c.key)} className={`tab !px-2.5 !py-1 text-xs ${chartKey === c.key ? "tab-active" : ""}`}>
                {c.label}
              </button>
            ))}
            <button onClick={addAlert} title="Price alert" className="tab !px-2.5 !py-1 text-xs">🔔</button>
          </div>
        </div>
        {isDigits && (
          <div className="flex items-center gap-4 border-b border-white/5 bg-ink-900/60 px-3 py-2">
            <span className="hidden text-xs text-slate-500 sm:block">Last digit stats ({list.length} ticks)</span>
            <DigitStats prices={list.map((t) => t.price)} decimals={sym.decimals} selected={group !== "even_odd" ? digit : undefined} />
          </div>
        )}
        <div className="relative h-[380px] bg-ink-950 lg:h-auto lg:min-h-0 lg:flex-[3]">
          <PriceChart symbol={symbol} decimals={sym.decimals} ticks={list} mode={cm.mode} granularity={cm.gran || 60} lines={lines} />
          <div className="pointer-events-none absolute left-3 top-2 text-[11px] text-slate-500">
            {sym.name} · {sym.submarket} · {me.active.type === "demo" ? "Demo" : "Real"} account
          </div>
        </div>
        <div className="h-[340px] border-t border-white/5 bg-ink-900 lg:h-auto lg:min-h-0 lg:flex-[2]">
          <Positions open={portfolio.open} closed={portfolio.closed} now={portfolio.time} onChange={loadPortfolio} toast={toast} />
        </div>
      </div>
      <aside className="w-full shrink-0 overflow-y-auto border-l border-white/5 bg-ink-900 lg:w-[340px]">
        <div className="flex items-center justify-between border-b border-white/5 px-4 py-3">
          <span className="text-sm font-semibold text-white">Place trade</span>
          <span className="text-xs text-slate-400">Balance: <span className="font-semibold text-white">{money(me.active.balance)}</span></span>
        </div>
        {me.active.type === "real" && me.active.balance < 1 && (
          <div className="mx-4 mt-4 rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-200">
            Your real account is empty. <a href="/cashier" className="font-semibold underline">Deposit</a> with USDT, BTC, ETH or M-Pesa, or switch to your demo account.
          </div>
        )}
        <TradePanel sym={sym} spot={spot} group={group} setGroup={setGroup} digit={digit} setDigit={setDigit} onBought={loadPortfolio} toast={toast} />
      </aside>

      <div className="pointer-events-none fixed bottom-4 right-4 z-[60] flex w-80 flex-col gap-2">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`pointer-events-auto rounded-xl border px-4 py-3 text-sm shadow-2xl backdrop-blur ${
              t.kind === "err" ? "border-down/40 bg-down/20 text-red-100" : t.kind === "win" ? "border-up/40 bg-up/20 text-emerald-50" : t.kind === "loss" ? "border-down/30 bg-ink-800/95 text-slate-200" : "border-white/10 bg-ink-800/95 text-slate-100"
            }`}
          >
            {t.msg}
          </div>
        ))}
      </div>
    </div>
  );
}
