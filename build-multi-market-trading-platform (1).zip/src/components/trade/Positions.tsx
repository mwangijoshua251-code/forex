"use client";

import { useState } from "react";
import { formatPrice, getSymbol, lastDigit } from "@/lib/markets";
import { CONTRACT_LABELS } from "@/lib/pricing";
import { api, dateTime, money, signed } from "@/lib/format";

export interface ClientContract {
  id: number;
  symbol: string;
  contractType: string;
  stake: number;
  payout: number | null;
  barrier: number | null;
  barrierLow: number | null;
  digit: number | null;
  durationSec: number | null;
  durationLabel: string | null;
  entrySpot: number;
  entryTime: number;
  expiryTime: number | null;
  exitSpot: number | null;
  exitTime: number | null;
  status: string;
  profit: number | null;
  sellPrice: number | null;
  multiplier: number | null;
  takeProfit: number | null;
  stopLoss: number | null;
  growthRate: number | null;
  commission: number | null;
  createdAt: string;
  live?: {
    done: boolean;
    currentSpot: number;
    currentValue: number;
    pnl: number;
    ticks?: number;
    sellable: boolean;
    rangeHigh?: number;
    rangeLow?: number;
  };
}

export function Positions({
  open,
  closed,
  now,
  onChange,
  toast,
}: {
  open: ClientContract[];
  closed: ClientContract[];
  now: number;
  onChange: () => void;
  toast: (m: string, k?: "ok" | "err") => void;
}) {
  const [tab, setTab] = useState<"open" | "closed">("open");
  const [busy, setBusy] = useState<number | null>(null);
  const [detail, setDetail] = useState<ClientContract | null>(null);
  const totalPnl = open.reduce((s, c) => s + (c.live?.pnl ?? 0), 0);

  const sell = async (c: ClientContract) => {
    setBusy(c.id);
    try {
      const r = await api<{ result: { currentValue: number; sold: boolean } }>("/api/trade/sell", { json: { id: c.id } });
      toast(r.result.sold ? `Contract #${c.id} closed for ${money(r.result.currentValue)}` : `Contract #${c.id} settled`);
      onChange();
    } catch (e) {
      toast((e as Error).message, "err");
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-1 border-b border-white/5 px-3 py-2">
        <button onClick={() => setTab("open")} className={`tab ${tab === "open" ? "tab-active" : ""}`}>Open positions ({open.length})</button>
        <button onClick={() => setTab("closed")} className={`tab ${tab === "closed" ? "tab-active" : ""}`}>Recent closed</button>
        {tab === "open" && open.length > 0 && (
          <span className={`ml-auto text-sm font-semibold tabular-nums ${totalPnl >= 0 ? "text-up" : "text-down"}`}>Total P/L: {signed(totalPnl)}</span>
        )}
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto p-3">
        {tab === "open" && open.length === 0 && <Empty text="No open positions. Pick a market and place your first trade." />}
        {tab === "closed" && closed.length === 0 && <Empty text="No closed contracts yet." />}
        <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
          {tab === "open" &&
            open.map((c) => {
              const s = getSymbol(c.symbol)!;
              const pnl = c.live?.pnl ?? 0;
              const remaining = c.expiryTime ? Math.max(0, c.expiryTime - now) : null;
              const progress = c.expiryTime && c.durationSec ? 1 - remaining! / c.durationSec : null;
              return (
                <div key={c.id} className="rounded-xl border border-white/5 bg-ink-850 p-3">
                  <button onClick={() => setDetail(c)} className="flex w-full items-start justify-between text-left">
                    <div>
                      <div className="text-sm font-semibold text-white">{s.name}</div>
                      <div className="text-xs text-slate-400">
                        {CONTRACT_LABELS[c.contractType]}
                        {c.multiplier ? ` x${c.multiplier}` : ""}
                        {c.growthRate ? ` ${c.growthRate * 100}%` : ""}
                        {c.digit !== null ? ` ${c.digit}` : ""}
                      </div>
                    </div>
                    <div className={`text-right text-sm font-bold tabular-nums ${pnl >= 0 ? "text-up" : "text-down"}`}>
                      {signed(pnl)}
                      <div className="text-[10px] font-normal text-slate-500">P/L USD</div>
                    </div>
                  </button>
                  <div className="mt-2 grid grid-cols-3 gap-2 text-[11px]">
                    <KV k="Stake" v={money(c.stake, false)} />
                    <KV k="Value" v={money(c.live?.currentValue, false)} />
                    <KV k={c.contractType === "ACCU" ? "Ticks" : "Spot"} v={c.contractType === "ACCU" ? String(c.live?.ticks ?? 0) : formatPrice(c.live?.currentSpot ?? 0, s.decimals)} />
                  </div>
                  {progress !== null && (
                    <div className="mt-2">
                      <div className="h-1 overflow-hidden rounded bg-ink-700">
                        <div className="h-full bg-brand transition-all" style={{ width: `${Math.min(100, progress * 100)}%` }} />
                      </div>
                      <div className="mt-1 text-[10px] text-slate-500">{remaining}s remaining · {c.durationLabel}</div>
                    </div>
                  )}
                  {(c.live?.sellable || c.contractType.startsWith("MULT")) && (
                    <button disabled={busy === c.id || !c.live?.sellable} onClick={() => sell(c)} className="btn-ghost mt-2 w-full !py-1.5 text-xs">
                      {busy === c.id ? "Closing…" : c.contractType.startsWith("MULT") || c.contractType === "ACCU" ? `Close ${money(c.live?.currentValue)}` : `Sell ${money(c.live?.currentValue)}`}
                    </button>
                  )}
                </div>
              );
            })}
          {tab === "closed" &&
            closed.map((c) => {
              const s = getSymbol(c.symbol)!;
              const p = c.profit ?? 0;
              return (
                <button key={c.id} onClick={() => setDetail(c)} className="rounded-xl border border-white/5 bg-ink-850 p-3 text-left hover:bg-ink-800">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="text-sm font-semibold text-white">{s.name}</div>
                      <div className="text-xs text-slate-400">{CONTRACT_LABELS[c.contractType]} · #{c.id}</div>
                    </div>
                    <span className={`rounded px-2 py-0.5 text-[10px] font-bold uppercase ${p > 0 ? "bg-up/15 text-up" : "bg-down/15 text-down"}`}>{c.status === "sold" ? "Sold" : p > 0 ? "Won" : "Lost"}</span>
                  </div>
                  <div className="mt-2 flex justify-between text-xs">
                    <span className="text-slate-500">Stake {money(c.stake, false)}</span>
                    <span className={`font-semibold tabular-nums ${p > 0 ? "text-up" : "text-down"}`}>{signed(p)} USD</span>
                  </div>
                </button>
              );
            })}
        </div>
      </div>
      {detail && <ContractDetail c={open.find((o) => o.id === detail.id) ?? closed.find((o) => o.id === detail.id) ?? detail} onClose={() => setDetail(null)} />}
    </div>
  );
}

function KV({ k, v }: { k: string; v: string }) {
  return (
    <div className="rounded-md bg-ink-900 px-2 py-1">
      <div className="text-slate-500">{k}</div>
      <div className="font-semibold tabular-nums text-slate-200">{v}</div>
    </div>
  );
}

function Empty({ text }: { text: string }) {
  return <p className="py-8 text-center text-sm text-slate-500">{text}</p>;
}

export function ContractDetail({ c, onClose }: { c: ClientContract; onClose: () => void }) {
  const s = getSymbol(c.symbol)!;
  const f = (n: number | null | undefined) => (n === null || n === undefined ? "—" : formatPrice(n, s.decimals));
  const rows: [string, string][] = [
    ["Contract ID", `#${c.id}`],
    ["Market", s.name],
    ["Type", CONTRACT_LABELS[c.contractType]],
    ["Stake", money(c.stake)],
  ];
  if (c.payout) rows.push(["Potential payout", money(c.payout)]);
  if (c.multiplier) rows.push(["Multiplier", `x${c.multiplier}`], ["Commission", money(c.commission)]);
  if (c.takeProfit) rows.push(["Take profit", money(c.takeProfit)]);
  if (c.stopLoss) rows.push(["Stop loss", money(c.stopLoss)]);
  if (c.growthRate) rows.push(["Growth rate", `${c.growthRate * 100}%`]);
  if (c.durationLabel) rows.push(["Duration", c.durationLabel]);
  if (c.barrier && c.contractType !== "ACCU") rows.push(["Barrier", f(c.barrier)]);
  if (c.digit !== null) rows.push(["Prediction digit", String(c.digit)]);
  rows.push(["Entry spot", f(c.entrySpot)], ["Start time", dateTime(c.entryTime)]);
  if (c.expiryTime) rows.push(["Expiry time", dateTime(c.expiryTime)]);
  if (c.exitSpot) rows.push(["Exit spot", f(c.exitSpot) + (c.contractType.startsWith("DIGIT") ? ` (digit ${lastDigit(c.exitSpot, s.decimals)})` : "")]);
  if (c.exitTime) rows.push(["Exit time", dateTime(c.exitTime)]);
  if (c.status !== "open") rows.push(["Status", c.status.toUpperCase()], ["Profit/Loss", `${signed(c.profit)} USD`]);
  else if (c.live) rows.push(["Current spot", f(c.live.currentSpot)], ["Indicative value", money(c.live.currentValue)]);
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-4" onClick={onClose}>
      <div className="card w-full max-w-md p-5" onClick={(e) => e.stopPropagation()}>
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-lg font-semibold text-white">Contract details</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white">✕</button>
        </div>
        <div className="divide-y divide-white/5 text-sm">
          {rows.map(([k, v]) => (
            <div key={k} className="flex justify-between py-2">
              <span className="text-slate-400">{k}</span>
              <span className="tabular-nums text-white">{v}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export function DigitStats({ prices, decimals, selected }: { prices: number[]; decimals: number; selected?: number }) {
  const counts = Array(10).fill(0);
  for (const p of prices) counts[lastDigit(p, decimals)]++;
  const total = prices.length || 1;
  const cur = prices.length ? lastDigit(prices[prices.length - 1], decimals) : -1;
  const max = Math.max(...counts);
  const min = Math.min(...counts);
  return (
    <div className="flex items-center gap-1.5 overflow-x-auto">
      {counts.map((c, d) => (
        <div key={d} className="flex flex-col items-center gap-1">
          <div
            className={`grid h-9 w-9 place-items-center rounded-full border-2 text-sm font-bold transition ${
              cur === d ? "scale-110 border-brand bg-brand text-white" : selected === d ? "border-amber-400 text-amber-300" : "border-ink-600 text-slate-300"
            }`}
          >
            {d}
          </div>
          <span className={`text-[10px] tabular-nums ${c === max ? "text-up" : c === min ? "text-down" : "text-slate-500"}`}>{((c / total) * 100).toFixed(1)}%</span>
        </div>
      ))}
    </div>
  );
}
