"use client";

import { useEffect, useMemo, useState } from "react";
import { formatPrice, type SymbolDef } from "@/lib/markets";
import {
  ACCU_MAX_TICKS,
  GROWTH_RATES,
  MULT_COMMISSION,
  TRADE_GROUPS,
  UNIT_LIMITS,
  accuRange,
  availableGroups,
  durationSec,
  quote,
  suggestedOffset,
  unitsFor,
  type DurationUnit,
  type TradeGroup,
} from "@/lib/pricing";
import { api, money } from "@/lib/format";

export function TradePanel({
  sym,
  spot,
  group,
  setGroup,
  digit,
  setDigit,
  onBought,
  toast,
}: {
  sym: SymbolDef;
  spot?: number;
  group: TradeGroup;
  setGroup: (g: TradeGroup) => void;
  digit: number;
  setDigit: (d: number) => void;
  onBought: () => void;
  toast: (msg: string, kind?: "ok" | "err") => void;
}) {
  const groups = availableGroups(sym);
  const units = unitsFor(group, sym);
  const [unit, setUnit] = useState<DurationUnit>(units[0] ?? "t");
  const [duration, setDuration] = useState(5);
  const [stake, setStake] = useState("10");
  const [offset, setOffset] = useState("");
  const [multiplier, setMultiplier] = useState(sym.multipliers[0]);
  const [tpOn, setTpOn] = useState(false);
  const [slOn, setSlOn] = useState(false);
  const [tp, setTp] = useState("");
  const [sl, setSl] = useState("");
  const [growth, setGrowth] = useState(0.03);
  const [busy, setBusy] = useState<string | null>(null);

  useEffect(() => {
    if (!groups.includes(group)) setGroup("rise_fall");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sym.symbol]);

  useEffect(() => {
    if (!units.includes(unit) && units.length) {
      setUnit(units[0]);
      setDuration(units[0] === "t" ? 5 : units[0] === "s" ? 30 : units[0] === "m" ? 5 : 1);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [group, sym.symbol]);

  useEffect(() => {
    setMultiplier(sym.multipliers[0]);
    setOffset("");
  }, [sym.symbol]);

  const T = durationSec(duration, unit);
  const needsBarrier = group === "higher_lower" || group === "touch";
  const defaultOffset = spot ? suggestedOffset(sym, spot, T) : 0;
  const offsetNum = offset === "" ? (group === "touch" || group === "higher_lower" ? defaultOffset : 0) : Number(offset);
  const stakeNum = Number(stake);
  const g = TRADE_GROUPS.find((x) => x.key === group)!;

  const quotes = useMemo(() => {
    if (!spot) return {};
    const out: Record<string, { payout?: number; error?: string }> = {};
    for (const s of g.sides) {
      if (group === "multipliers" || group === "accumulators") continue;
      let off = offsetNum;
      if (group === "higher_lower" && s.type === "LOWER" && offset === "") off = -defaultOffset;
      out[s.type] = quote({ contractType: s.type, stake: stakeNum, spot, sym, durationSec: T, barrierOffset: off, digit });
    }
    return out;
  }, [spot, g, group, offsetNum, stakeNum, sym, T, digit, offset, defaultOffset]);

  const buy = async (contractType: string) => {
    setBusy(contractType);
    try {
      let off = offsetNum;
      if (group === "higher_lower" && contractType === "LOWER" && offset === "") off = -defaultOffset;
      await api("/api/trade/buy", {
        json: {
          symbol: sym.symbol,
          contractType,
          stake: stakeNum,
          duration,
          unit,
          barrierOffset: off,
          digit,
          multiplier,
          takeProfit: tpOn ? Number(tp) : null,
          stopLoss: slOn ? Number(sl) : null,
          growthRate: growth,
        },
      });
      toast(`Contract purchased — ${g.sides.find((s) => s.type === contractType)?.label} on ${sym.name}`);
      onBought();
    } catch (e) {
      toast((e as Error).message, "err");
    } finally {
      setBusy(null);
    }
  };

  const lim = UNIT_LIMITS[unit];
  const accuR = accuRange(growth, sym.sigma);

  return (
    <div className="flex flex-col gap-4 p-4">
      <div>
        <label className="label">Trade type</label>
        <select value={group} onChange={(e) => setGroup(e.target.value as TradeGroup)} className="input">
          {(["Options", "Digits", "Multipliers", "Accumulators"] as const).map((cat) => {
            const items = TRADE_GROUPS.filter((t) => t.category === cat && groups.includes(t.key));
            if (!items.length) return null;
            return (
              <optgroup key={cat} label={cat}>
                {items.map((t) => (
                  <option key={t.key} value={t.key}>{t.label}</option>
                ))}
              </optgroup>
            );
          })}
        </select>
        <p className="mt-2 text-xs leading-relaxed text-slate-500">{g.desc}</p>
      </div>

      {units.length > 0 && (
        <div>
          <label className="label">Duration</label>
          <div className="mb-2 flex gap-1 rounded-lg bg-ink-850 p-1">
            {units.map((u) => (
              <button
                key={u}
                onClick={() => {
                  setUnit(u);
                  setDuration(u === "t" ? 5 : u === "s" ? 30 : u === "m" ? 5 : 1);
                }}
                className={`flex-1 rounded-md py-1.5 text-xs font-medium ${unit === u ? "bg-ink-700 text-white" : "text-slate-400"}`}
              >
                {UNIT_LIMITS[u].label}
              </button>
            ))}
          </div>
          <Stepper value={duration} min={lim.min} max={lim.max} onChange={setDuration} suffix={lim.label.toLowerCase()} />
          {unit === "t" && (
            <input type="range" min={lim.min} max={lim.max} value={duration} onChange={(e) => setDuration(Number(e.target.value))} className="mt-2 w-full accent-[#ff444f]" />
          )}
        </div>
      )}

      {needsBarrier && (
        <div>
          <label className="label">Barrier offset</label>
          <div className="flex items-center gap-2">
            <input
              value={offset === "" ? (defaultOffset ? "+" + defaultOffset.toFixed(sym.decimals) : "") : offset}
              onChange={(e) => setOffset(e.target.value.replace(/[^\d.+-]/g, ""))}
              className="input tabular-nums"
            />
            <button className="btn-ghost !px-3" onClick={() => setOffset(String(-(offsetNum || defaultOffset)))}>±</button>
          </div>
          {spot && (
            <p className="mt-1.5 text-xs text-slate-500">
              Barrier: <span className="tabular-nums text-slate-300">{formatPrice(spot + offsetNum, sym.decimals)}</span>
              {group === "higher_lower" && offset === "" && " (Lower uses the mirrored barrier)"}
            </p>
          )}
        </div>
      )}

      {(group === "matches_differs" || group === "over_under") && (
        <div>
          <label className="label">Last digit prediction</label>
          <div className="grid grid-cols-5 gap-1.5">
            {Array.from({ length: 10 }, (_, d) => (
              <button
                key={d}
                onClick={() => setDigit(d)}
                className={`rounded-lg py-2 text-sm font-semibold ${digit === d ? "bg-brand text-white" : "bg-ink-850 text-slate-300 hover:bg-ink-800"}`}
              >
                {d}
              </button>
            ))}
          </div>
        </div>
      )}

      {group === "multipliers" && (
        <div>
          <label className="label">Multiplier</label>
          <div className="grid grid-cols-4 gap-1.5">
            {sym.multipliers.map((m) => (
              <button key={m} onClick={() => setMultiplier(m)} className={`rounded-lg py-2 text-sm font-semibold ${multiplier === m ? "bg-brand text-white" : "bg-ink-850 text-slate-300 hover:bg-ink-800"}`}>
                x{m}
              </button>
            ))}
          </div>
        </div>
      )}

      {group === "accumulators" && (
        <div>
          <label className="label">Growth rate</label>
          <div className="grid grid-cols-5 gap-1.5">
            {GROWTH_RATES.map((r) => (
              <button key={r} onClick={() => setGrowth(r)} className={`rounded-lg py-2 text-sm font-semibold ${growth === r ? "bg-brand text-white" : "bg-ink-850 text-slate-300 hover:bg-ink-800"}`}>
                {r * 100}%
              </button>
            ))}
          </div>
          <p className="mt-2 text-xs text-slate-500">
            Barrier range: ±{(accuR * 100).toFixed(4)}% per tick · Max {ACCU_MAX_TICKS[growth.toFixed(2)]} ticks
          </p>
        </div>
      )}

      <div>
        <label className="label">Stake (USD)</label>
        <div className="flex items-center gap-2">
          <button className="btn-ghost !px-3" onClick={() => setStake(String(Math.max(0.35, Number((stakeNum - 1).toFixed(2)))))}>−</button>
          <input value={stake} onChange={(e) => setStake(e.target.value.replace(/[^\d.]/g, ""))} className="input text-center font-semibold tabular-nums" />
          <button className="btn-ghost !px-3" onClick={() => setStake(String(Number((stakeNum + 1).toFixed(2))))}>+</button>
        </div>
        <div className="mt-2 flex gap-1.5">
          {[1, 5, 10, 25, 50, 100].map((v) => (
            <button key={v} onClick={() => setStake(String(v))} className="flex-1 rounded-md bg-ink-850 py-1 text-xs text-slate-400 hover:bg-ink-800 hover:text-white">
              {v}
            </button>
          ))}
        </div>
      </div>

      {(group === "multipliers" || group === "accumulators") && (
        <div className="space-y-2">
          <Toggle label="Take profit" on={tpOn} setOn={setTpOn} value={tp} setValue={setTp} />
          {group === "multipliers" && <Toggle label="Stop loss" on={slOn} setOn={setSlOn} value={sl} setValue={setSl} />}
        </div>
      )}

      {group === "multipliers" && spot && stakeNum > 0 && (
        <div className="rounded-lg bg-ink-850 p-3 text-xs text-slate-400">
          <Row k="Commission" v={money(stakeNum * multiplier * MULT_COMMISSION)} />
          <Row k="Exposure" v={money(stakeNum * multiplier)} />
          <Row k="Stop out (Up)" v={formatPrice(spot * (1 - 1 / multiplier), sym.decimals)} />
          <Row k="Stop out (Down)" v={formatPrice(spot * (1 + 1 / multiplier), sym.decimals)} />
        </div>
      )}

      <div className="space-y-2">
        {g.sides.map((s) => {
          const q = quotes[s.type];
          const disabled = !spot || !!busy || !!q?.error || !(stakeNum >= 0.35);
          return (
            <div key={s.type}>
              <button
                onClick={() => buy(s.type)}
                disabled={disabled}
                className={`flex w-full items-center justify-between rounded-xl px-4 py-3 text-left font-semibold text-white transition disabled:opacity-50 ${s.color === "green" ? "bg-up hover:brightness-110" : "bg-down hover:brightness-110"}`}
              >
                <span className="flex items-center gap-2">
                  <span className="text-lg">{s.color === "green" ? "▲" : "▼"}</span>
                  {busy === s.type ? "Purchasing…" : s.label}
                </span>
                {q?.payout && (
                  <span className="text-right">
                    <span className="block text-[10px] font-medium uppercase opacity-80">Payout</span>
                    <span className="text-sm tabular-nums">{money(q.payout)}</span>
                  </span>
                )}
                {group === "multipliers" && <span className="text-sm">x{multiplier}</span>}
                {group === "accumulators" && <span className="text-sm">{growth * 100}% / tick</span>}
              </button>
              {q?.payout && (
                <p className="mt-1 px-1 text-[11px] text-slate-500">
                  Net profit {money(q.payout - stakeNum)} · Return {(((q.payout - stakeNum) / stakeNum) * 100).toFixed(2)}%
                </p>
              )}
              {q?.error && <p className="mt-1 px-1 text-[11px] text-down">{q.error}</p>}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between py-0.5">
      <span>{k}</span>
      <span className="tabular-nums text-slate-200">{v}</span>
    </div>
  );
}

function Stepper({ value, min, max, onChange, suffix }: { value: number; min: number; max: number; onChange: (n: number) => void; suffix: string }) {
  return (
    <div className="flex items-center gap-2">
      <button className="btn-ghost !px-3" onClick={() => onChange(Math.max(min, value - 1))}>−</button>
      <div className="relative flex-1">
        <input
          value={value}
          onChange={(e) => {
            const n = Number(e.target.value.replace(/\D/g, ""));
            onChange(Math.min(max, Math.max(0, n)));
          }}
          onBlur={() => onChange(Math.min(max, Math.max(min, value)))}
          className="input text-center font-semibold tabular-nums"
        />
        <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-500">{suffix}</span>
      </div>
      <button className="btn-ghost !px-3" onClick={() => onChange(Math.min(max, value + 1))}>+</button>
    </div>
  );
}

function Toggle({ label, on, setOn, value, setValue }: { label: string; on: boolean; setOn: (b: boolean) => void; value: string; setValue: (s: string) => void }) {
  return (
    <div className="rounded-lg bg-ink-850 p-3">
      <label className="flex cursor-pointer items-center justify-between text-sm">
        <span>{label}</span>
        <input type="checkbox" checked={on} onChange={(e) => setOn(e.target.checked)} className="h-4 w-4 accent-[#ff444f]" />
      </label>
      {on && <input value={value} onChange={(e) => setValue(e.target.value.replace(/[^\d.]/g, ""))} placeholder="Amount in USD" className="input mt-2 !py-2" />}
    </div>
  );
}
