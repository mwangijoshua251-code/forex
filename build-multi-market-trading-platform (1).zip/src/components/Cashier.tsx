"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { METHOD_LIST, METHODS, type MethodKey } from "@/lib/methods";
import { api, dateTime, money } from "@/lib/format";
import { useMe } from "./AppShell";

interface Rates { USDT: number; BTC: number; ETH: number; KES_DEPOSIT: number; KES_WITHDRAW: number }
interface PaymentRow {
  id: number; kind: string; method: MethodKey; amountUsd: number; feeUsd: number; assetAmount: number | null; assetCurrency: string | null;
  address: string | null; phone: string | null; txHash: string | null; reference: string; confirmations: number; requiredConfirmations: number;
  status: string; note: string | null; createdAt: string;
}

export function StatusBadge({ s }: { s: string }) {
  const cls: Record<string, string> = {
    completed: "bg-up/15 text-up",
    pending: "bg-amber-500/15 text-amber-300",
    processing: "bg-sky-500/15 text-sky-300",
    rejected: "bg-down/15 text-down",
    failed: "bg-down/15 text-down",
    cancelled: "bg-slate-500/15 text-slate-400",
  };
  return <span className={`rounded px-2 py-0.5 text-[10px] font-bold uppercase ${cls[s] ?? "bg-white/10"}`}>{s}</span>;
}

function fmtAsset(amount: number | null, ccy: string | null) {
  if (amount === null || !ccy) return "—";
  if (ccy === "KES") return `KES ${amount.toLocaleString()}`;
  if (ccy === "USDT") return `${amount.toFixed(2)} USDT`;
  return `${amount.toFixed(8)} ${ccy}`;
}

export function Cashier({ initialTab }: { initialTab?: string }) {
  const { me, refresh } = useMe();
  const [tab, setTab] = useState<"deposit" | "withdraw" | "history">((initialTab as "deposit") || "deposit");
  const [method, setMethod] = useState<MethodKey>("USDT_TRC20");
  const [data, setData] = useState<{ rows: PaymentRow[]; rates: Rates; real?: { balance: number; loginId: string }; kycStatus: string; phone: string | null } | null>(null);

  const load = useCallback(async () => {
    try {
      setData(await api("/api/payments"));
    } catch {
      /* ignore */
    }
  }, []);
  useEffect(() => {
    load();
    const id = setInterval(load, 3000);
    return () => clearInterval(id);
  }, [load]);

  const done = () => {
    load();
    refresh();
    setTab("history");
  };

  return (
    <div className="mx-auto max-w-6xl p-4 sm:p-6">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Cashier</h1>
          <p className="text-sm text-slate-400">All funds are held and displayed in USD. Real account {data?.real?.loginId}</p>
        </div>
        <div className="card px-5 py-3 text-right">
          <div className="text-xs uppercase text-slate-500">Real account balance</div>
          <div className="text-2xl font-bold tabular-nums text-white">{money(data?.real?.balance ?? me.accounts.find((a) => a.type === "real")?.balance)}</div>
        </div>
      </div>
      {data && (
        <div className="mb-5 grid grid-cols-2 gap-2 sm:grid-cols-4">
          {[
            ["BTC/USD", data.rates.BTC.toLocaleString("en-US", { maximumFractionDigits: 2 })],
            ["ETH/USD", data.rates.ETH.toLocaleString("en-US", { maximumFractionDigits: 2 })],
            ["USDT/USD", "1.00"],
            ["USD/KES", `${data.rates.KES_DEPOSIT} / ${data.rates.KES_WITHDRAW}`],
          ].map(([k, v]) => (
            <div key={k} className="card px-4 py-2.5">
              <div className="text-[11px] text-slate-500">{k}</div>
              <div className="text-sm font-semibold tabular-nums text-white">{v}</div>
            </div>
          ))}
        </div>
      )}
      <div className="mb-5 flex gap-1">
        {(["deposit", "withdraw", "history"] as const).map((t) => (
          <button key={t} onClick={() => setTab(t)} className={`tab capitalize ${tab === t ? "tab-active" : ""}`}>{t === "history" ? "Transaction history" : t}</button>
        ))}
      </div>

      {tab !== "history" && (
        <div className="grid gap-5 lg:grid-cols-[300px_1fr]">
          <div className="space-y-2">
            {METHOD_LIST.map((m) => (
              <button key={m.key} onClick={() => setMethod(m.key)} className={`card flex w-full items-center gap-3 p-3 text-left transition ${method === m.key ? "!border-brand/60 bg-ink-850" : "hover:bg-ink-850"}`}>
                <span className="grid h-10 w-10 place-items-center rounded-full text-lg font-bold text-white" style={{ background: m.color }}>{m.icon}</span>
                <div className="flex-1">
                  <div className="text-sm font-semibold text-white">{m.label}</div>
                  <div className="text-xs text-slate-500">{m.network} · {m.processing}</div>
                </div>
              </button>
            ))}
          </div>
          <div className="card p-5">
            {data && tab === "deposit" && (method === "MPESA" ? <MpesaDeposit rates={data.rates} phone={data.phone} onDone={done} /> : <CryptoDeposit method={method} rates={data.rates} onDone={done} />)}
            {data && tab === "withdraw" && <Withdraw method={method} rates={data.rates} balance={data.real?.balance ?? 0} kyc={data.kycStatus} phone={data.phone} onDone={done} />}
          </div>
        </div>
      )}

      {tab === "history" && data && <History rows={data.rows} onChange={() => { load(); refresh(); }} />}
    </div>
  );
}

function CryptoDeposit({ method, rates, onDone }: { method: MethodKey; rates: Rates; onDone: () => void }) {
  const m = METHODS[method];
  const [info, setInfo] = useState<{ address: string; qr: string } | null>(null);
  const [amount, setAmount] = useState("");
  const [hash, setHash] = useState("");
  const [copied, setCopied] = useState(false);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    setInfo(null);
    api<{ address: string; qr: string }>(`/api/payments/info?method=${method}`).then(setInfo).catch(() => {});
  }, [method]);
  const rate = m.asset === "USDT" ? 1 : rates[m.asset as "BTC" | "ETH"];
  const usd = Number(amount) || 0;
  const submit = async () => {
    setErr("");
    setBusy(true);
    try {
      await api("/api/payments/deposit", { json: { method, amountUsd: usd, txHash: hash } });
      setAmount("");
      setHash("");
      onDone();
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  const sampleHash = () => {
    const hex = Array.from(crypto.getRandomValues(new Uint8Array(32))).map((b) => b.toString(16).padStart(2, "0")).join("");
    setHash(method === "BTC" || method === "USDT_TRC20" ? hex : "0x" + hex);
  };
  return (
    <div>
      <h2 className="text-lg font-semibold text-white">Deposit {m.label}</h2>
      <p className="mb-4 text-sm text-slate-400">Send {m.asset} to the address below. Your account is credited in USD at the market rate once the transfer reaches {m.confirmations} confirmations.</p>
      <div className="mb-4 rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-200">
        ⚠ Send only <b>{m.asset}</b> on the <b>{m.network}</b> network. Sending any other asset or using another network will result in permanent loss. Minimum deposit: {m.minDeposit} USD.
      </div>
      <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-start">
        <div className="grid h-[180px] w-[180px] shrink-0 place-items-center rounded-xl bg-white p-2">
          {info ? <img src={info.qr} alt="Deposit address QR" className="h-full w-full" /> : <span className="text-xs text-slate-500">Loading…</span>}
        </div>
        <div className="w-full min-w-0 flex-1">
          <label className="label">Your {m.network} deposit address</label>
          <div className="flex gap-2">
            <code className="input block truncate !font-mono text-xs">{info?.address ?? "…"}</code>
            <button
              className="btn-ghost shrink-0"
              onClick={() => {
                if (info) navigator.clipboard?.writeText(info.address);
                setCopied(true);
                setTimeout(() => setCopied(false), 1500);
              }}
            >
              {copied ? "Copied" : "Copy"}
            </button>
          </div>
          <p className="mt-2 text-xs text-slate-500">1 {m.asset} = {rate.toLocaleString("en-US", { maximumFractionDigits: 2 })} USD</p>
        </div>
      </div>
      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <div>
          <label className="label">Amount sent (USD value)</label>
          <input className="input" value={amount} onChange={(e) => setAmount(e.target.value.replace(/[^\d.]/g, ""))} placeholder={`Min ${m.minDeposit}`} />
          <p className="mt-1 text-xs text-slate-500">≈ {m.asset === "USDT" ? usd.toFixed(2) : (usd / rate).toFixed(8)} {m.asset}</p>
        </div>
        <div>
          <label className="label">Transaction hash (TXID)</label>
          <input className="input font-mono text-xs" value={hash} onChange={(e) => setHash(e.target.value.trim())} placeholder="Paste the TXID from your wallet" />
          <button type="button" onClick={sampleHash} className="mt-1 text-xs text-slate-500 underline hover:text-slate-300">Testing? Generate a sample TXID</button>
        </div>
      </div>
      {err && <p className="mt-3 rounded-lg bg-down/10 px-3 py-2 text-sm text-red-300">{err}</p>}
      <button disabled={busy || !usd || !hash} onClick={submit} className="btn-brand mt-5 w-full sm:w-auto">{busy ? "Submitting…" : "I've sent the payment"}</button>
    </div>
  );
}

function MpesaDeposit({ rates, phone, onDone }: { rates: Rates; phone: string | null; onDone: () => void }) {
  const [tel, setTel] = useState(phone ? "0" + phone.replace(/^\+254/, "") : "");
  const [kes, setKes] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState<string | null>(null);
  const k = Number(kes) || 0;
  const submit = async () => {
    setErr("");
    setBusy(true);
    try {
      const r = await api<{ payment: { reference: string } }>("/api/payments/deposit", { json: { method: "MPESA", amountKes: k, phone: tel } });
      setSent(r.payment.reference);
      setTimeout(onDone, 2500);
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <div>
      <h2 className="text-lg font-semibold text-white">Deposit with M-Pesa</h2>
      <p className="mb-4 text-sm text-slate-400">Pay in Kenyan Shillings — your real account is credited in USD instantly at 1 USD = {rates.KES_DEPOSIT} KES.</p>
      {sent ? (
        <div className="rounded-xl border border-up/30 bg-up/10 p-5 text-center">
          <div className="text-3xl">📱</div>
          <p className="mt-2 font-semibold text-white">Check your phone</p>
          <p className="text-sm text-slate-300">An M-Pesa prompt has been sent to {tel}. Enter your PIN to complete the payment of KES {k.toLocaleString()}.</p>
          <p className="mt-2 text-xs text-slate-500">Reference {sent}</p>
        </div>
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="label">M-Pesa phone number</label>
              <input className="input" value={tel} onChange={(e) => setTel(e.target.value)} placeholder="0712 345 678" />
            </div>
            <div>
              <label className="label">Amount (KES)</label>
              <input className="input" value={kes} onChange={(e) => setKes(e.target.value.replace(/\D/g, ""))} placeholder="100 – 150,000" />
              <p className="mt-1 text-xs text-slate-500">You will receive ≈ <b className="text-white">{money(k / rates.KES_DEPOSIT)}</b></p>
            </div>
          </div>
          <div className="mt-3 flex gap-2">
            {[500, 1000, 2500, 5000, 10000].map((v) => (
              <button key={v} onClick={() => setKes(String(v))} className="flex-1 rounded-md bg-ink-850 py-1.5 text-xs text-slate-400 hover:bg-ink-800 hover:text-white">{v.toLocaleString()}</button>
            ))}
          </div>
          {err && <p className="mt-3 rounded-lg bg-down/10 px-3 py-2 text-sm text-red-300">{err}</p>}
          <button disabled={busy || !k || !tel} onClick={submit} className="btn-brand mt-5 w-full !bg-[#4caf50] hover:!brightness-110 sm:w-auto">{busy ? "Sending request…" : "Pay with M-Pesa"}</button>
          <div className="mt-6 rounded-lg bg-ink-850 p-4 text-xs text-slate-400">
            <p className="font-semibold text-slate-300">How it works</p>
            <ol className="mt-2 list-decimal space-y-1 pl-4">
              <li>Enter your Safaricom number and the amount in KES.</li>
              <li>You&apos;ll receive an STK push prompt on your phone.</li>
              <li>Enter your M-Pesa PIN — funds reflect in USD within seconds.</li>
            </ol>
          </div>
        </>
      )}
    </div>
  );
}

function Withdraw({ method, rates, balance, kyc, phone, onDone }: { method: MethodKey; rates: Rates; balance: number; kyc: string; phone: string | null; onDone: () => void }) {
  const m = METHODS[method];
  const [amount, setAmount] = useState("");
  const [dest, setDest] = useState("");
  const [pw, setPw] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    setDest(method === "MPESA" && phone ? "0" + phone.replace(/^\+254/, "") : "");
  }, [method, phone]);
  const usd = Number(amount) || 0;
  const net = Math.max(0, usd - m.withdrawFee);
  const receive = m.asset === "KES" ? `KES ${Math.round(net * rates.KES_WITHDRAW).toLocaleString()}` : m.asset === "USDT" ? `${net.toFixed(2)} USDT` : `${(net / rates[m.asset as "BTC" | "ETH"]).toFixed(8)} ${m.asset}`;
  if (kyc === "unverified") {
    return (
      <div className="py-6 text-center">
        <div className="text-4xl">🪪</div>
        <h2 className="mt-3 text-lg font-semibold text-white">Verify your identity to withdraw</h2>
        <p className="mx-auto mt-1 max-w-md text-sm text-slate-400">To protect your funds and comply with AML regulations, please submit your identity documents before making a withdrawal.</p>
        <Link href="/profile?tab=verification" className="btn-brand mt-5">Verify now</Link>
      </div>
    );
  }
  const submit = async () => {
    setErr("");
    setBusy(true);
    try {
      await api("/api/payments/withdraw", { json: { method, amountUsd: usd, address: method === "MPESA" ? undefined : dest, phone: method === "MPESA" ? dest : undefined, password: pw } });
      setAmount("");
      setPw("");
      onDone();
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <div>
      <h2 className="text-lg font-semibold text-white">Withdraw via {m.label}</h2>
      <p className="mb-4 text-sm text-slate-400">Available: <b className="text-white">{money(balance)}</b> · Min {m.minWithdraw} USD · Fee {money(m.withdrawFee)}</p>
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <label className="label">{method === "MPESA" ? "M-Pesa phone number" : `${m.asset} address (${m.network})`}</label>
          <input className="input font-mono text-sm" value={dest} onChange={(e) => setDest(e.target.value.trim())} placeholder={method === "MPESA" ? "0712 345 678" : method === "BTC" ? "bc1q…" : method === "USDT_TRC20" ? "T…" : "0x…"} />
        </div>
        <div>
          <label className="label">Amount (USD)</label>
          <div className="relative">
            <input className="input pr-14" value={amount} onChange={(e) => setAmount(e.target.value.replace(/[^\d.]/g, ""))} />
            <button onClick={() => setAmount(String(balance))} className="absolute right-2 top-1/2 -translate-y-1/2 rounded bg-white/10 px-2 py-0.5 text-[10px] font-bold">MAX</button>
          </div>
          <p className="mt-1 text-xs text-slate-500">You will receive ≈ <b className="text-white">{receive}</b></p>
        </div>
        <div>
          <label className="label">Confirm with password</label>
          <input className="input" type="password" value={pw} onChange={(e) => setPw(e.target.value)} />
        </div>
      </div>
      {err && <p className="mt-3 rounded-lg bg-down/10 px-3 py-2 text-sm text-red-300">{err}</p>}
      <button disabled={busy || !usd || !dest || !pw} onClick={submit} className="btn-brand mt-5 w-full sm:w-auto">{busy ? "Submitting…" : "Request withdrawal"}</button>
      <p className="mt-4 text-xs text-slate-500">Withdrawals are reviewed by our payments team and usually processed within 24 hours. Funds are held from your balance while pending; you can cancel a pending request at any time.</p>
    </div>
  );
}

function History({ rows, onChange }: { rows: PaymentRow[]; onChange: () => void }) {
  const cancel = async (id: number) => {
    if (!confirm("Cancel this withdrawal? Funds will be returned to your balance.")) return;
    try {
      await api("/api/payments/cancel", { json: { id } });
      onChange();
    } catch (e) {
      alert((e as Error).message);
    }
  };
  if (!rows.length) return <div className="card p-10 text-center text-sm text-slate-500">No deposits or withdrawals yet.</div>;
  return (
    <div className="card overflow-x-auto">
      <table className="data w-full min-w-[860px]">
        <thead>
          <tr><th>Date</th><th>Type</th><th>Method</th><th className="!text-right">USD</th><th>Asset</th><th>Status</th><th>Reference / TX</th><th /></tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.id}>
              <td className="whitespace-nowrap text-slate-400">{dateTime(r.createdAt)}</td>
              <td className="capitalize">{r.kind}</td>
              <td>{METHODS[r.method]?.label}</td>
              <td className={`text-right font-semibold tabular-nums ${r.kind === "deposit" ? "text-up" : "text-down"}`}>{r.kind === "deposit" ? "+" : "−"}{money(r.amountUsd, false)}</td>
              <td className="tabular-nums text-slate-300">{fmtAsset(r.assetAmount, r.assetCurrency)}</td>
              <td>
                <StatusBadge s={r.status} />
                {r.requiredConfirmations > 0 && r.status === "pending" && (
                  <div className="mt-1 w-28">
                    <div className="h-1 rounded bg-ink-700"><div className="h-1 rounded bg-amber-400" style={{ width: `${(r.confirmations / r.requiredConfirmations) * 100}%` }} /></div>
                    <div className="text-[10px] text-slate-500">{r.confirmations}/{r.requiredConfirmations} confirmations</div>
                  </div>
                )}
                {r.note && r.status !== "completed" && <div className="mt-0.5 max-w-[200px] text-[10px] text-slate-500">{r.note}</div>}
              </td>
              <td className="max-w-[220px]">
                <div className="text-xs text-slate-300">{r.reference}</div>
                {r.txHash && <div className="truncate font-mono text-[10px] text-slate-500" title={r.txHash}>{r.txHash}</div>}
                {(r.address || r.phone) && <div className="truncate font-mono text-[10px] text-slate-600">{r.address || r.phone}</div>}
              </td>
              <td>{r.kind === "withdrawal" && r.status === "pending" && <button onClick={() => cancel(r.id)} className="text-xs text-brand hover:underline">Cancel</button>}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
