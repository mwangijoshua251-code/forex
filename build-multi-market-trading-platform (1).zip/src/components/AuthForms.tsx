"use client";

import Link from "next/link";
import { useState, type ReactNode } from "react";
import { api } from "@/lib/format";
import { Logo } from "./AppShell";

const COUNTRIES = ["Kenya", "Uganda", "Tanzania", "Rwanda", "Nigeria", "Ghana", "South Africa", "Zambia", "Ethiopia", "United Arab Emirates", "India", "Other"];

function Shell({ title, sub, children }: { title: string; sub: string; children: ReactNode }) {
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="relative hidden overflow-hidden bg-gradient-to-br from-ink-900 via-ink-950 to-[#2a0d12] p-12 lg:flex lg:flex-col">
        <Link href="/"><Logo /></Link>
        <div className="my-auto max-w-md">
          <h2 className="text-4xl font-extrabold leading-tight text-white">Trade the world&apos;s markets <span className="text-brand">24/7</span></h2>
          <p className="mt-4 text-slate-400">Derived indices, forex, stock indices, commodities, crypto and stocks — with options, multipliers and accumulators from just 0.35 USD.</p>
          <ul className="mt-8 space-y-3 text-sm text-slate-300">
            {["10,000 USD free demo account", "Deposit & withdraw via USDT, BTC, ETH and M-Pesa", "All balances held in USD", "Over 60 instruments across 6 markets"].map((t) => (
              <li key={t} className="flex items-center gap-3"><span className="grid h-5 w-5 place-items-center rounded-full bg-brand/20 text-xs text-brand">✓</span>{t}</li>
            ))}
          </ul>
        </div>
        <p className="text-xs text-slate-600">Trading involves risk. Only trade with money you can afford to lose.</p>
        <svg className="absolute -bottom-10 right-0 opacity-30" width="600" height="260" viewBox="0 0 600 260"><path d="M0 220 L60 190 L110 205 L170 140 L230 160 L290 100 L350 120 L410 60 L470 90 L530 30 L600 50" fill="none" stroke="#ff444f" strokeWidth="3" /></svg>
      </div>
      <div className="flex items-center justify-center p-6">
        <div className="w-full max-w-md">
          <div className="mb-8 lg:hidden"><Link href="/"><Logo /></Link></div>
          <h1 className="text-2xl font-bold text-white">{title}</h1>
          <p className="mb-6 mt-1 text-sm text-slate-400">{sub}</p>
          {children}
        </div>
      </div>
    </div>
  );
}

function MethodTabs({ value, onChange }: { value: "email" | "phone"; onChange: (v: "email" | "phone") => void }) {
  return (
    <div className="mb-5 grid grid-cols-2 gap-1 rounded-lg bg-ink-850 p-1">
      {(["email", "phone"] as const).map((m) => (
        <button key={m} type="button" onClick={() => onChange(m)} className={`rounded-md py-2 text-sm font-medium ${value === m ? "bg-ink-700 text-white" : "text-slate-400"}`}>
          {m === "email" ? "Email" : "Phone number"}
        </button>
      ))}
    </div>
  );
}

export function LoginForm() {
  const [method, setMethod] = useState<"email" | "phone">("email");
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    setBusy(true);
    try {
      await api("/api/auth/login", { json: { identifier, password } });
      window.location.href = "/trade";
    } catch (e) {
      setErr((e as Error).message);
      setBusy(false);
    }
  };
  return (
    <Shell title="Welcome back" sub="Log in with your email address or phone number.">
      <MethodTabs value={method} onChange={(m) => { setMethod(m); setIdentifier(""); }} />
      <form onSubmit={submit} className="space-y-4">
        <div>
          <label className="label">{method === "email" ? "Email address" : "Phone number"}</label>
          <input className="input" type={method === "email" ? "email" : "tel"} required value={identifier} onChange={(e) => setIdentifier(e.target.value)} placeholder={method === "email" ? "you@example.com" : "0712 345 678 or +254712345678"} autoComplete="username" />
        </div>
        <div>
          <label className="label">Password</label>
          <div className="relative">
            <input className="input pr-16" type={show ? "text" : "password"} required value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" />
            <button type="button" onClick={() => setShow(!show)} className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400">{show ? "Hide" : "Show"}</button>
          </div>
        </div>
        {err && <p className="rounded-lg bg-down/10 px-3 py-2 text-sm text-red-300">{err}</p>}
        <button disabled={busy} className="btn-brand w-full !py-3">{busy ? "Logging in…" : "Log in"}</button>
      </form>
      <p className="mt-6 text-center text-sm text-slate-400">
        Don&apos;t have an account? <Link href="/register" className="font-semibold text-brand">Sign up free</Link>
      </p>
    </Shell>
  );
}

export function RegisterForm() {
  const [method, setMethod] = useState<"email" | "phone">("email");
  const [f, setF] = useState({ fullName: "", email: "", phone: "", password: "", country: "Kenya", acceptTerms: false });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f, v: string | boolean) => setF((x) => ({ ...x, [k]: v }));
  const strength = [/.{8,}/, /[A-Z]/, /[a-z]/, /\d/, /[^A-Za-z0-9]/].filter((r) => r.test(f.password)).length;
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    setBusy(true);
    try {
      await api("/api/auth/register", { json: { ...f, email: method === "email" ? f.email : "", phone: method === "phone" ? f.phone : "" } });
      window.location.href = "/hub?welcome=1";
    } catch (e) {
      setErr((e as Error).message);
      setBusy(false);
    }
  };
  return (
    <Shell title="Create your free account" sub="Get a 10,000 USD demo account instantly, plus a real USD account.">
      <MethodTabs value={method} onChange={setMethod} />
      <form onSubmit={submit} className="space-y-4">
        <div>
          <label className="label">Full name</label>
          <input className="input" required value={f.fullName} onChange={(e) => set("fullName", e.target.value)} placeholder="As shown on your ID" />
        </div>
        {method === "email" ? (
          <div>
            <label className="label">Email address</label>
            <input className="input" type="email" required value={f.email} onChange={(e) => set("email", e.target.value)} placeholder="you@example.com" />
          </div>
        ) : (
          <div>
            <label className="label">Phone number</label>
            <input className="input" type="tel" required value={f.phone} onChange={(e) => set("phone", e.target.value)} placeholder="0712 345 678 or +254712345678" />
          </div>
        )}
        <div>
          <label className="label">Country of residence</label>
          <select className="input" value={f.country} onChange={(e) => set("country", e.target.value)}>
            {COUNTRIES.map((c) => <option key={c}>{c}</option>)}
          </select>
        </div>
        <div>
          <label className="label">Password</label>
          <input className="input" type="password" required value={f.password} onChange={(e) => set("password", e.target.value)} autoComplete="new-password" />
          <div className="mt-2 flex gap-1">
            {[0, 1, 2, 3, 4].map((i) => (
              <div key={i} className={`h-1 flex-1 rounded ${i < strength ? (strength >= 4 ? "bg-up" : strength >= 3 ? "bg-amber-400" : "bg-down") : "bg-ink-700"}`} />
            ))}
          </div>
          <p className="mt-1 text-xs text-slate-500">At least 8 characters with letters and numbers.</p>
        </div>
        <label className="flex items-start gap-2 text-xs text-slate-400">
          <input type="checkbox" checked={f.acceptTerms} onChange={(e) => set("acceptTerms", e.target.checked)} className="mt-0.5 accent-[#ff444f]" />
          I am over 18, and I accept the terms & conditions and acknowledge that trading derivatives carries a high level of risk.
        </label>
        {err && <p className="rounded-lg bg-down/10 px-3 py-2 text-sm text-red-300">{err}</p>}
        <button disabled={busy} className="btn-brand w-full !py-3">{busy ? "Creating account…" : "Create account"}</button>
      </form>
      <p className="mt-6 text-center text-sm text-slate-400">
        Already have an account? <Link href="/login" className="font-semibold text-brand">Log in</Link>
      </p>
    </Shell>
  );
}
