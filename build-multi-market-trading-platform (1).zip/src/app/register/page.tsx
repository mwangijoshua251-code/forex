import { redirect } from "next/navigation";
import { getAuth } from "@/lib/auth";
import { RegisterForm } from "@/components/AuthForms";

export const dynamic = "force-dynamic";

export default async function RegisterPage() {
  if (await getAuth()) redirect("/trade");
  return <RegisterForm />;
}
