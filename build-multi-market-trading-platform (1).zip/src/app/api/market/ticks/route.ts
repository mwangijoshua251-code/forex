import { route } from "@/lib/api";
import { getEngine } from "@/lib/engine";
import { HttpError } from "@/lib/auth";
import { getSymbol } from "@/lib/markets";

export const dynamic = "force-dynamic";

export const GET = route(async (req) => {
  const url = new URL(req.url);
  const symbol = url.searchParams.get("symbol") || "";
  if (!getSymbol(symbol)) throw new HttpError(400, "Unknown symbol");
  const eng = getEngine();
  const gran = Number(url.searchParams.get("granularity") || 0);
  if (gran > 0) {
    const all = eng.history(symbol, 14400);
    const candles: { time: number; open: number; high: number; low: number; close: number }[] = [];
    for (const t of all) {
      const bucket = Math.floor(t.time / gran) * gran;
      const last = candles[candles.length - 1];
      if (!last || last.time !== bucket) candles.push({ time: bucket, open: t.price, high: t.price, low: t.price, close: t.price });
      else {
        last.high = Math.max(last.high, t.price);
        last.low = Math.min(last.low, t.price);
        last.close = t.price;
      }
    }
    return Response.json({ symbol, time: eng.lastTime, candles });
  }
  const since = Number(url.searchParams.get("since") || 0);
  const count = Math.min(14400, Number(url.searchParams.get("count") || 600));
  const ticks = since > 0 ? eng.range(symbol, since + 1, eng.lastTime) : eng.history(symbol, count);
  return Response.json({ symbol, time: eng.lastTime, ticks });
});
