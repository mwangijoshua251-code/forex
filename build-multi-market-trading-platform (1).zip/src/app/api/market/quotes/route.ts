import { route } from "@/lib/api";
import { getEngine } from "@/lib/engine";

export const dynamic = "force-dynamic";

export const GET = route(async () => {
  const eng = getEngine();
  return Response.json({ time: eng.lastTime, quotes: eng.quotes() });
});
