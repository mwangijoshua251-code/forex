import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { body, route } from "@/lib/api";
import { createAccountsFor, createSession, ensureAdmin, hashPassword, HttpError, isEmail, normalizePhone } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const POST = route(async (req) => {
  await ensureAdmin().catch(() => {});
  const b = await body<{ fullName?: string; email?: string; phone?: string; password?: string; country?: string; method?: string; acceptTerms?: boolean }>(req);
  const fullName = (b.fullName || "").trim();
  if (fullName.length < 2) throw new HttpError(400, "Enter your full name");
  const password = b.password || "";
  if (password.length < 8 || !/[A-Za-z]/.test(password) || !/\d/.test(password))
    throw new HttpError(400, "Password must be at least 8 characters and include letters and numbers");
  if (!b.acceptTerms) throw new HttpError(400, "You must accept the terms and conditions");
  let email: string | null = null;
  let phone: string | null = null;
  if (b.email && b.email.trim()) {
    email = b.email.trim().toLowerCase();
    if (!isEmail(email)) throw new HttpError(400, "Enter a valid email address");
    const ex = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    if (ex.length) throw new HttpError(409, "An account with this email already exists");
  }
  if (b.phone && b.phone.trim()) {
    phone = normalizePhone(b.phone);
    if (!/^\+\d{9,15}$/.test(phone)) throw new HttpError(400, "Enter a valid phone number");
    const ex = await db.select({ id: users.id }).from(users).where(eq(users.phone, phone)).limit(1);
    if (ex.length) throw new HttpError(409, "An account with this phone number already exists");
  }
  if (!email && !phone) throw new HttpError(400, "Provide an email address or phone number");
  const [u] = await db
    .insert(users)
    .values({ fullName, email, phone, passwordHash: hashPassword(password), country: b.country || "Kenya" })
    .returning();
  const { demo } = await createAccountsFor(u.id);
  await createSession(u.id, demo.id);
  return Response.json({ ok: true });
});
