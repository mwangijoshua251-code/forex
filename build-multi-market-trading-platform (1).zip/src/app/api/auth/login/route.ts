import { eq } from "drizzle-orm";
import { db } from "@/db";
import { accounts, users } from "@/db/schema";
import { body, route } from "@/lib/api";
import { createAccountsFor, createSession, ensureAdmin, HttpError, isEmail, normalizePhone, verifyPassword } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const POST = route(async (req) => {
  await ensureAdmin().catch(() => {});
  const b = await body<{ identifier?: string; password?: string }>(req);
  const id = (b.identifier || "").trim();
  if (!id || !b.password) throw new HttpError(400, "Enter your email/phone and password");
  const cond = isEmail(id) ? eq(users.email, id.toLowerCase()) : eq(users.phone, normalizePhone(id));
  const [u] = await db.select().from(users).where(cond).limit(1);
  if (!u || !verifyPassword(b.password, u.passwordHash)) throw new HttpError(401, "Incorrect login details");
  if (u.disabled) throw new HttpError(403, "Your account has been disabled. Contact support.");
  let accs = await db.select().from(accounts).where(eq(accounts.userId, u.id));
  if (!accs.length) {
    await createAccountsFor(u.id);
    accs = await db.select().from(accounts).where(eq(accounts.userId, u.id));
  }
  const active = accs.find((a) => a.type === "demo") ?? accs[0];
  await createSession(u.id, active.id);
  return Response.json({ ok: true, role: u.role });
});
