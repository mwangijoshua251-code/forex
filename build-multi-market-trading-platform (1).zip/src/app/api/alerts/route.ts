import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { priceAlerts } from "@/db/schema";
import { body, route } from "@/lib/api";
import { HttpError, requireAuth } from "@/lib/auth";
import { getSymbol } from "@/lib/markets";
import { getEngine } from "@/lib/engine";

export const dynamic = "force-dynamic";

export const GET = route(async () => {
  const a = await requireAuth();
  const rows = await db.select().from(priceAlerts).where(eq(priceAlerts.userId, a.user.id)).orderBy(desc(priceAlerts.id)).limit(50);
  return Response.json({ rows });
});

export const POST = route(async (req) => {
  const a = await requireAuth();
  const b = await body<{ action?: string; id?: number; symbol?: string; price?: number }>(req);
  if (b.action === "delete") {
    await db.delete(priceAlerts).where(and(eq(priceAlerts.id, Number(b.id)), eq(priceAlerts.userId, a.user.id)));
    return Response.json({ ok: true });
  }
  const s = getSymbol(b.symbol || "");
  const price = Number(b.price);
  if (!s || !(price > 0)) throw new HttpError(400, "Choose a market and a valid price");
  const cur = getEngine().latest(s.symbol)!.price;
  const [row] = await db
    .insert(priceAlerts)
    .values({ userId: a.user.id, symbol: s.symbol, price, direction: price >= cur ? "above" : "below" })
    .returning();
  return Response.json({ ok: true, alert: row });
});
