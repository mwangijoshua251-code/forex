import { body, route } from "@/lib/api";
import { requireAuth } from "@/lib/auth";
import { cancelWithdrawal } from "@/lib/payments";

export const dynamic = "force-dynamic";

export const POST = route(async (req) => {
  const a = await requireAuth();
  const b = await body<{ id: number }>(req);
  const p = await cancelWithdrawal(a, Number(b.id));
  return Response.json({ ok: true, payment: p });
});
