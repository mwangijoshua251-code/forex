import QRCode from "qrcode";
import { route } from "@/lib/api";
import { HttpError, requireAuth } from "@/lib/auth";
import { METHODS, type MethodKey } from "@/lib/methods";
import { depositAddress, rates } from "@/lib/payments";
import { mpesaConfigured } from "@/lib/mpesa";

export const dynamic = "force-dynamic";

export const GET = route(async (req) => {
  const a = await requireAuth();
  const method = new URL(req.url).searchParams.get("method") as MethodKey;
  const m = METHODS[method];
  if (!m) throw new HttpError(400, "Unknown method");
  if (method === "MPESA") {
    return Response.json({ method: m, rates: rates(), live: mpesaConfigured(), paybill: process.env.MPESA_SHORTCODE || "4087321" });
  }
  const address = depositAddress(a.user.id, method);
  const qr = await QRCode.toDataURL(address, { margin: 1, width: 220 });
  return Response.json({ method: m, address, qr, rates: rates() });
});
