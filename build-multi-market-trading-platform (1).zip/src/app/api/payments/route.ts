import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { payments } from "@/db/schema";
import { route } from "@/lib/api";
import { requireAuth } from "@/lib/auth";
import { rates } from "@/lib/payments";

export const dynamic = "force-dynamic";

export const GET = route(async () => {
  const a = await requireAuth();
  const rows = await db.select().from(payments).where(eq(payments.userId, a.user.id)).orderBy(desc(payments.id)).limit(100);
  const real = a.accounts.find((x) => x.type === "real");
  return Response.json({ rows, rates: rates(), real, kycStatus: a.user.kycStatus, phone: a.user.phone });
});
