import { eq } from "drizzle-orm";
import { db } from "@/db";
import { payments } from "@/db/schema";
import { body, route } from "@/lib/api";
import { completeDeposit, failPayment } from "@/lib/payments";

export const dynamic = "force-dynamic";

type Cb = {
  Body?: {
    stkCallback?: {
      CheckoutRequestID: string;
      ResultCode: number;
      ResultDesc: string;
      CallbackMetadata?: { Item: { Name: string; Value?: string | number }[] };
    };
  };
};

export const POST = route(async (req) => {
  const b = await body<Cb>(req);
  const cb = b.Body?.stkCallback;
  if (!cb) return Response.json({ ResultCode: 0, ResultDesc: "Ignored" });
  const [p] = await db.select().from(payments).where(eq(payments.txHash, cb.CheckoutRequestID)).limit(1);
  if (p) {
    if (cb.ResultCode === 0) {
      const receipt = cb.CallbackMetadata?.Item.find((i) => i.Name === "MpesaReceiptNumber")?.Value;
      await completeDeposit(p.id, { txHash: String(receipt ?? cb.CheckoutRequestID) });
    } else {
      await failPayment(p.id, cb.ResultDesc || "M-Pesa payment was not completed");
    }
  }
  return Response.json({ ResultCode: 0, ResultDesc: "Accepted" });
});
