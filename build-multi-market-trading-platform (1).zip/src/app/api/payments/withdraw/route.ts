import { body, route } from "@/lib/api";
import { HttpError, requireAuth, verifyPassword } from "@/lib/auth";
import { createWithdrawal } from "@/lib/payments";
import type { MethodKey } from "@/lib/methods";

export const dynamic = "force-dynamic";

export const POST = route(async (req) => {
  const a = await requireAuth();
  const b = await body<{ method: MethodKey; amountUsd: number; address?: string; phone?: string; password?: string }>(req);
  if (!b.password || !verifyPassword(b.password, a.user.passwordHash)) throw new HttpError(401, "Incorrect password — withdrawal not authorised");
  const p = await createWithdrawal(a, b);
  return Response.json({ ok: true, payment: p });
});
