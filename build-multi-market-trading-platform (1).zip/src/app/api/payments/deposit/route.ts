import { body, route } from "@/lib/api";
import { requireAuth } from "@/lib/auth";
import { createDeposit } from "@/lib/payments";
import type { MethodKey } from "@/lib/methods";

export const dynamic = "force-dynamic";

export const POST = route(async (req) => {
  const a = await requireAuth();
  const b = await body<{ method: MethodKey; amountUsd?: number; amountKes?: number; txHash?: string; phone?: string }>(req);
  const p = await createDeposit(a, b);
  return Response.json({ ok: true, payment: p });
});
