import { and, desc, eq, gte, lte, ne, sql } from "drizzle-orm";
import { db } from "@/db";
import { contracts, transactions } from "@/db/schema";
import { route } from "@/lib/api";
import { requireAuth } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const GET = route(async (req) => {
  const a = await requireAuth();
  const url = new URL(req.url);
  const type = url.searchParams.get("type") || "statement";
  const from = url.searchParams.get("from");
  const to = url.searchParams.get("to");
  const fromD = from ? new Date(from + "T00:00:00") : new Date(Date.now() - 30 * 86400000);
  const toD = to ? new Date(to + "T23:59:59") : new Date(Date.now() + 86400000);
  if (type === "statement") {
    const rows = await db
      .select()
      .from(transactions)
      .where(and(eq(transactions.accountId, a.active.id), gte(transactions.createdAt, fromD), lte(transactions.createdAt, toD)))
      .orderBy(desc(transactions.id))
      .limit(500);
    return Response.json({ rows });
  }
  const rows = await db
    .select()
    .from(contracts)
    .where(and(eq(contracts.accountId, a.active.id), ne(contracts.status, "open"), gte(contracts.createdAt, fromD), lte(contracts.createdAt, toD)))
    .orderBy(desc(contracts.id))
    .limit(500);
  const [sum] = await db
    .select({
      total: sql<number>`coalesce(sum(${contracts.profit}),0)`,
      won: sql<number>`count(*) filter (where ${contracts.profit} > 0)`,
      lost: sql<number>`count(*) filter (where ${contracts.profit} <= 0)`,
      staked: sql<number>`coalesce(sum(${contracts.stake}),0)`,
    })
    .from(contracts)
    .where(and(eq(contracts.accountId, a.active.id), ne(contracts.status, "open"), gte(contracts.createdAt, fromD), lte(contracts.createdAt, toD)));
  return Response.json({ rows, summary: { total: Number(sum.total), won: Number(sum.won), lost: Number(sum.lost), staked: Number(sum.staked) } });
});
