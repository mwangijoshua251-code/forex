import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { accounts, contracts, sessions } from "@/db/schema";
import { body, route } from "@/lib/api";
import { HttpError, requireAuth } from "@/lib/auth";
import { adjustBalance, round2 } from "@/lib/ledger";

export const dynamic = "force-dynamic";

export const POST = route(async (req) => {
  const a = await requireAuth();
  const b = await body<{ action?: string; accountId?: number }>(req);
  if (b.action === "switch") {
    const acc = a.accounts.find((x) => x.id === Number(b.accountId));
    if (!acc) throw new HttpError(404, "Account not found");
    await db.update(sessions).set({ activeAccountId: acc.id }).where(eq(sessions.id, a.sessionId));
    return Response.json({ ok: true, active: acc });
  }
  if (b.action === "reset-demo") {
    const demo = a.accounts.find((x) => x.type === "demo");
    if (!demo) throw new HttpError(404, "No demo account");
    const open = await db.select({ id: contracts.id }).from(contracts).where(and(eq(contracts.accountId, demo.id), eq(contracts.status, "open")));
    if (open.length) throw new HttpError(400, "Close all open demo positions before resetting");
    const delta = round2(10000 - demo.balance);
    if (delta !== 0) {
      await db.transaction(async (tx) => {
        await adjustBalance(tx, { accountId: demo.id, userId: a.user.id, delta, type: "reset", description: "Demo balance reset to 10,000.00 USD" });
      });
    }
    const [acc] = await db.select().from(accounts).where(eq(accounts.id, demo.id));
    return Response.json({ ok: true, account: acc });
  }
  throw new HttpError(400, "Unknown action");
});
