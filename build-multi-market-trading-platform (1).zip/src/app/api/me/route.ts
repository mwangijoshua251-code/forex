import { and, count, eq } from "drizzle-orm";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { route } from "@/lib/api";
import { publicUser, requireAuth } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const GET = route(async () => {
  const a = await requireAuth();
  const [n] = await db
    .select({ c: count() })
    .from(notifications)
    .where(and(eq(notifications.userId, a.user.id), eq(notifications.read, false)));
  return Response.json({ user: publicUser(a.user), accounts: a.accounts, active: a.active, unread: n.c });
});
