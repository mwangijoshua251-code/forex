import { body, route } from "@/lib/api";
import { requireAuth } from "@/lib/auth";
import { sellContract } from "@/lib/contracts";

export const dynamic = "force-dynamic";

export const POST = route(async (req) => {
  const a = await requireAuth();
  const b = await body<{ id?: number }>(req);
  const r = await sellContract(a, Number(b.id));
  return Response.json({ ok: true, result: r });
});
