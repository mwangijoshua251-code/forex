import { body, route } from "@/lib/api";
import { requireAuth } from "@/lib/auth";
import { buyContract, type BuyInput } from "@/lib/contracts";

export const dynamic = "force-dynamic";

export const POST = route(async (req) => {
  const a = await requireAuth();
  const b = await body<BuyInput>(req);
  const c = await buyContract(a, b);
  return Response.json({ ok: true, contract: c });
});
