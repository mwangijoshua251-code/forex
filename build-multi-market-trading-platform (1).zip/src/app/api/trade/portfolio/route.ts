import { and, desc, eq, ne } from "drizzle-orm";
import { db } from "@/db";
import { accounts, contracts } from "@/db/schema";
import { route } from "@/lib/api";
import { requireAuth } from "@/lib/auth";
import { evaluate } from "@/lib/contracts";
import { getEngine } from "@/lib/engine";

export const dynamic = "force-dynamic";

export const GET = route(async () => {
  const a = await requireAuth();
  const eng = getEngine();
  const open = await db
    .select()
    .from(contracts)
    .where(and(eq(contracts.accountId, a.active.id), eq(contracts.status, "open")))
    .orderBy(desc(contracts.id));
  const closed = await db
    .select()
    .from(contracts)
    .where(and(eq(contracts.accountId, a.active.id), ne(contracts.status, "open")))
    .orderBy(desc(contracts.id))
    .limit(25);
  const [acc] = await db.select().from(accounts).where(eq(accounts.id, a.active.id));
  return Response.json({
    time: eng.lastTime,
    balance: acc.balance,
    account: acc,
    open: open.map((c) => ({ ...c, live: evaluate(c, eng) })),
    closed,
  });
});
