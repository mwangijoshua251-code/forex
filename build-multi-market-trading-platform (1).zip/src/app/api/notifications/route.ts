import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { route } from "@/lib/api";
import { requireAuth } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const GET = route(async () => {
  const a = await requireAuth();
  const rows = await db.select().from(notifications).where(eq(notifications.userId, a.user.id)).orderBy(desc(notifications.id)).limit(30);
  return Response.json({ rows });
});

export const POST = route(async () => {
  const a = await requireAuth();
  await db.update(notifications).set({ read: true }).where(eq(notifications.userId, a.user.id));
  return Response.json({ ok: true });
});
