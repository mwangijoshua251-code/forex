import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { accounts, users } from "@/db/schema";
import { body, route } from "@/lib/api";
import { HttpError, requireAdmin } from "@/lib/auth";
import { adjustBalance, notify } from "@/lib/ledger";
import { approveWithdrawal, completeDeposit, rejectPayment } from "@/lib/payments";

export const dynamic = "force-dynamic";

export const POST = route(async (req) => {
  await requireAdmin();
  const b = await body<{ target: string; id: number; action: string; reason?: string; txHash?: string; amount?: number }>(req);
  const id = Number(b.id);
  if (b.target === "payment") {
    if (b.action === "approve") {
      const r = await approveWithdrawal(id, b.txHash || undefined).catch(async (e) => {
        if (e instanceof HttpError && e.status === 404) return completeDeposit(id);
        throw e;
      });
      return Response.json({ ok: true, result: r });
    }
    if (b.action === "reject") return Response.json({ ok: true, result: await rejectPayment(id, b.reason || "Rejected by compliance") });
  }
  if (b.target === "user") {
    if (b.action === "verify" || b.action === "reject_kyc") {
      const status = b.action === "verify" ? "verified" : "unverified";
      await db.update(users).set({ kycStatus: status }).where(eq(users.id, id));
      await notify(db, id, b.action === "verify" ? "Identity verified" : "Verification rejected", b.action === "verify" ? "Your account is fully verified. You can now withdraw." : b.reason || "Your documents could not be verified. Please resubmit.");
      return Response.json({ ok: true });
    }
    if (b.action === "disable" || b.action === "enable") {
      await db.update(users).set({ disabled: b.action === "disable" }).where(eq(users.id, id));
      return Response.json({ ok: true });
    }
    if (b.action === "credit") {
      const amt = Number(b.amount);
      if (!amt) throw new HttpError(400, "Enter an amount");
      const [acc] = await db.select().from(accounts).where(and(eq(accounts.userId, id), eq(accounts.type, "real")));
      if (!acc) throw new HttpError(404, "No real account");
      await db.transaction(async (tx) => {
        await adjustBalance(tx, { accountId: acc.id, userId: id, delta: amt, type: amt > 0 ? "adjustment" : "adjustment", description: b.reason || "Manual balance adjustment" });
      });
      return Response.json({ ok: true });
    }
  }
  throw new HttpError(400, "Unknown action");
});
