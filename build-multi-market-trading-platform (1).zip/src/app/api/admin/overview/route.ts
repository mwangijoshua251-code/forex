import { and, desc, eq, inArray, sql, ilike, or } from "drizzle-orm";
import { db } from "@/db";
import { accounts, contracts, payments, users } from "@/db/schema";
import { route } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const GET = route(async (req) => {
  await requireAdmin();
  const q = new URL(req.url).searchParams.get("q") || "";
  const [stats] = await db
    .select({
      users: sql<number>`(select count(*) from ${users})`,
      realBalances: sql<number>`(select coalesce(sum(balance),0) from ${accounts} where type='real')`,
      deposits: sql<number>`(select coalesce(sum(amount_usd),0) from ${payments} where kind='deposit' and status='completed')`,
      withdrawals: sql<number>`(select coalesce(sum(amount_usd),0) from ${payments} where kind='withdrawal' and status='completed')`,
      openContracts: sql<number>`(select count(*) from ${contracts} where status='open')`,
      realPnl: sql<number>`(select coalesce(-sum(c.profit),0) from ${contracts} c join ${accounts} a on a.id=c.account_id where a.type='real' and c.status<>'open')`,
      pendingKyc: sql<number>`(select count(*) from ${users} where kyc_status='pending')`,
    })
    .from(sql`(select 1) as x`);
  const pending = await db
    .select({ p: payments, name: users.fullName, email: users.email, phone: users.phone })
    .from(payments)
    .leftJoin(users, eq(users.id, payments.userId))
    .where(inArray(payments.status, ["pending", "processing"]))
    .orderBy(desc(payments.id));
  const recent = await db
    .select({ p: payments, name: users.fullName })
    .from(payments)
    .leftJoin(users, eq(users.id, payments.userId))
    .orderBy(desc(payments.id))
    .limit(30);
  const userWhere = q ? or(ilike(users.fullName, `%${q}%`), ilike(users.email, `%${q}%`), ilike(users.phone, `%${q}%`)) : undefined;
  const ulist = await db
    .select({ u: users, balance: accounts.balance, loginId: accounts.loginId })
    .from(users)
    .leftJoin(accounts, and(eq(accounts.userId, users.id), eq(accounts.type, "real")))
    .where(userWhere)
    .orderBy(desc(users.id))
    .limit(100);
  return Response.json({
    stats: Object.fromEntries(Object.entries(stats).map(([k, v]) => [k, Number(v)])),
    pending,
    recent,
    users: ulist.map((r) => ({
      id: r.u.id, fullName: r.u.fullName, email: r.u.email, phone: r.u.phone, role: r.u.role, kycStatus: r.u.kycStatus,
      kycDocType: r.u.kycDocType, kycDocNumber: r.u.kycDocNumber, disabled: r.u.disabled, createdAt: r.u.createdAt, balance: r.balance, loginId: r.loginId,
    })),
  });
});
