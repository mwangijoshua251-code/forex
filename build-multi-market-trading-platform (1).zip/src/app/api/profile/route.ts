import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { body, route } from "@/lib/api";
import { hashPassword, HttpError, isEmail, normalizePhone, publicUser, requireAuth, verifyPassword } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const GET = route(async () => {
  const a = await requireAuth();
  const u = a.user;
  return Response.json({
    user: { ...publicUser(u), dateOfBirth: u.dateOfBirth, address: u.address, kycDocType: u.kycDocType, kycDocNumber: u.kycDocNumber, maxStake: u.maxStake, dailyLossLimit: u.dailyLossLimit, selfExcludedUntil: u.selfExcludedUntil, createdAt: u.createdAt },
  });
});

export const POST = route(async (req) => {
  const a = await requireAuth();
  const b = await body<Record<string, string | number | null>>(req);
  const uid = a.user.id;
  switch (b.action) {
    case "update": {
      const set: Partial<typeof users.$inferInsert> = {};
      if (b.fullName) set.fullName = String(b.fullName).trim();
      if (b.country) set.country = String(b.country);
      if (b.address !== undefined) set.address = String(b.address ?? "");
      if (b.dateOfBirth !== undefined) set.dateOfBirth = String(b.dateOfBirth ?? "");
      if (b.email && !a.user.email) {
        const e = String(b.email).toLowerCase().trim();
        if (!isEmail(e)) throw new HttpError(400, "Invalid email");
        const ex = await db.select({ id: users.id }).from(users).where(eq(users.email, e));
        if (ex.length) throw new HttpError(409, "Email already in use");
        set.email = e;
      }
      if (b.phone && !a.user.phone) {
        const p = normalizePhone(String(b.phone));
        const ex = await db.select({ id: users.id }).from(users).where(eq(users.phone, p));
        if (ex.length) throw new HttpError(409, "Phone already in use");
        set.phone = p;
      }
      await db.update(users).set(set).where(eq(users.id, uid));
      return Response.json({ ok: true });
    }
    case "kyc": {
      const docType = String(b.docType || "");
      const docNumber = String(b.docNumber || "").trim();
      if (!["national_id", "passport", "driving_licence"].includes(docType)) throw new HttpError(400, "Select a document type");
      if (docNumber.length < 5) throw new HttpError(400, "Enter a valid document number");
      if (!b.dateOfBirth) throw new HttpError(400, "Enter your date of birth");
      const dob = new Date(String(b.dateOfBirth));
      if (Date.now() - dob.getTime() < 18 * 365.25 * 86400000) throw new HttpError(400, "You must be at least 18 years old");
      if (!b.address || String(b.address).length < 4) throw new HttpError(400, "Enter your residential address");
      await db
        .update(users)
        .set({ kycDocType: docType, kycDocNumber: docNumber, dateOfBirth: String(b.dateOfBirth), address: String(b.address), kycStatus: "pending" })
        .where(eq(users.id, uid));
      return Response.json({ ok: true });
    }
    case "password": {
      if (!verifyPassword(String(b.current || ""), a.user.passwordHash)) throw new HttpError(400, "Current password is incorrect");
      const np = String(b.next || "");
      if (np.length < 8 || !/[A-Za-z]/.test(np) || !/\d/.test(np)) throw new HttpError(400, "New password must be 8+ characters with letters and numbers");
      await db.update(users).set({ passwordHash: hashPassword(np) }).where(eq(users.id, uid));
      return Response.json({ ok: true });
    }
    case "limits": {
      const maxStake = b.maxStake ? Number(b.maxStake) : null;
      const daily = b.dailyLossLimit ? Number(b.dailyLossLimit) : null;
      const set: Partial<typeof users.$inferInsert> = { maxStake, dailyLossLimit: daily };
      const days = Number(b.selfExcludeDays || 0);
      if (days > 0) set.selfExcludedUntil = new Date(Date.now() + days * 86400000);
      await db.update(users).set(set).where(eq(users.id, uid));
      return Response.json({ ok: true });
    }
  }
  throw new HttpError(400, "Unknown action");
});
