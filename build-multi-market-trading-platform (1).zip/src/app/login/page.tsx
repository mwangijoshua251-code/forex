import { redirect } from "next/navigation";
import { getAuth } from "@/lib/auth";
import { LoginForm } from "@/components/AuthForms";

export const dynamic = "force-dynamic";

export default async function LoginPage() {
  if (await getAuth()) redirect("/trade");
  return <LoginForm />;
}
