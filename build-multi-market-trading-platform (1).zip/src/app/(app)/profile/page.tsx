import { Profile } from "@/components/Profile";

export default async function ProfilePage({ searchParams }: { searchParams: Promise<{ tab?: string }> }) {
  const sp = await searchParams;
  return <Profile initialTab={sp.tab} />;
}
