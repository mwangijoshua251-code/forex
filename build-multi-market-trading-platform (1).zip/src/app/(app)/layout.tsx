import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { and, count, eq } from "drizzle-orm";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { getAuth, publicUser } from "@/lib/auth";
import { AppShell } from "@/components/AppShell";
import { ensureRuntime } from "@/lib/runtime";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: ReactNode }) {
  ensureRuntime();
  const a = await getAuth();
  if (!a) redirect("/login");
  const [n] = await db
    .select({ c: count() })
    .from(notifications)
    .where(and(eq(notifications.userId, a.user.id), eq(notifications.read, false)));
  const strip = (x: (typeof a.accounts)[number]) => ({ id: x.id, type: x.type, loginId: x.loginId, currency: x.currency, balance: x.balance });
  return (
    <AppShell initial={{ user: publicUser(a.user), accounts: a.accounts.map(strip), active: strip(a.active), unread: n.c }}>
      {children}
    </AppShell>
  );
}
