import { Suspense } from "react";
import { TradeTerminal } from "@/components/trade/TradeTerminal";

export default function TradePage() {
  return (
    <Suspense fallback={<div className="p-10 text-center text-slate-500">Loading trading terminal…</div>}>
      <TradeTerminal />
    </Suspense>
  );
}
