import { redirect } from "next/navigation";
import { getAuth } from "@/lib/auth";
import { Admin } from "@/components/Admin";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const a = await getAuth();
  if (!a || a.user.role !== "admin") redirect("/trade");
  return <Admin />;
}
