import { Hub } from "@/components/Hub";

export default async function HubPage({ searchParams }: { searchParams: Promise<{ welcome?: string }> }) {
  const sp = await searchParams;
  return <Hub welcome={sp.welcome === "1"} />;
}
