import { Cashier } from "@/components/Cashier";

export default async function CashierPage({ searchParams }: { searchParams: Promise<{ tab?: string }> }) {
  const sp = await searchParams;
  return <Cashier initialTab={sp.tab} />;
}
