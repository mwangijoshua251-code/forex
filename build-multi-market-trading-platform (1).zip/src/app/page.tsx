import Link from "next/link";
import { getAuth } from "@/lib/auth";
import { Logo } from "@/components/AppShell";
import { MARKETS, SYMBOLS } from "@/lib/markets";
import { TRADE_GROUPS } from "@/lib/pricing";
import { METHOD_LIST } from "@/lib/methods";
import { LiveTicker } from "@/components/LiveTicker";

export const dynamic = "force-dynamic";

export default async function Home() {
  const auth = await getAuth().catch(() => null);
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 border-b border-white/5 bg-ink-950/80 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-7xl items-center gap-6 px-4">
          <Logo />
          <nav className="hidden gap-6 text-sm text-slate-400 md:flex">
            <a href="#markets" className="hover:text-white">Markets</a>
            <a href="#trade-types" className="hover:text-white">Trade types</a>
            <a href="#payments" className="hover:text-white">Payments</a>
            <a href="#why" className="hover:text-white">Why us</a>
          </nav>
          <div className="ml-auto flex gap-2">
            {auth ? (
              <Link href="/trade" className="btn-brand">Go to trading</Link>
            ) : (
              <>
                <Link href="/login" className="btn-ghost">Log in</Link>
                <Link href="/register" className="btn-brand">Sign up</Link>
              </>
            )}
          </div>
        </div>
        <LiveTicker />
      </header>

      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(255,68,79,0.18),transparent_60%)]" />
        <div className="relative mx-auto grid max-w-7xl items-center gap-10 px-4 py-16 lg:grid-cols-2 lg:py-24">
          <div>
            <span className="rounded-full border border-brand/30 bg-brand/10 px-3 py-1 text-xs font-semibold text-brand">Synthetic indices open 24/7 — even on weekends</span>
            <h1 className="mt-5 text-4xl font-extrabold leading-tight text-white sm:text-6xl">
              Trade smarter.<br />Trade <span className="text-brand">every market.</span>
            </h1>
            <p className="mt-5 max-w-xl text-lg text-slate-400">
              Options, multipliers and accumulators on {SYMBOLS.length}+ instruments across derived indices, forex, stock indices, commodities, crypto and stocks. Fund instantly with USDT, BTC, ETH or M-Pesa — all balances in USD.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href={auth ? "/trade" : "/register"} className="btn-brand !px-6 !py-3 text-base">Open free account</Link>
              <Link href={auth ? "/trade" : "/login"} className="btn-ghost !px-6 !py-3 text-base">Try 10,000 USD demo</Link>
            </div>
            <div className="mt-10 grid max-w-md grid-cols-3 gap-6">
              {[["0.35", "USD min stake"], ["1s", "tick speed"], ["24/7", "derived markets"]].map(([a, b]) => (
                <div key={b}><div className="text-2xl font-bold text-white">{a}</div><div className="text-xs text-slate-500">{b}</div></div>
              ))}
            </div>
          </div>
          <div className="relative">
            <div className="absolute -inset-6 rounded-3xl bg-brand/10 blur-3xl" />
            <img src="/images/hero.jpg" alt="Tradova trading platform" className="relative rounded-2xl border border-white/10 shadow-2xl" />
          </div>
        </div>
      </section>

      <section id="markets" className="mx-auto max-w-7xl px-4 py-16">
        <h2 className="text-3xl font-bold text-white">All the markets you want</h2>
        <p className="mt-2 text-slate-400">Six asset classes, one account.</p>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {MARKETS.map((m) => (
            <div key={m.key} className="card p-6 transition hover:border-brand/30">
              <h3 className="text-lg font-semibold text-white">{m.label}</h3>
              <p className="mt-1 text-sm text-slate-400">{m.desc}</p>
              <div className="mt-4 flex flex-wrap gap-1.5">
                {SYMBOLS.filter((s) => s.market === m.key).slice(0, 6).map((s) => (
                  <span key={s.symbol} className="rounded-md bg-white/5 px-2 py-1 text-xs text-slate-300">{s.name}</span>
                ))}
                <span className="rounded-md px-2 py-1 text-xs text-slate-500">+{Math.max(0, SYMBOLS.filter((s) => s.market === m.key).length - 6)} more</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section id="trade-types" className="border-y border-white/5 bg-ink-900/50">
        <div className="mx-auto max-w-7xl px-4 py-16">
          <h2 className="text-3xl font-bold text-white">Trade types for every strategy</h2>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {TRADE_GROUPS.map((t) => (
              <div key={t.key} className="card p-5">
                <div className="text-[10px] font-bold uppercase tracking-wider text-brand">{t.category}</div>
                <h3 className="mt-1 font-semibold text-white">{t.label}</h3>
                <p className="mt-2 text-sm text-slate-400">{t.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="payments" className="mx-auto max-w-7xl px-4 py-16">
        <h2 className="text-3xl font-bold text-white">Fast deposits & withdrawals</h2>
        <p className="mt-2 text-slate-400">Fund with crypto or mobile money. Your balance is always in USD.</p>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {METHOD_LIST.map((m) => (
            <div key={m.key} className="card p-5 text-center">
              <div className="mx-auto grid h-12 w-12 place-items-center rounded-full text-xl font-bold text-white" style={{ background: m.color }}>{m.icon}</div>
              <div className="mt-3 font-semibold text-white">{m.label}</div>
              <div className="text-xs text-slate-500">{m.network}</div>
              <div className="mt-2 text-xs text-slate-400">Min {m.minDeposit} USD · {m.processing}</div>
            </div>
          ))}
        </div>
      </section>

      <section id="why" className="border-t border-white/5 bg-ink-900/50">
        <div className="mx-auto grid max-w-7xl gap-6 px-4 py-16 md:grid-cols-4">
          {[
            ["🛡️", "Secure & segregated", "Client funds held separately with KYC/AML compliance and password-confirmed withdrawals."],
            ["⚡", "Instant execution", "Server-priced contracts settled automatically, tick by tick."],
            ["📊", "Pro tools", "Tick & candle charts, digit statistics, price alerts, reports and CSV exports."],
            ["🧭", "Responsible trading", "Set stake limits, daily loss limits, or self-exclude any time."],
          ].map(([i, t, d]) => (
            <div key={t}>
              <div className="text-3xl">{i}</div>
              <h3 className="mt-3 font-semibold text-white">{t}</h3>
              <p className="mt-1 text-sm text-slate-400">{d}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t border-white/5">
        <div className="mx-auto max-w-7xl px-4 py-10 text-xs leading-relaxed text-slate-500">
          <Logo className="mb-4" />
          <p>Risk warning: The products offered on this platform are complex derivatives and carry a high risk of losing money rapidly due to leverage. You should consider whether you understand how these products work and whether you can afford to take the high risk of losing your money. Synthetic indices are generated by a random number generator and are not linked to real-world markets.</p>
          <p className="mt-3">© {new Date().getFullYear()} Tradova. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
