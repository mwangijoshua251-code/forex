import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Tradova — Trade Derived, Forex, Crypto, Stocks & Commodities",
  description:
    "Trade synthetic indices, forex, stock indices, commodities, cryptocurrencies and stocks with options, multipliers and accumulators. Deposit via USDT, BTC, ETH and M-Pesa.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-ink-950 font-sans text-slate-200 antialiased">{children}</body>
    </html>
  );
}
