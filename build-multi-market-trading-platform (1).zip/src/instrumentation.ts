export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    try {
      const { ensureRuntime } = await import("./lib/runtime");
      ensureRuntime();
      const { ensureAdmin } = await import("./lib/auth");
      await ensureAdmin().catch(() => {});
    } catch (e) {
      console.error("runtime start failed", e);
    }
  }
}
