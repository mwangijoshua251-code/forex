import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { priceAlerts } from "@/db/schema";
import { getEngine } from "./engine";
import { settleAll } from "./contracts";
import { processPayments } from "./payments";
import { notify } from "./ledger";
import { getSymbol, formatPrice } from "./markets";

const g = globalThis as typeof globalThis & { __runtimeStarted?: boolean };

let alertBusy = false;
async function checkAlerts() {
  if (alertBusy) return;
  alertBusy = true;
  try {
    const eng = getEngine();
    const list = await db.select().from(priceAlerts).where(eq(priceAlerts.triggered, false));
    for (const a of list) {
      const p = eng.latest(a.symbol)?.price;
      if (p === undefined) continue;
      if ((a.direction === "above" && p >= a.price) || (a.direction === "below" && p <= a.price)) {
        const s = getSymbol(a.symbol);
        await db.update(priceAlerts).set({ triggered: true }).where(and(eq(priceAlerts.id, a.id), eq(priceAlerts.triggered, false)));
        await notify(db, a.userId, "Price alert triggered", `${s?.name ?? a.symbol} is now ${a.direction} ${formatPrice(a.price, s?.decimals ?? 2)} (current ${formatPrice(p, s?.decimals ?? 2)})`);
      }
    }
  } catch (e) {
    console.error("alerts", e);
  } finally {
    alertBusy = false;
  }
}

export function ensureRuntime() {
  if (g.__runtimeStarted) return getEngine();
  g.__runtimeStarted = true;
  const eng = getEngine();
  setInterval(() => {
    eng.advance();
    settleAll().catch((e) => console.error(e));
  }, 1000);
  setInterval(() => {
    processPayments().catch((e) => console.error(e));
    checkAlerts().catch((e) => console.error(e));
  }, 3000);
  return eng;
}
