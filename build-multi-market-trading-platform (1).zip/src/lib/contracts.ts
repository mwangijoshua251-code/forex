import { and, eq, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import { contracts, type Contract } from "@/db/schema";
import { getEngine, PriceEngine } from "./engine";
import { getSymbol, lastDigit } from "./markets";
import {
  ACCU_MAX_TICKS,
  CONTRACT_LABELS,
  GROWTH_RATES,
  MULT_COMMISSION,
  accuRange,
  availableGroups,
  digitProb,
  durationLabel,
  durationSec,
  groupOf,
  probAbove,
  probTouch,
  quote,
  UNIT_LIMITS,
  type DurationUnit,
} from "./pricing";
import { AuthContext, HttpError } from "./auth";
import { adjustBalance, round2 } from "./ledger";

export interface Evaluation {
  done: boolean;
  status?: "won" | "lost";
  exitSpot?: number;
  exitTime?: number;
  credit?: number;
  currentSpot: number;
  currentValue: number;
  pnl: number;
  ticks?: number;
  rangeHigh?: number;
  rangeLow?: number;
  sellable: boolean;
}

function winOption(c: Contract, exit: number, decimals: number) {
  const d = lastDigit(exit, decimals);
  switch (c.contractType) {
    case "CALL": return exit > c.entrySpot;
    case "PUT": return exit < c.entrySpot;
    case "HIGHER": return exit > (c.barrier ?? 0);
    case "LOWER": return exit < (c.barrier ?? 0);
    case "DIGITMATCH": return d === c.digit;
    case "DIGITDIFF": return d !== c.digit;
    case "DIGITEVEN": return d % 2 === 0;
    case "DIGITODD": return d % 2 === 1;
    case "DIGITOVER": return d > (c.digit ?? 0);
    case "DIGITUNDER": return d < (c.digit ?? 0);
  }
  return false;
}

export function evaluate(c: Contract, eng: PriceEngine = getEngine()): Evaluation {
  const sym = getSymbol(c.symbol)!;
  const latest = eng.latest(c.symbol)!;
  const now = latest.time;
  const cur = latest.price;
  const ct = c.contractType;

  if (ct === "MULTUP" || ct === "MULTDOWN") {
    const dir = ct === "MULTUP" ? 1 : -1;
    const mult = c.multiplier ?? 1;
    const comm = c.commission ?? 0;
    const pnlAt = (p: number) => c.stake * mult * dir * (p / c.entrySpot - 1) - comm;
    const path = eng.range(c.symbol, c.entryTime + 1, now);
    for (const t of path) {
      const pnl = pnlAt(t.price);
      if (pnl <= -c.stake) {
        return { done: true, status: "lost", exitSpot: t.price, exitTime: t.time, credit: 0, currentSpot: cur, currentValue: 0, pnl: -c.stake, sellable: false };
      }
      if ((c.takeProfit && pnl >= c.takeProfit) || (c.stopLoss && pnl <= -c.stopLoss)) {
        const credit = round2(c.stake + pnl);
        return { done: true, status: pnl >= 0 ? "won" : "lost", exitSpot: t.price, exitTime: t.time, credit, currentSpot: cur, currentValue: credit, pnl: round2(pnl), sellable: false };
      }
    }
    const pnl = round2(Math.max(-c.stake, pnlAt(cur)));
    return { done: false, currentSpot: cur, currentValue: round2(c.stake + pnl), pnl, sellable: true };
  }

  if (ct === "ACCU") {
    const g = c.growthRate ?? 0.01;
    const r = accuRange(g, sym.sigma);
    const maxTicks = ACCU_MAX_TICKS[g.toFixed(2)] ?? 230;
    const path = eng.range(c.symbol, c.entryTime + 1, now);
    let prev = c.entrySpot;
    let n = 0;
    for (const t of path) {
      if (Math.abs(t.price / prev - 1) > r) {
        return { done: true, status: "lost", exitSpot: t.price, exitTime: t.time, credit: 0, currentSpot: cur, currentValue: 0, pnl: -c.stake, ticks: n, sellable: false };
      }
      prev = t.price;
      n++;
      const value = c.stake * Math.pow(1 + g, n);
      if ((c.takeProfit && value - c.stake >= c.takeProfit) || n >= maxTicks) {
        const credit = round2(value);
        return { done: true, status: "won", exitSpot: t.price, exitTime: t.time, credit, currentSpot: cur, currentValue: credit, pnl: round2(credit - c.stake), ticks: n, sellable: false };
      }
    }
    const value = round2(c.stake * Math.pow(1 + g, n));
    return { done: false, currentSpot: cur, currentValue: value, pnl: round2(value - c.stake), ticks: n, rangeHigh: prev * (1 + r), rangeLow: prev * (1 - r), sellable: n > 0 };
  }

  const payout = c.payout ?? 0;
  const expiry = c.expiryTime ?? c.entryTime;

  if (ct === "TOUCH" || ct === "NOTOUCH") {
    const barrier = c.barrier ?? 0;
    const above = barrier > c.entrySpot;
    const path = eng.range(c.symbol, c.entryTime + 1, Math.min(now, expiry));
    const hit = path.find((t) => (above ? t.price >= barrier : t.price <= barrier));
    if (hit) {
      const won = ct === "TOUCH";
      return { done: true, status: won ? "won" : "lost", exitSpot: hit.price, exitTime: hit.time, credit: won ? payout : 0, currentSpot: cur, currentValue: won ? payout : 0, pnl: won ? round2(payout - c.stake) : -c.stake, sellable: false };
    }
    if (now >= expiry) {
      const exit = eng.priceAt(c.symbol, expiry) ?? cur;
      const won = ct === "NOTOUCH";
      return { done: true, status: won ? "won" : "lost", exitSpot: exit, exitTime: expiry, credit: won ? payout : 0, currentSpot: cur, currentValue: won ? payout : 0, pnl: won ? round2(payout - c.stake) : -c.stake, sellable: false };
    }
    const T = expiry - now;
    const p = ct === "TOUCH" ? probTouch(cur, barrier, sym.sigma, T) : 1 - probTouch(cur, barrier, sym.sigma, T);
    const value = round2(Math.min(payout, payout * p * 0.97));
    return { done: false, currentSpot: cur, currentValue: value, pnl: round2(value - c.stake), sellable: true };
  }

  if (now >= expiry) {
    const exit = eng.priceAt(c.symbol, expiry);
    if (exit !== null) {
      const won = winOption(c, exit, sym.decimals);
      return { done: true, status: won ? "won" : "lost", exitSpot: exit, exitTime: expiry, credit: won ? payout : 0, currentSpot: cur, currentValue: won ? payout : 0, pnl: won ? round2(payout - c.stake) : -c.stake, sellable: false };
    }
  }
  const T = Math.max(0, expiry - now);
  let p = 0.5;
  if (ct === "CALL") p = probAbove(cur, c.entrySpot, sym.sigma, T);
  else if (ct === "PUT") p = 1 - probAbove(cur, c.entrySpot, sym.sigma, T);
  else if (ct === "HIGHER") p = probAbove(cur, c.barrier ?? cur, sym.sigma, T);
  else if (ct === "LOWER") p = 1 - probAbove(cur, c.barrier ?? cur, sym.sigma, T);
  else p = digitProb(ct, c.digit ?? 0);
  const value = round2(Math.min(payout, payout * p * 0.97));
  const sellable = !ct.startsWith("DIGIT") && now > c.entryTime && T > 1;
  return { done: false, currentSpot: cur, currentValue: value, pnl: round2(value - c.stake), sellable };
}

export async function settle(c: Contract, ev: Evaluation, sold = false) {
  const status = sold ? "sold" : ev.status!;
  const credit = round2(ev.credit ?? 0);
  return db.transaction(async (tx) => {
    const [row] = await tx
      .update(contracts)
      .set({
        status,
        exitSpot: ev.exitSpot ?? ev.currentSpot,
        exitTime: ev.exitTime ?? getEngine().lastTime,
        profit: round2(credit - c.stake),
        sellPrice: credit,
      })
      .where(and(eq(contracts.id, c.id), eq(contracts.status, "open")))
      .returning();
    if (row && credit > 0) {
      await adjustBalance(tx, {
        accountId: c.accountId,
        userId: c.userId,
        delta: credit,
        type: sold ? "sell" : "payout",
        description: `${sold ? "Sold" : "Payout"} — ${CONTRACT_LABELS[c.contractType]} ${getSymbol(c.symbol)?.name ?? c.symbol} (#${c.id})`,
        reference: `C${c.id}`,
        contractId: c.id,
      });
    }
    return row;
  });
}

let settling = false;
export async function settleAll() {
  if (settling) return;
  settling = true;
  try {
    const eng = getEngine();
    const open = await db.select().from(contracts).where(eq(contracts.status, "open"));
    for (const c of open) {
      try {
        const ev = evaluate(c, eng);
        if (ev.done) await settle(c, ev);
      } catch (e) {
        console.error("settle error", c.id, e);
      }
    }
  } finally {
    settling = false;
  }
}

export interface BuyInput {
  symbol: string;
  contractType: string;
  stake: number;
  duration?: number;
  unit?: DurationUnit;
  barrierOffset?: number;
  digit?: number;
  multiplier?: number;
  takeProfit?: number | null;
  stopLoss?: number | null;
  growthRate?: number;
}

export async function buyContract(auth: AuthContext, input: BuyInput) {
  const sym = getSymbol(input.symbol);
  if (!sym) throw new HttpError(400, "Unknown market");
  const ct = input.contractType;
  if (!CONTRACT_LABELS[ct]) throw new HttpError(400, "Unknown contract type");
  const group = groupOf(ct);
  if (!availableGroups(sym).includes(group)) throw new HttpError(400, `${CONTRACT_LABELS[ct]} is not offered on ${sym.name}`);
  const stake = round2(Number(input.stake));
  if (!(stake >= 0.35)) throw new HttpError(400, "Minimum stake is 0.35 USD");
  if (stake > 50000) throw new HttpError(400, "Maximum stake is 50,000 USD");

  const u = auth.user;
  if (u.selfExcludedUntil && u.selfExcludedUntil > new Date())
    throw new HttpError(403, `You have self-excluded from trading until ${u.selfExcludedUntil.toDateString()}`);
  if (u.maxStake && stake > u.maxStake) throw new HttpError(403, `Stake exceeds your personal limit of ${u.maxStake} USD`);
  if (u.dailyLossLimit && auth.active.type === "real") {
    const since = new Date();
    since.setHours(0, 0, 0, 0);
    const [r] = await db
      .select({ s: sql<number>`coalesce(sum(${contracts.profit}),0)` })
      .from(contracts)
      .where(and(eq(contracts.accountId, auth.active.id), gte(contracts.createdAt, since)));
    if (-Number(r.s) >= u.dailyLossLimit) throw new HttpError(403, "You've reached your daily loss limit");
  }

  const eng = getEngine();
  const latest = eng.latest(sym.symbol)!;
  const spot = latest.price;
  const values: typeof contracts.$inferInsert = {
    accountId: auth.active.id,
    userId: u.id,
    symbol: sym.symbol,
    contractType: ct,
    stake,
    entrySpot: spot,
    entryTime: latest.time,
  };

  if (group === "multipliers") {
    const m = Number(input.multiplier);
    if (!sym.multipliers.includes(m)) throw new HttpError(400, "Invalid multiplier");
    values.multiplier = m;
    values.commission = round2(stake * m * MULT_COMMISSION);
    if (input.takeProfit) {
      if (!(input.takeProfit > 0)) throw new HttpError(400, "Take profit must be positive");
      values.takeProfit = round2(input.takeProfit);
    }
    if (input.stopLoss) {
      if (!(input.stopLoss > 0) || input.stopLoss > stake) throw new HttpError(400, "Stop loss must be between 0 and your stake");
      values.stopLoss = round2(input.stopLoss);
    }
  } else if (group === "accumulators") {
    const g = Number(input.growthRate);
    if (!GROWTH_RATES.includes(g)) throw new HttpError(400, "Invalid growth rate");
    values.growthRate = g;
    if (input.takeProfit) values.takeProfit = round2(input.takeProfit);
    const r = accuRange(g, sym.sigma);
    values.barrier = spot * (1 + r);
    values.barrierLow = spot * (1 - r);
  } else {
    const unit = (input.unit ?? "t") as DurationUnit;
    const dur = Math.floor(Number(input.duration));
    const lim = UNIT_LIMITS[unit];
    if (!lim) throw new HttpError(400, "Invalid duration unit");
    if (!(dur >= lim.min && dur <= lim.max)) throw new HttpError(400, `Duration must be ${lim.min}–${lim.max} ${lim.label.toLowerCase()}`);
    if (group === "higher_lower" || group === "touch") {
      if (unit === "t" && dur < 5) throw new HttpError(400, "Minimum duration is 5 ticks for this contract");
    }
    const T = durationSec(dur, unit);
    const q = quote({ contractType: ct, stake, spot, sym, durationSec: T, barrierOffset: Number(input.barrierOffset ?? 0), digit: Number(input.digit ?? 0) });
    if (q.error || !q.payout) throw new HttpError(400, q.error ?? "Unable to price contract");
    values.payout = q.payout;
    values.durationSec = T;
    values.durationLabel = durationLabel(dur, unit);
    values.expiryTime = latest.time + T;
    if (group === "higher_lower" || group === "touch") values.barrier = Number((spot + Number(input.barrierOffset)).toFixed(sym.decimals));
    if (ct.startsWith("DIGIT") && ct !== "DIGITEVEN" && ct !== "DIGITODD") values.digit = Number(input.digit);
  }

  return db.transaction(async (tx) => {
    const [c] = await tx.insert(contracts).values(values).returning();
    await adjustBalance(tx, {
      accountId: auth.active.id,
      userId: u.id,
      delta: -stake,
      type: "buy",
      description: `Buy — ${CONTRACT_LABELS[ct]} ${sym.name} (#${c.id})`,
      reference: `C${c.id}`,
      contractId: c.id,
    });
    return c;
  });
}

export async function sellContract(auth: AuthContext, id: number) {
  const [c] = await db
    .select()
    .from(contracts)
    .where(and(eq(contracts.id, id), eq(contracts.userId, auth.user.id)))
    .limit(1);
  if (!c) throw new HttpError(404, "Contract not found");
  if (c.status !== "open") throw new HttpError(400, "Contract is already closed");
  const ev = evaluate(c);
  if (ev.done) {
    await settle(c, ev);
    return { ...ev, sold: false };
  }
  if (!ev.sellable) throw new HttpError(400, "This contract cannot be sold right now");
  await settle(c, { ...ev, credit: Math.max(0, ev.currentValue) }, true);
  return { ...ev, sold: true };
}
