import { handleError } from "./auth";
import { ensureRuntime } from "./runtime";

export function route(fn: (req: Request) => Promise<Response>) {
  return async (req: Request) => {
    try {
      ensureRuntime();
      return await fn(req);
    } catch (e) {
      return handleError(e);
    }
  };
}

export async function body<T = Record<string, unknown>>(req: Request): Promise<T> {
  try {
    return (await req.json()) as T;
  } catch {
    return {} as T;
  }
}
