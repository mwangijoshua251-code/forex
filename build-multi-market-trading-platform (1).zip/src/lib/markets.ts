export type MarketKey = "synthetic" | "forex" | "indices" | "commodities" | "crypto" | "stocks";
export type Kind = "gbm" | "boom" | "crash" | "step" | "jump";

export interface SymbolDef {
  symbol: string;
  name: string;
  market: MarketKey;
  submarket: string;
  decimals: number;
  start: number;
  /** log-volatility per 1-second tick */
  sigma: number;
  kind: Kind;
  spikeEvery?: number;
  multipliers: number[];
}

export const MARKETS: { key: MarketKey; label: string; desc: string }[] = [
  { key: "synthetic", label: "Derived", desc: "Synthetic indices available 24/7, unaffected by real-world events" },
  { key: "forex", label: "Forex", desc: "Major, minor and exotic currency pairs" },
  { key: "indices", label: "Stock Indices", desc: "Global equity indices" },
  { key: "commodities", label: "Commodities", desc: "Metals and energies" },
  { key: "crypto", label: "Cryptocurrencies", desc: "Major crypto against USD" },
  { key: "stocks", label: "Stocks", desc: "Top US equities" },
];

const SEC_PER_YEAR = 31536000;
const v = (annual: number, boost = 1) => (annual * boost) / Math.sqrt(SEC_PER_YEAR);

const synthMult = [20, 40, 60, 100, 200, 400];
const fxMult = [50, 100, 200, 300, 500, 1000];
const idxMult = [20, 50, 100, 200];
const comMult = [50, 100, 200, 300];
const cryMult = [10, 20, 50, 100];
const stkMult = [5, 10, 20, 50];

export const SYMBOLS: SymbolDef[] = [
  // Derived — Volatility
  { symbol: "R_10", name: "Volatility 10 Index", market: "synthetic", submarket: "Continuous Indices", decimals: 3, start: 6542.123, sigma: v(0.1), kind: "gbm", multipliers: synthMult },
  { symbol: "R_25", name: "Volatility 25 Index", market: "synthetic", submarket: "Continuous Indices", decimals: 3, start: 2871.456, sigma: v(0.25), kind: "gbm", multipliers: synthMult },
  { symbol: "R_50", name: "Volatility 50 Index", market: "synthetic", submarket: "Continuous Indices", decimals: 4, start: 186.5432, sigma: v(0.5), kind: "gbm", multipliers: synthMult },
  { symbol: "R_75", name: "Volatility 75 Index", market: "synthetic", submarket: "Continuous Indices", decimals: 4, start: 41235.8812, sigma: v(0.75), kind: "gbm", multipliers: synthMult },
  { symbol: "R_100", name: "Volatility 100 Index", market: "synthetic", submarket: "Continuous Indices", decimals: 2, start: 1324.57, sigma: v(1.0), kind: "gbm", multipliers: synthMult },
  { symbol: "1HZ10V", name: "Volatility 10 (1s) Index", market: "synthetic", submarket: "Continuous Indices", decimals: 2, start: 8934.21, sigma: v(0.1), kind: "gbm", multipliers: synthMult },
  { symbol: "1HZ25V", name: "Volatility 25 (1s) Index", market: "synthetic", submarket: "Continuous Indices", decimals: 2, start: 612345.67, sigma: v(0.25), kind: "gbm", multipliers: synthMult },
  { symbol: "1HZ50V", name: "Volatility 50 (1s) Index", market: "synthetic", submarket: "Continuous Indices", decimals: 2, start: 254321.45, sigma: v(0.5), kind: "gbm", multipliers: synthMult },
  { symbol: "1HZ75V", name: "Volatility 75 (1s) Index", market: "synthetic", submarket: "Continuous Indices", decimals: 2, start: 7123.88, sigma: v(0.75), kind: "gbm", multipliers: synthMult },
  { symbol: "1HZ100V", name: "Volatility 100 (1s) Index", market: "synthetic", submarket: "Continuous Indices", decimals: 2, start: 1543.22, sigma: v(1.0), kind: "gbm", multipliers: synthMult },
  { symbol: "1HZ150V", name: "Volatility 150 (1s) Index", market: "synthetic", submarket: "Continuous Indices", decimals: 2, start: 3421.11, sigma: v(1.5), kind: "gbm", multipliers: synthMult },
  { symbol: "1HZ250V", name: "Volatility 250 (1s) Index", market: "synthetic", submarket: "Continuous Indices", decimals: 2, start: 5987.34, sigma: v(2.5), kind: "gbm", multipliers: synthMult },
  // Derived — Crash/Boom
  { symbol: "BOOM300", name: "Boom 300 Index", market: "synthetic", submarket: "Crash/Boom", decimals: 3, start: 3421.567, sigma: v(0.3), kind: "boom", spikeEvery: 300, multipliers: [100, 200, 300] },
  { symbol: "BOOM500", name: "Boom 500 Index", market: "synthetic", submarket: "Crash/Boom", decimals: 3, start: 5123.456, sigma: v(0.3), kind: "boom", spikeEvery: 500, multipliers: [100, 200, 300, 400] },
  { symbol: "BOOM1000", name: "Boom 1000 Index", market: "synthetic", submarket: "Crash/Boom", decimals: 3, start: 12456.789, sigma: v(0.3), kind: "boom", spikeEvery: 1000, multipliers: [100, 200, 300, 400] },
  { symbol: "CRASH300", name: "Crash 300 Index", market: "synthetic", submarket: "Crash/Boom", decimals: 3, start: 2987.654, sigma: v(0.3), kind: "crash", spikeEvery: 300, multipliers: [100, 200, 300] },
  { symbol: "CRASH500", name: "Crash 500 Index", market: "synthetic", submarket: "Crash/Boom", decimals: 3, start: 4321.123, sigma: v(0.3), kind: "crash", spikeEvery: 500, multipliers: [100, 200, 300, 400] },
  { symbol: "CRASH1000", name: "Crash 1000 Index", market: "synthetic", submarket: "Crash/Boom", decimals: 3, start: 6789.012, sigma: v(0.3), kind: "crash", spikeEvery: 1000, multipliers: [100, 200, 300, 400] },
  // Derived — Step / Jump
  { symbol: "STPRNG", name: "Step Index", market: "synthetic", submarket: "Step Indices", decimals: 1, start: 8234.5, sigma: 0.1 / 8234.5, kind: "step", multipliers: [200, 500, 1000, 2000] },
  { symbol: "JD10", name: "Jump 10 Index", market: "synthetic", submarket: "Jump Indices", decimals: 2, start: 9876.54, sigma: v(0.1), kind: "jump", multipliers: synthMult },
  { symbol: "JD25", name: "Jump 25 Index", market: "synthetic", submarket: "Jump Indices", decimals: 2, start: 4567.89, sigma: v(0.25), kind: "jump", multipliers: synthMult },
  { symbol: "JD50", name: "Jump 50 Index", market: "synthetic", submarket: "Jump Indices", decimals: 2, start: 3456.78, sigma: v(0.5), kind: "jump", multipliers: synthMult },
  { symbol: "JD100", name: "Jump 100 Index", market: "synthetic", submarket: "Jump Indices", decimals: 2, start: 2345.67, sigma: v(1.0), kind: "jump", multipliers: synthMult },
  // Forex
  { symbol: "frxEURUSD", name: "EUR/USD", market: "forex", submarket: "Major Pairs", decimals: 5, start: 1.08542, sigma: v(0.08, 3), kind: "gbm", multipliers: fxMult },
  { symbol: "frxGBPUSD", name: "GBP/USD", market: "forex", submarket: "Major Pairs", decimals: 5, start: 1.27134, sigma: v(0.09, 3), kind: "gbm", multipliers: fxMult },
  { symbol: "frxUSDJPY", name: "USD/JPY", market: "forex", submarket: "Major Pairs", decimals: 3, start: 151.482, sigma: v(0.1, 3), kind: "gbm", multipliers: fxMult },
  { symbol: "frxAUDUSD", name: "AUD/USD", market: "forex", submarket: "Major Pairs", decimals: 5, start: 0.65821, sigma: v(0.1, 3), kind: "gbm", multipliers: fxMult },
  { symbol: "frxUSDCAD", name: "USD/CAD", market: "forex", submarket: "Major Pairs", decimals: 5, start: 1.36214, sigma: v(0.07, 3), kind: "gbm", multipliers: fxMult },
  { symbol: "frxUSDCHF", name: "USD/CHF", market: "forex", submarket: "Major Pairs", decimals: 5, start: 0.88412, sigma: v(0.08, 3), kind: "gbm", multipliers: fxMult },
  { symbol: "frxNZDUSD", name: "NZD/USD", market: "forex", submarket: "Major Pairs", decimals: 5, start: 0.60234, sigma: v(0.1, 3), kind: "gbm", multipliers: fxMult },
  { symbol: "frxEURGBP", name: "EUR/GBP", market: "forex", submarket: "Minor Pairs", decimals: 5, start: 0.85376, sigma: v(0.06, 3), kind: "gbm", multipliers: fxMult },
  { symbol: "frxEURJPY", name: "EUR/JPY", market: "forex", submarket: "Minor Pairs", decimals: 3, start: 164.421, sigma: v(0.1, 3), kind: "gbm", multipliers: fxMult },
  { symbol: "frxGBPJPY", name: "GBP/JPY", market: "forex", submarket: "Minor Pairs", decimals: 3, start: 192.587, sigma: v(0.11, 3), kind: "gbm", multipliers: fxMult },
  { symbol: "frxUSDKES", name: "USD/KES", market: "forex", submarket: "Exotic Pairs", decimals: 3, start: 129.45, sigma: v(0.06, 3), kind: "gbm", multipliers: [20, 50, 100] },
  { symbol: "frxUSDZAR", name: "USD/ZAR", market: "forex", submarket: "Exotic Pairs", decimals: 4, start: 18.4521, sigma: v(0.15, 3), kind: "gbm", multipliers: [20, 50, 100] },
  // Indices
  { symbol: "OTC_SPC", name: "US 500", market: "indices", submarket: "American Indices", decimals: 2, start: 5832.45, sigma: v(0.18, 2), kind: "gbm", multipliers: idxMult },
  { symbol: "OTC_NDX", name: "US Tech 100", market: "indices", submarket: "American Indices", decimals: 2, start: 20512.3, sigma: v(0.22, 2), kind: "gbm", multipliers: idxMult },
  { symbol: "OTC_DJI", name: "Wall Street 30", market: "indices", submarket: "American Indices", decimals: 2, start: 42318.7, sigma: v(0.16, 2), kind: "gbm", multipliers: idxMult },
  { symbol: "OTC_FTSE", name: "UK 100", market: "indices", submarket: "European Indices", decimals: 2, start: 8245.12, sigma: v(0.15, 2), kind: "gbm", multipliers: idxMult },
  { symbol: "OTC_GDAXI", name: "Germany 40", market: "indices", submarket: "European Indices", decimals: 2, start: 19234.56, sigma: v(0.18, 2), kind: "gbm", multipliers: idxMult },
  { symbol: "OTC_N225", name: "Japan 225", market: "indices", submarket: "Asian Indices", decimals: 2, start: 38912.4, sigma: v(0.2, 2), kind: "gbm", multipliers: idxMult },
  // Commodities
  { symbol: "frxXAUUSD", name: "Gold/USD", market: "commodities", submarket: "Metals", decimals: 2, start: 2654.32, sigma: v(0.15, 2.5), kind: "gbm", multipliers: comMult },
  { symbol: "frxXAGUSD", name: "Silver/USD", market: "commodities", submarket: "Metals", decimals: 4, start: 31.2456, sigma: v(0.25, 2.5), kind: "gbm", multipliers: comMult },
  { symbol: "frxXPTUSD", name: "Platinum/USD", market: "commodities", submarket: "Metals", decimals: 2, start: 978.45, sigma: v(0.22, 2.5), kind: "gbm", multipliers: comMult },
  { symbol: "WTI_OIL", name: "Oil/USD (WTI)", market: "commodities", submarket: "Energy", decimals: 3, start: 71.245, sigma: v(0.35, 2), kind: "gbm", multipliers: comMult },
  { symbol: "BRENT_OIL", name: "Brent Crude", market: "commodities", submarket: "Energy", decimals: 3, start: 75.812, sigma: v(0.33, 2), kind: "gbm", multipliers: comMult },
  { symbol: "NATGAS", name: "Natural Gas", market: "commodities", submarket: "Energy", decimals: 4, start: 2.8456, sigma: v(0.5, 2), kind: "gbm", multipliers: comMult },
  // Crypto
  { symbol: "cryBTCUSD", name: "BTC/USD", market: "crypto", submarket: "Cryptocurrencies", decimals: 2, start: 97250.0, sigma: v(0.55, 2), kind: "gbm", multipliers: cryMult },
  { symbol: "cryETHUSD", name: "ETH/USD", market: "crypto", submarket: "Cryptocurrencies", decimals: 2, start: 3420.5, sigma: v(0.7, 2), kind: "gbm", multipliers: cryMult },
  { symbol: "crySOLUSD", name: "SOL/USD", market: "crypto", submarket: "Cryptocurrencies", decimals: 3, start: 192.345, sigma: v(0.9, 2), kind: "gbm", multipliers: cryMult },
  { symbol: "cryBNBUSD", name: "BNB/USD", market: "crypto", submarket: "Cryptocurrencies", decimals: 2, start: 645.3, sigma: v(0.6, 2), kind: "gbm", multipliers: cryMult },
  { symbol: "cryXRPUSD", name: "XRP/USD", market: "crypto", submarket: "Cryptocurrencies", decimals: 5, start: 2.31456, sigma: v(0.9, 2), kind: "gbm", multipliers: cryMult },
  { symbol: "cryLTCUSD", name: "LTC/USD", market: "crypto", submarket: "Cryptocurrencies", decimals: 3, start: 102.456, sigma: v(0.8, 2), kind: "gbm", multipliers: cryMult },
  { symbol: "cryDOGEUSD", name: "DOGE/USD", market: "crypto", submarket: "Cryptocurrencies", decimals: 5, start: 0.32145, sigma: v(1.0, 2), kind: "gbm", multipliers: cryMult },
  // Stocks
  { symbol: "stkAAPL", name: "Apple", market: "stocks", submarket: "US Stocks", decimals: 2, start: 228.45, sigma: v(0.28, 2), kind: "gbm", multipliers: stkMult },
  { symbol: "stkTSLA", name: "Tesla", market: "stocks", submarket: "US Stocks", decimals: 2, start: 342.12, sigma: v(0.6, 2), kind: "gbm", multipliers: stkMult },
  { symbol: "stkAMZN", name: "Amazon", market: "stocks", submarket: "US Stocks", decimals: 2, start: 205.78, sigma: v(0.32, 2), kind: "gbm", multipliers: stkMult },
  { symbol: "stkMSFT", name: "Microsoft", market: "stocks", submarket: "US Stocks", decimals: 2, start: 425.34, sigma: v(0.25, 2), kind: "gbm", multipliers: stkMult },
  { symbol: "stkGOOGL", name: "Alphabet", market: "stocks", submarket: "US Stocks", decimals: 2, start: 172.56, sigma: v(0.3, 2), kind: "gbm", multipliers: stkMult },
  { symbol: "stkMETA", name: "Meta Platforms", market: "stocks", submarket: "US Stocks", decimals: 2, start: 568.9, sigma: v(0.38, 2), kind: "gbm", multipliers: stkMult },
  { symbol: "stkNVDA", name: "NVIDIA", market: "stocks", submarket: "US Stocks", decimals: 2, start: 138.25, sigma: v(0.55, 2), kind: "gbm", multipliers: stkMult },
  { symbol: "stkNFLX", name: "Netflix", market: "stocks", submarket: "US Stocks", decimals: 2, start: 812.4, sigma: v(0.4, 2), kind: "gbm", multipliers: stkMult },
];

export const SYMBOL_MAP: Record<string, SymbolDef> = Object.fromEntries(SYMBOLS.map((s) => [s.symbol, s]));

export function getSymbol(sym: string): SymbolDef | undefined {
  return SYMBOL_MAP[sym];
}

export function formatPrice(price: number, decimals: number) {
  return price.toLocaleString("en-US", { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
}

export function lastDigit(price: number, decimals: number) {
  return Math.round(price * Math.pow(10, decimals)) % 10;
}

export function isVolatility(s: SymbolDef) {
  return s.market === "synthetic" && (s.symbol.startsWith("R_") || s.symbol.startsWith("1HZ"));
}
