import { cookies } from "next/headers";
import { randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { accounts, sessions, users, type Account, type User } from "@/db/schema";

export const SESSION_COOKIE = "tv_session";
const SESSION_DAYS = 30;

export function hashPassword(pw: string) {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(pw, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(pw: string, stored: string) {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const test = scryptSync(pw, salt, 64);
  const buf = Buffer.from(hash, "hex");
  return buf.length === test.length && timingSafeEqual(buf, test);
}

export function normalizePhone(input: string) {
  let p = input.replace(/[\s\-()]/g, "");
  if (p.startsWith("+")) return "+" + p.slice(1).replace(/\D/g, "");
  p = p.replace(/\D/g, "");
  if (p.startsWith("0") && p.length === 10) return "+254" + p.slice(1);
  if ((p.startsWith("7") || p.startsWith("1")) && p.length === 9) return "+254" + p;
  return "+" + p;
}

export function isEmail(s: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);
}

function randomDigits(n: number) {
  let s = "";
  for (let i = 0; i < n; i++) s += Math.floor(Math.random() * 10);
  return s;
}

export async function createAccountsFor(userId: number) {
  const [demo] = await db
    .insert(accounts)
    .values({ userId, type: "demo", loginId: "VRTC" + randomDigits(7), balance: 10000 })
    .returning();
  const [real] = await db
    .insert(accounts)
    .values({ userId, type: "real", loginId: "CR" + randomDigits(7), balance: 0 })
    .returning();
  return { demo, real };
}

export async function ensureAdmin() {
  const email = (process.env.ADMIN_EMAIL || "admin@tradova.com").toLowerCase();
  const existing = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (existing.length) return;
  const [u] = await db
    .insert(users)
    .values({
      email,
      fullName: "Platform Admin",
      passwordHash: hashPassword(process.env.ADMIN_PASSWORD || "Admin@12345"),
      role: "admin",
      kycStatus: "verified",
    })
    .onConflictDoNothing()
    .returning();
  if (u) await createAccountsFor(u.id);
}

export async function createSession(userId: number, activeAccountId: number) {
  const id = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86400 * 1000);
  await db.insert(sessions).values({ id, userId, activeAccountId, expiresAt });
  const c = await cookies();
  c.set(SESSION_COOKIE, id, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    expires: expiresAt,
    secure: process.env.SECURE_COOKIES === "1",
  });
  return id;
}

export async function destroySession() {
  const c = await cookies();
  const id = c.get(SESSION_COOKIE)?.value;
  if (id) await db.delete(sessions).where(eq(sessions.id, id));
  c.delete(SESSION_COOKIE);
}

export interface AuthContext {
  sessionId: string;
  user: User;
  accounts: Account[];
  active: Account;
}

export async function getAuth(): Promise<AuthContext | null> {
  const c = await cookies();
  const id = c.get(SESSION_COOKIE)?.value;
  if (!id) return null;
  const [s] = await db
    .select()
    .from(sessions)
    .where(and(eq(sessions.id, id), gt(sessions.expiresAt, new Date())))
    .limit(1);
  if (!s) return null;
  const [user] = await db.select().from(users).where(eq(users.id, s.userId)).limit(1);
  if (!user || user.disabled) return null;
  const accs = await db.select().from(accounts).where(eq(accounts.userId, user.id)).orderBy(accounts.id);
  if (!accs.length) return null;
  const active = accs.find((a) => a.id === s.activeAccountId) ?? accs.find((a) => a.type === "demo") ?? accs[0];
  return { sessionId: id, user, accounts: accs, active };
}

export class HttpError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

export async function requireAuth() {
  const a = await getAuth();
  if (!a) throw new HttpError(401, "Please log in to continue");
  return a;
}

export async function requireAdmin() {
  const a = await requireAuth();
  if (a.user.role !== "admin") throw new HttpError(403, "Admin access required");
  return a;
}

export function handleError(e: unknown) {
  if (e instanceof HttpError) return Response.json({ error: e.message }, { status: e.status });
  console.error(e);
  return Response.json({ error: e instanceof Error ? e.message : "Something went wrong" }, { status: 500 });
}

export function publicUser(u: User) {
  return {
    id: u.id,
    email: u.email,
    phone: u.phone,
    fullName: u.fullName,
    country: u.country,
    role: u.role,
    kycStatus: u.kycStatus,
  };
}
