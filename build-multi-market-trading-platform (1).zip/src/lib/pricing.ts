import { SymbolDef, isVolatility } from "./markets";

export type TradeGroup =
  | "rise_fall"
  | "higher_lower"
  | "touch"
  | "matches_differs"
  | "even_odd"
  | "over_under"
  | "multipliers"
  | "accumulators";

export type DurationUnit = "t" | "s" | "m" | "h";

export const TRADE_GROUPS: {
  key: TradeGroup;
  label: string;
  category: "Options" | "Digits" | "Multipliers" | "Accumulators";
  sides: { type: string; label: string; color: "green" | "red" }[];
  desc: string;
}[] = [
  { key: "rise_fall", label: "Rise/Fall", category: "Options", sides: [{ type: "CALL", label: "Rise", color: "green" }, { type: "PUT", label: "Fall", color: "red" }], desc: "Predict whether the exit spot will be strictly higher or lower than the entry spot." },
  { key: "higher_lower", label: "Higher/Lower", category: "Options", sides: [{ type: "HIGHER", label: "Higher", color: "green" }, { type: "LOWER", label: "Lower", color: "red" }], desc: "Predict whether the exit spot will be higher or lower than a price target (the barrier)." },
  { key: "touch", label: "Touch/No Touch", category: "Options", sides: [{ type: "TOUCH", label: "Touch", color: "green" }, { type: "NOTOUCH", label: "No Touch", color: "red" }], desc: "Predict whether the market will touch or not touch a target at any time during the contract." },
  { key: "matches_differs", label: "Matches/Differs", category: "Digits", sides: [{ type: "DIGITMATCH", label: "Matches", color: "green" }, { type: "DIGITDIFF", label: "Differs", color: "red" }], desc: "Predict whether the last digit of the last tick will match or differ from your chosen number." },
  { key: "even_odd", label: "Even/Odd", category: "Digits", sides: [{ type: "DIGITEVEN", label: "Even", color: "green" }, { type: "DIGITODD", label: "Odd", color: "red" }], desc: "Predict whether the last digit of the last tick will be an even or odd number." },
  { key: "over_under", label: "Over/Under", category: "Digits", sides: [{ type: "DIGITOVER", label: "Over", color: "green" }, { type: "DIGITUNDER", label: "Under", color: "red" }], desc: "Predict whether the last digit of the last tick will be higher or lower than your chosen number." },
  { key: "multipliers", label: "Multipliers", category: "Multipliers", sides: [{ type: "MULTUP", label: "Up", color: "green" }, { type: "MULTDOWN", label: "Down", color: "red" }], desc: "Amplify your potential profit with a multiplier while limiting your loss to your stake." },
  { key: "accumulators", label: "Accumulators", category: "Accumulators", sides: [{ type: "ACCU", label: "Buy", color: "green" }], desc: "Your payout grows by the growth rate every tick, as long as the price stays within the barrier range." },
];

export const CONTRACT_LABELS: Record<string, string> = {
  CALL: "Rise", PUT: "Fall", HIGHER: "Higher", LOWER: "Lower", TOUCH: "Touch", NOTOUCH: "No Touch",
  DIGITMATCH: "Matches", DIGITDIFF: "Differs", DIGITEVEN: "Even", DIGITODD: "Odd", DIGITOVER: "Over", DIGITUNDER: "Under",
  MULTUP: "Multiplier Up", MULTDOWN: "Multiplier Down", ACCU: "Accumulator",
};

export function groupOf(contractType: string): TradeGroup {
  return TRADE_GROUPS.find((g) => g.sides.some((s) => s.type === contractType))!.key;
}

export function availableGroups(s: SymbolDef): TradeGroup[] {
  const base: TradeGroup[] = ["rise_fall", "higher_lower", "touch", "multipliers"];
  if (s.market === "synthetic") base.push("matches_differs", "even_odd", "over_under");
  if (isVolatility(s)) base.push("accumulators");
  return base;
}

export function unitsFor(group: TradeGroup, s: SymbolDef): DurationUnit[] {
  if (group === "matches_differs" || group === "even_odd" || group === "over_under") return ["t"];
  if (group === "multipliers" || group === "accumulators") return [];
  if (s.market === "synthetic") return ["t", "s", "m", "h"];
  return ["s", "m", "h"];
}

export const UNIT_LIMITS: Record<DurationUnit, { min: number; max: number; label: string }> = {
  t: { min: 1, max: 10, label: "Ticks" },
  s: { min: 15, max: 3600, label: "Seconds" },
  m: { min: 1, max: 240, label: "Minutes" },
  h: { min: 1, max: 4, label: "Hours" },
};

export function durationSec(value: number, unit: DurationUnit) {
  return unit === "h" ? value * 3600 : unit === "m" ? value * 60 : value;
}

export function durationLabel(value: number, unit: DurationUnit) {
  const names: Record<DurationUnit, string> = { t: "tick", s: "second", m: "minute", h: "hour" };
  return `${value} ${names[unit]}${value === 1 ? "" : "s"}`;
}

export const GROWTH_RATES = [0.01, 0.02, 0.03, 0.04, 0.05];
const ACCU_K: Record<string, number> = { "0.01": 2.33, "0.02": 2.18, "0.03": 2.07, "0.04": 1.98, "0.05": 1.9 };
export function accuRange(growth: number, sigma: number) {
  return (ACCU_K[growth.toFixed(2)] ?? 2.33) * sigma;
}
export const ACCU_MAX_TICKS: Record<string, number> = { "0.01": 230, "0.02": 120, "0.03": 80, "0.04": 60, "0.05": 50 };
export const MULT_COMMISSION = 0.0003;

export function normCdf(x: number) {
  const t = 1 / (1 + 0.2316419 * Math.abs(x));
  const d = 0.3989423 * Math.exp((-x * x) / 2);
  const p = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274))));
  return x > 0 ? 1 - p : p;
}

export function probAbove(spot: number, barrier: number, sigma: number, T: number) {
  if (T <= 0) return spot > barrier ? 1 : 0;
  return normCdf(Math.log(spot / barrier) / (sigma * Math.sqrt(T)));
}

export function probTouch(spot: number, barrier: number, sigma: number, T: number) {
  if (T <= 0) return 0;
  const d = Math.abs(Math.log(barrier / spot)) / (sigma * Math.sqrt(T));
  return Math.min(1, 2 * (1 - normCdf(d)));
}

export function digitProb(type: string, digit: number) {
  switch (type) {
    case "DIGITMATCH": return 0.1;
    case "DIGITDIFF": return 0.9;
    case "DIGITEVEN":
    case "DIGITODD": return 0.5;
    case "DIGITOVER": return (9 - digit) / 10;
    case "DIGITUNDER": return digit / 10;
  }
  return 0;
}

export interface QuoteInput {
  contractType: string;
  stake: number;
  spot: number;
  sym: SymbolDef;
  durationSec?: number;
  barrierOffset?: number;
  digit?: number;
}

export interface Quote {
  payout?: number;
  probability?: number;
  error?: string;
}

function round2(n: number) {
  return Math.round(n * 100) / 100;
}

export function quote(q: QuoteInput): Quote {
  const { contractType: ct, stake, spot, sym } = q;
  if (!(stake >= 0.35)) return { error: "Minimum stake is 0.35 USD" };
  if (stake > 50000) return { error: "Maximum stake is 50,000 USD" };
  const T = q.durationSec ?? 0;
  let p = 0;
  let margin = 1.026;
  if (ct === "CALL" || ct === "PUT") p = 0.5;
  else if (ct === "HIGHER" || ct === "LOWER" || ct === "TOUCH" || ct === "NOTOUCH") {
    const off = q.barrierOffset ?? 0;
    if (!isFinite(off)) return { error: "Invalid barrier" };
    const barrier = spot + off;
    if (barrier <= 0) return { error: "Invalid barrier" };
    if ((ct === "TOUCH" || ct === "NOTOUCH") && off === 0) return { error: "Barrier offset cannot be zero" };
    if (ct === "HIGHER") p = probAbove(spot, barrier, sym.sigma, T);
    if (ct === "LOWER") p = 1 - probAbove(spot, barrier, sym.sigma, T);
    if (ct === "TOUCH") p = probTouch(spot, barrier, sym.sigma, T);
    if (ct === "NOTOUCH") p = 1 - probTouch(spot, barrier, sym.sigma, T);
    margin = 1.035;
  } else if (ct.startsWith("DIGIT")) {
    const d = q.digit ?? 0;
    if (ct === "DIGITOVER" && (d < 0 || d > 8)) return { error: "Over digit must be 0–8" };
    if (ct === "DIGITUNDER" && (d < 1 || d > 9)) return { error: "Under digit must be 1–9" };
    p = digitProb(ct, d);
    margin = ct === "DIGITMATCH" || ct === "DIGITDIFF" ? 1.05 : 1.026;
  } else return {};
  if (p < 0.03) return { error: "Barrier is too far from the current spot" };
  if (p > 0.96) return { error: "Barrier is too close — payout would be below stake" };
  const payout = round2(stake / (p * margin));
  if (payout <= stake) return { error: "Payout is below stake. Adjust your contract." };
  return { payout, probability: p };
}

export function suggestedOffset(sym: SymbolDef, spot: number, T: number) {
  const raw = spot * sym.sigma * Math.sqrt(Math.max(T, 5)) * 0.6;
  const unit = Math.pow(10, -sym.decimals);
  return Math.max(unit, Number((Math.round(raw / unit) * unit).toFixed(sym.decimals)));
}
