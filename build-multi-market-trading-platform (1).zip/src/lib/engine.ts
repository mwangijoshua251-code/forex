import { SYMBOLS, SymbolDef } from "./markets";

const HISTORY = 14400; // 4 hours of 1-second ticks

interface Series {
  def: SymbolDef;
  prices: number[];
  baseTime: number; // epoch seconds of prices[0]
}

function gauss() {
  let u = 0;
  let v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

function roundTo(n: number, d: number) {
  const f = Math.pow(10, d);
  return Math.round(n * f) / f;
}

function nextPrice(def: SymbolDef, prev: number): number {
  let p: number;
  switch (def.kind) {
    case "step":
      p = prev + (Math.random() < 0.5 ? -0.1 : 0.1);
      break;
    case "boom":
    case "crash": {
      const every = def.spikeEvery ?? 1000;
      const meanSpike = 0.0025;
      const dir = def.kind === "boom" ? 1 : -1;
      if (Math.random() < 1 / every) {
        p = prev * (1 + dir * (0.001 + Math.random() * 0.003));
      } else {
        p = prev * Math.exp(def.sigma * gauss() - (dir * meanSpike) / every);
      }
      break;
    }
    case "jump": {
      let r = def.sigma * gauss();
      if (Math.random() < 3 / 3600) r += (Math.random() < 0.5 ? -1 : 1) * 30 * def.sigma;
      p = prev * Math.exp(r);
      break;
    }
    default: {
      const revert = def.market === "synthetic" ? 0 : -0.00002 * Math.log(prev / def.start);
      p = prev * Math.exp(def.sigma * gauss() + revert);
    }
  }
  return roundTo(Math.max(p, Math.pow(10, -def.decimals)), def.decimals);
}

export class PriceEngine {
  series = new Map<string, Series>();
  lastTime: number;

  constructor() {
    const now = Math.floor(Date.now() / 1000);
    this.lastTime = now;
    for (const def of SYMBOLS) {
      const prices: number[] = new Array(HISTORY);
      let p = def.start;
      for (let i = 0; i < HISTORY; i++) {
        p = nextPrice(def, p);
        prices[i] = p;
      }
      this.series.set(def.symbol, { def, prices, baseTime: now - HISTORY + 1 });
    }
  }

  advance() {
    const now = Math.floor(Date.now() / 1000);
    if (now <= this.lastTime) return;
    const steps = Math.min(now - this.lastTime, HISTORY);
    for (const s of this.series.values()) {
      for (let i = 0; i < steps; i++) {
        s.prices.push(nextPrice(s.def, s.prices[s.prices.length - 1]));
      }
      const extra = s.prices.length - HISTORY;
      if (extra > 0) {
        s.prices.splice(0, extra);
      }
      s.baseTime = now - s.prices.length + 1;
    }
    this.lastTime = now;
  }

  private get(sym: string) {
    this.advance();
    return this.series.get(sym);
  }

  latest(sym: string) {
    const s = this.get(sym);
    if (!s) return null;
    return { time: this.lastTime, price: s.prices[s.prices.length - 1] };
  }

  priceAt(sym: string, t: number): number | null {
    const s = this.get(sym);
    if (!s) return null;
    const idx = t - s.baseTime;
    if (idx < 0) return s.prices[0];
    if (idx >= s.prices.length) return null;
    return s.prices[idx];
  }

  /** ticks with time in [t0, t1] inclusive */
  range(sym: string, t0: number, t1: number): { time: number; price: number }[] {
    const s = this.get(sym);
    if (!s) return [];
    const out: { time: number; price: number }[] = [];
    const a = Math.max(0, t0 - s.baseTime);
    const b = Math.min(s.prices.length - 1, t1 - s.baseTime);
    for (let i = a; i <= b; i++) out.push({ time: s.baseTime + i, price: s.prices[i] });
    return out;
  }

  history(sym: string, count: number) {
    const s = this.get(sym);
    if (!s) return [];
    return this.range(sym, this.lastTime - Math.min(count, HISTORY) + 1, this.lastTime);
  }

  quotes() {
    this.advance();
    const out: Record<string, { price: number; change: number; prev: number }> = {};
    for (const [sym, s] of this.series) {
      const last = s.prices[s.prices.length - 1];
      const prev = s.prices[s.prices.length - 2] ?? last;
      const first = s.prices[0];
      out[sym] = { price: last, prev, change: ((last - first) / first) * 100 };
    }
    return out;
  }
}

const g = globalThis as typeof globalThis & { __priceEngine?: PriceEngine };

export function getEngine(): PriceEngine {
  if (!g.__priceEngine) g.__priceEngine = new PriceEngine();
  return g.__priceEngine;
}
