import { createHash, randomBytes } from "crypto";
import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { payments, type Payment } from "@/db/schema";
import { getEngine } from "./engine";
import { AuthContext, HttpError, normalizePhone } from "./auth";
import { adjustBalance, notify, round2 } from "./ledger";
import { mpesaConfigured, stkPush } from "./mpesa";
import { METHODS, type MethodKey } from "./methods";

export function rates() {
  const eng = getEngine();
  const kes = Number(process.env.MPESA_KES_RATE) || eng.latest("frxUSDKES")!.price;
  return {
    USDT: 1,
    BTC: eng.latest("cryBTCUSD")!.price,
    ETH: eng.latest("cryETHUSD")!.price,
    KES_DEPOSIT: round2(kes * 1.01),
    KES_WITHDRAW: round2(kes * 0.99),
  };
}

function assetRate(method: MethodKey, kind: "deposit" | "withdrawal") {
  const r = rates();
  const asset = METHODS[method].asset;
  if (asset === "KES") return kind === "deposit" ? r.KES_DEPOSIT : r.KES_WITHDRAW;
  return r[asset as "USDT" | "BTC" | "ETH"];
}

/** USD → asset conversion */
export function toAsset(method: MethodKey, usd: number, kind: "deposit" | "withdrawal") {
  const rate = assetRate(method, kind);
  const asset = METHODS[method].asset;
  if (asset === "KES") return { amount: Math.round(usd * rate), rate };
  if (asset === "USDT") return { amount: round2(usd), rate };
  return { amount: Number((usd / rate).toFixed(8)), rate };
}

const B58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
const BECH = "qpzry9x8gf2tvdw0s3jn54khce6mua7l";
function encode(seed: string, alphabet: string, len: number) {
  let h = createHash("sha512").update(seed).digest();
  let out = "";
  while (out.length < len) {
    for (const b of h) {
      if (out.length >= len) break;
      out += alphabet[b % alphabet.length];
    }
    h = createHash("sha512").update(h).digest();
  }
  return out;
}

export function depositAddress(userId: number, method: MethodKey) {
  const override = process.env[`DEPOSIT_ADDRESS_${method}`];
  if (override) return override;
  const seed = `${process.env.ADDRESS_SEED || "tradova"}:${userId}:${method}`;
  if (method === "USDT_TRC20") return "T" + encode(seed, B58, 33);
  if (method === "BTC") return "bc1q" + encode(seed, BECH, 38);
  return "0x" + createHash("sha256").update(seed).digest("hex").slice(0, 40);
}

export function validateAddress(method: MethodKey, address: string) {
  if (method === "USDT_TRC20") return /^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(address);
  if (method === "BTC") return /^(bc1[a-z0-9]{25,62}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})$/.test(address);
  if (method === "ETH" || method === "USDT_ERC20") return /^0x[a-fA-F0-9]{40}$/.test(address);
  return false;
}

function ref(prefix: string) {
  return `${prefix}-${randomBytes(4).toString("hex").toUpperCase()}`;
}

function mpesaReceipt() {
  const L = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let s = "T";
  for (let i = 0; i < 9; i++) s += L[Math.floor(Math.random() * L.length)];
  return s;
}

function requireReal(auth: AuthContext) {
  const real = auth.accounts.find((a) => a.type === "real");
  if (!real) throw new HttpError(400, "No real account found");
  return real;
}

export async function createDeposit(
  auth: AuthContext,
  input: { method: MethodKey; amountUsd?: number; amountKes?: number; txHash?: string; phone?: string }
) {
  const m = METHODS[input.method];
  if (!m) throw new HttpError(400, "Unsupported payment method");
  const real = requireReal(auth);

  if (input.method === "MPESA") {
    const kes = Math.round(Number(input.amountKes));
    if (!(kes >= m.minKes! && kes <= m.maxKes!)) throw new HttpError(400, `M-Pesa amount must be KES ${m.minKes}–${m.maxKes!.toLocaleString()}`);
    const phone = normalizePhone(input.phone || "");
    if (!/^\+254(7|1)\d{8}$/.test(phone)) throw new HttpError(400, "Enter a valid Safaricom number e.g. 0712345678");
    const rate = assetRate("MPESA", "deposit");
    const usd = round2(kes / rate);
    const reference = ref("MP");
    let checkout: string | null = null;
    if (mpesaConfigured()) checkout = await stkPush(phone, kes, reference);
    const [p] = await db
      .insert(payments)
      .values({
        userId: auth.user.id,
        accountId: real.id,
        kind: "deposit",
        method: "MPESA",
        amountUsd: usd,
        assetAmount: kes,
        assetCurrency: "KES",
        rate,
        phone,
        txHash: checkout,
        reference,
        status: "processing",
        note: checkout ? "STK push sent. Enter your M-Pesa PIN on your phone." : "STK push sent (simulation). Payment will auto-confirm.",
      })
      .returning();
    return p;
  }

  const usd = round2(Number(input.amountUsd));
  if (!(usd >= m.minDeposit)) throw new HttpError(400, `Minimum deposit is ${m.minDeposit} USD`);
  if (usd > 100000) throw new HttpError(400, "Maximum deposit is 100,000 USD");
  const txHash = (input.txHash || "").trim();
  if (txHash.length < 10) throw new HttpError(400, "Enter the transaction hash (TXID) of your transfer");
  const dup = await db.select({ id: payments.id }).from(payments).where(eq(payments.txHash, txHash)).limit(1);
  if (dup.length) throw new HttpError(400, "This transaction hash has already been submitted");
  const { amount, rate } = toAsset(input.method, usd, "deposit");
  const [p] = await db
    .insert(payments)
    .values({
      userId: auth.user.id,
      accountId: real.id,
      kind: "deposit",
      method: input.method,
      amountUsd: usd,
      assetAmount: amount,
      assetCurrency: m.asset,
      rate,
      address: depositAddress(auth.user.id, input.method),
      txHash,
      reference: ref("DP"),
      requiredConfirmations: m.confirmations,
      status: "pending",
      note: "Waiting for blockchain confirmations",
    })
    .returning();
  return p;
}

export async function createWithdrawal(
  auth: AuthContext,
  input: { method: MethodKey; amountUsd: number; address?: string; phone?: string }
) {
  const m = METHODS[input.method];
  if (!m) throw new HttpError(400, "Unsupported payment method");
  const real = requireReal(auth);
  if (auth.user.kycStatus === "unverified")
    throw new HttpError(403, "Please verify your identity (Profile → Verification) before withdrawing");
  const usd = round2(Number(input.amountUsd));
  if (!(usd >= m.minWithdraw)) throw new HttpError(400, `Minimum withdrawal is ${m.minWithdraw} USD`);
  if (usd > real.balance) throw new HttpError(400, "Insufficient balance");
  if (input.method === "MPESA" && usd > 1000) throw new HttpError(400, "Maximum M-Pesa withdrawal is 1,000 USD per transaction");
  let address: string | null = null;
  let phone: string | null = null;
  if (input.method === "MPESA") {
    phone = normalizePhone(input.phone || "");
    if (!/^\+254(7|1)\d{8}$/.test(phone)) throw new HttpError(400, "Enter a valid Safaricom number");
  } else {
    address = (input.address || "").trim();
    if (!validateAddress(input.method, address)) throw new HttpError(400, `Invalid ${m.label} address`);
  }
  const net = usd - m.withdrawFee;
  if (net <= 0) throw new HttpError(400, "Amount must exceed the network fee");
  const { amount, rate } = toAsset(input.method, net, "withdrawal");
  return db.transaction(async (tx) => {
    const [p] = await tx
      .insert(payments)
      .values({
        userId: auth.user.id,
        accountId: real.id,
        kind: "withdrawal",
        method: input.method,
        amountUsd: usd,
        feeUsd: m.withdrawFee,
        assetAmount: amount,
        assetCurrency: m.asset,
        rate,
        address,
        phone,
        reference: ref("WD"),
        status: "pending",
        note: "Awaiting compliance review",
      })
      .returning();
    await adjustBalance(tx, {
      accountId: real.id,
      userId: auth.user.id,
      delta: -usd,
      type: "withdrawal",
      description: `Withdrawal via ${m.label} (${p.reference})`,
      reference: p.reference,
      paymentId: p.id,
    });
    return p;
  });
}

export async function completeDeposit(id: number, extra: Partial<Payment> = {}) {
  return db.transaction(async (tx) => {
    const [p] = await tx
      .update(payments)
      .set({ ...extra, status: "completed", note: "Funds credited", updatedAt: new Date() })
      .where(and(eq(payments.id, id), eq(payments.kind, "deposit"), inArray(payments.status, ["pending", "processing"])))
      .returning();
    if (!p) return null;
    await adjustBalance(tx, {
      accountId: p.accountId,
      userId: p.userId,
      delta: p.amountUsd,
      type: "deposit",
      description: `Deposit via ${METHODS[p.method as MethodKey].label} (${p.reference})`,
      reference: p.reference,
      paymentId: p.id,
    });
    await notify(tx, p.userId, "Deposit successful", `${p.amountUsd.toFixed(2)} USD has been credited to your real account.`);
    return p;
  });
}

export async function failPayment(id: number, reason: string) {
  return db.transaction(async (tx) => {
    const [p] = await tx
      .update(payments)
      .set({ status: "failed", note: reason, updatedAt: new Date() })
      .where(and(eq(payments.id, id), inArray(payments.status, ["pending", "processing"])))
      .returning();
    if (p && p.kind === "withdrawal") {
      await adjustBalance(tx, { accountId: p.accountId, userId: p.userId, delta: p.amountUsd, type: "refund", description: `Withdrawal ${p.reference} reversed`, reference: p.reference, paymentId: p.id });
    }
    if (p) await notify(tx, p.userId, `${p.kind === "deposit" ? "Deposit" : "Withdrawal"} failed`, reason);
    return p;
  });
}

export async function approveWithdrawal(id: number, txHash?: string) {
  return db.transaction(async (tx) => {
    const [cur] = await tx.select().from(payments).where(eq(payments.id, id)).limit(1);
    if (!cur || cur.kind !== "withdrawal") throw new HttpError(404, "Withdrawal not found");
    const hash = txHash || (cur.method === "MPESA" ? mpesaReceipt() : (cur.method === "USDT_TRC20" || cur.method === "BTC" ? "" : "0x") + randomBytes(32).toString("hex"));
    const [p] = await tx
      .update(payments)
      .set({ status: "completed", txHash: hash, note: "Payment sent", updatedAt: new Date() })
      .where(and(eq(payments.id, id), inArray(payments.status, ["pending", "processing"])))
      .returning();
    if (!p) throw new HttpError(400, "Withdrawal already processed");
    await notify(tx, p.userId, "Withdrawal sent", `Your withdrawal of ${p.amountUsd.toFixed(2)} USD (${p.reference}) has been processed.`);
    return p;
  });
}

export async function rejectPayment(id: number, reason: string) {
  return db.transaction(async (tx) => {
    const [p] = await tx
      .update(payments)
      .set({ status: "rejected", note: reason, updatedAt: new Date() })
      .where(and(eq(payments.id, id), inArray(payments.status, ["pending", "processing"])))
      .returning();
    if (!p) throw new HttpError(400, "Payment already processed");
    if (p.kind === "withdrawal") {
      await adjustBalance(tx, { accountId: p.accountId, userId: p.userId, delta: p.amountUsd, type: "refund", description: `Withdrawal ${p.reference} rejected — funds returned`, reference: p.reference, paymentId: p.id });
    }
    await notify(tx, p.userId, `${p.kind === "deposit" ? "Deposit" : "Withdrawal"} rejected`, reason);
    return p;
  });
}

export async function cancelWithdrawal(auth: AuthContext, id: number) {
  return db.transaction(async (tx) => {
    const [p] = await tx
      .update(payments)
      .set({ status: "cancelled", note: "Cancelled by client", updatedAt: new Date() })
      .where(and(eq(payments.id, id), eq(payments.userId, auth.user.id), eq(payments.kind, "withdrawal"), eq(payments.status, "pending")))
      .returning();
    if (!p) throw new HttpError(400, "Only pending withdrawals can be cancelled");
    await adjustBalance(tx, { accountId: p.accountId, userId: p.userId, delta: p.amountUsd, type: "refund", description: `Withdrawal ${p.reference} cancelled`, reference: p.reference, paymentId: p.id });
    return p;
  });
}

const simulate = () => process.env.SIMULATE_PAYMENTS !== "0";

let processing = false;
export async function processPayments() {
  if (processing) return;
  processing = true;
  try {
    const open = await db.select().from(payments).where(inArray(payments.status, ["pending", "processing"]));
    const now = Date.now();
    for (const p of open) {
      const age = (now - p.createdAt.getTime()) / 1000;
      if (p.kind === "deposit" && p.method !== "MPESA" && simulate()) {
        const m = METHODS[p.method as MethodKey];
        const confs = Math.min(p.requiredConfirmations, Math.floor(age / m.simSecPerConf));
        if (confs >= p.requiredConfirmations) await completeDeposit(p.id, { confirmations: confs });
        else if (confs !== p.confirmations)
          await db.update(payments).set({ confirmations: confs, updatedAt: new Date() }).where(eq(payments.id, p.id));
      } else if (p.kind === "deposit" && p.method === "MPESA" && !mpesaConfigured() && simulate()) {
        if (age > 12) await completeDeposit(p.id, { txHash: mpesaReceipt() });
      } else if (p.kind === "deposit" && p.method === "MPESA" && age > 600) {
        await failPayment(p.id, "M-Pesa request timed out. No funds were deducted.");
      } else if (p.kind === "withdrawal" && process.env.AUTO_APPROVE_WITHDRAWALS === "1" && age > 30) {
        await approveWithdrawal(p.id);
      }
    }
  } catch (e) {
    console.error("payment processor", e);
  } finally {
    processing = false;
  }
}
