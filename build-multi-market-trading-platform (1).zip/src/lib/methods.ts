export type MethodKey = "USDT_TRC20" | "USDT_ERC20" | "BTC" | "ETH" | "MPESA";

export interface MethodDef {
  key: MethodKey;
  label: string;
  asset: "USDT" | "BTC" | "ETH" | "KES";
  network: string;
  minDeposit: number;
  minWithdraw: number;
  withdrawFee: number;
  confirmations: number;
  simSecPerConf: number;
  minKes?: number;
  maxKes?: number;
  processing: string;
  color: string;
  icon: string;
}

export const METHODS: Record<MethodKey, MethodDef> = {
  USDT_TRC20: { key: "USDT_TRC20", label: "Tether USDT (TRC20)", asset: "USDT", network: "TRON (TRC20)", minDeposit: 10, minWithdraw: 10, withdrawFee: 1, confirmations: 19, simSecPerConf: 2, processing: "~1–3 minutes", color: "#26a17b", icon: "₮" },
  USDT_ERC20: { key: "USDT_ERC20", label: "Tether USDT (ERC20)", asset: "USDT", network: "Ethereum (ERC20)", minDeposit: 20, minWithdraw: 25, withdrawFee: 5, confirmations: 12, simSecPerConf: 3, processing: "~3–5 minutes", color: "#26a17b", icon: "₮" },
  BTC: { key: "BTC", label: "Bitcoin", asset: "BTC", network: "Bitcoin (SegWit)", minDeposit: 10, minWithdraw: 20, withdrawFee: 3, confirmations: 2, simSecPerConf: 30, processing: "~10–30 minutes", color: "#f7931a", icon: "₿" },
  ETH: { key: "ETH", label: "Ethereum", asset: "ETH", network: "Ethereum (ERC20)", minDeposit: 10, minWithdraw: 15, withdrawFee: 2, confirmations: 12, simSecPerConf: 3, processing: "~3–5 minutes", color: "#627eea", icon: "Ξ" },
  MPESA: { key: "MPESA", label: "M-Pesa", asset: "KES", network: "Safaricom M-Pesa", minDeposit: 1, minWithdraw: 5, withdrawFee: 0, confirmations: 0, simSecPerConf: 0, minKes: 100, maxKes: 150000, processing: "Instant", color: "#4caf50", icon: "M" },
};

export const METHOD_LIST = Object.values(METHODS);
