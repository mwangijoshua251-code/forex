// Safaricom Daraja API integration. Used automatically when env vars are configured,
// otherwise the platform simulates the STK push flow.
const base = () =>
  process.env.MPESA_ENV === "production" ? "https://api.safaricom.co.ke" : "https://sandbox.safaricom.co.ke";

export function mpesaConfigured() {
  return Boolean(
    process.env.MPESA_CONSUMER_KEY &&
      process.env.MPESA_CONSUMER_SECRET &&
      process.env.MPESA_SHORTCODE &&
      process.env.MPESA_PASSKEY &&
      process.env.MPESA_CALLBACK_URL
  );
}

async function token() {
  const auth = Buffer.from(`${process.env.MPESA_CONSUMER_KEY}:${process.env.MPESA_CONSUMER_SECRET}`).toString("base64");
  const r = await fetch(`${base()}/oauth/v1/generate?grant_type=client_credentials`, {
    headers: { Authorization: `Basic ${auth}` },
    cache: "no-store",
  });
  if (!r.ok) throw new Error("M-Pesa authentication failed");
  const j = (await r.json()) as { access_token: string };
  return j.access_token;
}

function timestamp() {
  const d = new Date(Date.now() + 3 * 3600 * 1000); // EAT
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getUTCFullYear()}${p(d.getUTCMonth() + 1)}${p(d.getUTCDate())}${p(d.getUTCHours())}${p(d.getUTCMinutes())}${p(d.getUTCSeconds())}`;
}

export async function stkPush(phone: string, amountKes: number, reference: string) {
  const t = await token();
  const ts = timestamp();
  const shortcode = process.env.MPESA_SHORTCODE!;
  const password = Buffer.from(`${shortcode}${process.env.MPESA_PASSKEY}${ts}`).toString("base64");
  const msisdn = phone.replace(/^\+/, "");
  const r = await fetch(`${base()}/mpesa/stkpush/v1/processrequest`, {
    method: "POST",
    headers: { Authorization: `Bearer ${t}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      BusinessShortCode: shortcode,
      Password: password,
      Timestamp: ts,
      TransactionType: "CustomerPayBillOnline",
      Amount: Math.ceil(amountKes),
      PartyA: msisdn,
      PartyB: shortcode,
      PhoneNumber: msisdn,
      CallBackURL: process.env.MPESA_CALLBACK_URL,
      AccountReference: reference,
      TransactionDesc: "Account deposit",
    }),
  });
  const j = (await r.json()) as { CheckoutRequestID?: string; errorMessage?: string; ResponseDescription?: string };
  if (!r.ok || !j.CheckoutRequestID) throw new Error(j.errorMessage || j.ResponseDescription || "STK push failed");
  return j.CheckoutRequestID;
}
