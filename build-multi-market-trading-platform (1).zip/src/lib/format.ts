export function money(n: number | null | undefined, withCcy = true) {
  const v = Number(n ?? 0);
  const s = v.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return withCcy ? `${s} USD` : s;
}

export function signed(n: number | null | undefined) {
  const v = Number(n ?? 0);
  return (v > 0 ? "+" : "") + money(v, false);
}

export function dateTime(d: string | number | Date) {
  const x = typeof d === "number" ? new Date(d * 1000) : new Date(d);
  return x.toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

export function timeOnly(sec: number) {
  return new Date(sec * 1000).toLocaleTimeString("en-GB");
}

export async function api<T = unknown>(url: string, init?: RequestInit & { json?: unknown }): Promise<T> {
  const r = await fetch(url, {
    ...init,
    method: init?.method ?? (init?.json !== undefined ? "POST" : "GET"),
    headers: { "Content-Type": "application/json", ...(init?.headers || {}) },
    body: init?.json !== undefined ? JSON.stringify(init.json) : init?.body,
    cache: "no-store",
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error((j as { error?: string }).error || `Request failed (${r.status})`);
  return j as T;
}
