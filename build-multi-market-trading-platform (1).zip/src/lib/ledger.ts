import { and, eq, gte, sql } from "drizzle-orm";
import type { PgDatabase } from "drizzle-orm/pg-core";
import { accounts, notifications, transactions } from "@/db/schema";
import { HttpError } from "./auth";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type Exec = PgDatabase<any, any, any>;

export function round2(n: number) {
  return Math.round(n * 100) / 100;
}

export async function adjustBalance(
  tx: Exec,
  opts: {
    accountId: number;
    userId: number;
    delta: number;
    type: string;
    description: string;
    reference?: string;
    contractId?: number;
    paymentId?: number;
  }
) {
  const delta = round2(opts.delta);
  const where =
    delta < 0 ? and(eq(accounts.id, opts.accountId), gte(accounts.balance, -delta)) : eq(accounts.id, opts.accountId);
  const [acc] = await tx
    .update(accounts)
    .set({ balance: sql`round((${accounts.balance} + ${delta})::numeric, 2)::double precision` })
    .where(where)
    .returning();
  if (!acc) throw new HttpError(400, "Insufficient balance");
  await tx.insert(transactions).values({
    accountId: opts.accountId,
    userId: opts.userId,
    type: opts.type,
    amount: delta,
    balanceAfter: acc.balance,
    description: opts.description,
    reference: opts.reference,
    contractId: opts.contractId,
    paymentId: opts.paymentId,
  });
  return acc;
}

export async function notify(tx: Exec, userId: number, title: string, body: string) {
  await tx.insert(notifications).values({ userId, title, body });
}
