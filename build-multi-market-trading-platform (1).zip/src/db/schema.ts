import {
  pgTable,
  serial,
  text,
  integer,
  doublePrecision,
  timestamp,
  bigint,
  boolean,
  index,
} from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").unique(),
  phone: text("phone").unique(),
  passwordHash: text("password_hash").notNull(),
  fullName: text("full_name").notNull(),
  country: text("country").notNull().default("Kenya"),
  role: text("role").notNull().default("user"),
  kycStatus: text("kyc_status").notNull().default("unverified"),
  kycDocType: text("kyc_doc_type"),
  kycDocNumber: text("kyc_doc_number"),
  dateOfBirth: text("date_of_birth"),
  address: text("address"),
  dailyLossLimit: doublePrecision("daily_loss_limit"),
  maxStake: doublePrecision("max_stake"),
  selfExcludedUntil: timestamp("self_excluded_until"),
  disabled: boolean("disabled").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const sessions = pgTable("sessions", {
  id: text("id").primaryKey(),
  userId: integer("user_id").notNull(),
  activeAccountId: integer("active_account_id"),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const accounts = pgTable("accounts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // demo | real
  loginId: text("login_id").notNull().unique(),
  currency: text("currency").notNull().default("USD"),
  balance: doublePrecision("balance").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const contracts = pgTable(
  "contracts",
  {
    id: serial("id").primaryKey(),
    accountId: integer("account_id").notNull(),
    userId: integer("user_id").notNull(),
    symbol: text("symbol").notNull(),
    contractType: text("contract_type").notNull(),
    stake: doublePrecision("stake").notNull(),
    payout: doublePrecision("payout"),
    barrier: doublePrecision("barrier"),
    barrierLow: doublePrecision("barrier_low"),
    digit: integer("digit"),
    durationSec: integer("duration_sec"),
    durationLabel: text("duration_label"),
    entrySpot: doublePrecision("entry_spot").notNull(),
    entryTime: bigint("entry_time", { mode: "number" }).notNull(),
    expiryTime: bigint("expiry_time", { mode: "number" }),
    exitSpot: doublePrecision("exit_spot"),
    exitTime: bigint("exit_time", { mode: "number" }),
    status: text("status").notNull().default("open"), // open | won | lost | sold
    profit: doublePrecision("profit"),
    sellPrice: doublePrecision("sell_price"),
    multiplier: integer("multiplier"),
    takeProfit: doublePrecision("take_profit"),
    stopLoss: doublePrecision("stop_loss"),
    growthRate: doublePrecision("growth_rate"),
    commission: doublePrecision("commission"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("contracts_status_idx").on(t.status), index("contracts_account_idx").on(t.accountId)]
);

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  accountId: integer("account_id").notNull(),
  kind: text("kind").notNull(), // deposit | withdrawal
  method: text("method").notNull(), // USDT_TRC20 | USDT_ERC20 | BTC | ETH | MPESA
  amountUsd: doublePrecision("amount_usd").notNull(),
  feeUsd: doublePrecision("fee_usd").notNull().default(0),
  assetAmount: doublePrecision("asset_amount"),
  assetCurrency: text("asset_currency"),
  rate: doublePrecision("rate"),
  address: text("address"),
  phone: text("phone"),
  txHash: text("tx_hash"),
  reference: text("reference").notNull(),
  confirmations: integer("confirmations").notNull().default(0),
  requiredConfirmations: integer("required_confirmations").notNull().default(0),
  status: text("status").notNull().default("pending"), // pending | processing | completed | rejected | failed | cancelled
  note: text("note"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const transactions = pgTable(
  "transactions",
  {
    id: serial("id").primaryKey(),
    accountId: integer("account_id").notNull(),
    userId: integer("user_id").notNull(),
    type: text("type").notNull(), // deposit | withdrawal | buy | sell | payout | reset | refund
    amount: doublePrecision("amount").notNull(),
    balanceAfter: doublePrecision("balance_after").notNull(),
    reference: text("reference"),
    description: text("description"),
    contractId: integer("contract_id"),
    paymentId: integer("payment_id"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("tx_account_idx").on(t.accountId)]
);

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  body: text("body").notNull(),
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const priceAlerts = pgTable("price_alerts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  symbol: text("symbol").notNull(),
  direction: text("direction").notNull(), // above | below
  price: doublePrecision("price").notNull(),
  triggered: boolean("triggered").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type User = typeof users.$inferSelect;
export type Account = typeof accounts.$inferSelect;
export type Contract = typeof contracts.$inferSelect;
export type Payment = typeof payments.$inferSelect;
